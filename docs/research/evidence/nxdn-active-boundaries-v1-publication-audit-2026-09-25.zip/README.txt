External publication audit recorded after the immutable main archive was created.
No native receiver or encoder execution. The script verifies both the distributable
archive and original-machine preservation paths; those paths are not portable.
Retained source is for reproducibility and inspection, not an app installer.
Portable frozen-checker replay instructions are in the main archive README.
