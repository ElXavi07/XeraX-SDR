# Availability v1 checker / runner pre-execution review

Decision: no remaining static measurement, input-copy or runner blocker found in the reviewed sources. This does not authorize a receiver launch before the separately required native unit, source/linkage, preservation and committed-source gates pass. No receiver process or input generation was performed by this reviewer.

## Scope and identity

Registration: `76e175aef1b8f30431c07cb3d4a50d431b858c02`; product baseline: `ec712a0869184c0b73ec06b1ce36d3d1bdaf6b04`. Review is separate from checker/runner implementation; this reviewer implemented the private acquisition APIs, so this is not an independent review of that implementation.

| Reviewed file | SHA256 |
|---|---|
| `analyze.py` | `de809c70d328c3ce2accf0543ff7e3402cd699d0e08fdfd7696e06afaa693432` |
| `test_analyze.py` | `f5ac79de3f474c89825fc58aa02551aa07c821561037201aff6b94d5d32c16e5` |
| `prepare_inputs.py` | `6839179bb72fe224288b66b380587bce34fd3633e1b7517f51cdc3a563273b19` |
| `prepare_build.py` | `a98895a1abc2ff74cb2f4825a8a60e703febfc9a9ab11dd8be8ddfee8e390a40` |
| `run.py` | `e63ff11d6d89a3fe22ff9b0a141359719e3db6bf1bcb251833de4c8d38e906b5` |
| `test_run.py` | `43ed77b6d4da687e5e7655be0420ea9a8db262c14d878b7c7dd96a4de059c21e` |

Copied input manifest independently rehashed as `d42a311b1367b0a200dd3c52ab0aaa3bfd292a429785a9ac534ee54348dad98c`. No copied input was edited.

## Input and observation constraints

- Fixed matrix is five immutable inputs Ã— chunks37/512 Ã— detail0/1 =20 new candidate identities, always public fast1. There is no baseline process invocation, old matrix rerun, corpus synthesis or adaptive case selection.
- The copy recipe checks the failed active study report and all recorded files before copying. The checker reconstructs the fixed case list, source waveform metadata, prior reference inventory and recipe identity; it uses the frozen source oracle and finite evidence implementation rather than candidate output as truth.
- Explicit per-call availability is checked against the existing independent finite sample/body-call classification. A reported complete call cannot hide a partial or absent symbol. The per-route mask must equal the independently completed selected source-slot ranges; even an unavailable route without synthesis is rejected.
- A complete early slot is retained despite later EOF. Prefix6159 expects zero real FEC/synthesis and unchanged media/audio indices; prefixes6160/6161 expect one. Strong/header/source-bit and negative gates remain in force. Detail and chunk pairs retain common state, body and source evidence checks; detailed PCM remains descriptive.
- Full clean and bad-LICH inputs must preserve cached common receiver outcomes after removal only of availability_schema, available_slots and per-call available telemetry. Known bad-LICH 12/20 recovery failure remains a retention/progression failure even if the narrower availability guard passes. Product promotion remains false.

## Execution and failure retention

- Runner validates committed harness, untouched product sources, exact input manifest, source/linkage audit and the exact eight passed dedicated native unit groups with saved JUnit SHA/name/outcome verification before execution. Unit status and build/source identities are retained; this review does not substitute for those gates.
- It snapshots the new candidate executable and runtime DLLs, copied inputs, candidate/legacy source closure, generated sources, compile configuration, link maps, registration and completed preflight logs. It merges the five historical preservation groups and historical report inventory with conflict rejection.
- Before every launch it rehashes original, copied, configured, historical and loaded-source groups. Drift aborts subsequent launches. The exact fast/chunk/detail arguments and cleaned DSD_ environment are recorded.
- Every distinct attempt retains raw stdout/stderr, process result, partial trace and checker error. Timeouts, nonzero exits and malformed/incomplete evidence cannot become measurement passes. No automatic retry exists; per-identity and output directories are created exclusively. Final aggregate requires all20 successful measurements and preservation.

## Resolved pre-execution findings and limits

- This review requested an explicit expected hash for the original routing observer_extra.inc outside the baseline copy manifest. prepare_build.py now rejects anything except `9459b0f168e47511beb2f4bb66832fff5f9ff8542f40725c93187d197eb8a192` before applying observation-only wrappers.
- Initial configure seam mismatch, missing imported-scope RTL unit target, checked-wrapper missing prototype and inherited no-radio metrics-declaration compile failures were retained by the parent. They occurred before receiver execution. Acquisition provenance records its own CMake/declaration corrections.
- The inherited Pulse/headful WAV adapter semantics are explicitly outside general all-backend availability certification. The registered finite RTL/headless/replay scope is unchanged. No speech quality, RF robustness, wall-clock speed, privacy-path or app safety claim follows from these tests.

Parent framework log `build/nxdn-availability-v1-framework-preflight-2.log` records28 passing Python tests; this reviewer read the tests and result but did not rerun them. Native unit/linkage execution was still pending when this static review was written.

## Final pre-execution closure

Parent build6 and the first dedicated native CTest run completed: eight actual testcases passed, including radio and radio-less acquisition plus frame/voice guards. The reviewer independently reopened the status/log/XML; XML SHA256 is `6e0a45e1f7d09302e478e8ec006d54959e08169aba3f9b362aa80322cb372c2e`. Receiver invocations remain zero. `ACQUISITION-PROVENANCE.md` now includes exact baseline/candidate hashes, complete normalized diff and every retained preflight failure/correction. The subsequent bounded runner evidence hardening is recorded below; checker and input-copy source are unchanged. Source/linkage audit, final source commit and any required CI still remain separate launch prerequisites.

## Final runner evidence hardening before commit

The launch gate now verifies the saved native-unit status and actual JUnit bytes together: exactly the eight registered names, count 8, successful CTest exit, zero prior receiver invocations, executed testcase status, no failure/error/skipped element or suite total, and an exact XML SHA256 match. Missing, duplicate, extra (including nested), mislabeled or reordered cases fail. Final status/log must byte-match the retained attempt 1 status/log. All five files enter the preserved original identities before copying and are rechecked before every native launch.

The snapshot now includes `native-unit-1.xml`, both attempt 1 log/status and their final copies, plus all eight completed build-audit development artifacts (first/second/third auditor source versions and their logs, final/pass logs). Bounded preflight patterns also retain earlier and final Python framework output. The live receiver run log remains excluded. A read-only validation of the actual saved native evidence passed and selected all five evidence files; the development-artifact inventory includes all eight actual files.

This narrow runner validation change was implemented by this reviewer at the parent's request, so its self-review is not an independent implementation audit. The prior original-runner/checker review remains separate; the parent reviews this final diff before freezing.

Meaningful synthetic counterexamples cover XML hash tampering, rehashed failure/error/skips, suite counters, unexecuted cases, missing/duplicate/extra/wrong/reordered names, status counter/type/exit claims, mismatched status/log copies, missing/malformed XML, and tampering after validation that blocks launch before invocation. Artifact selection is tested to retain auditor failure sources/logs without selecting live-run or unrelated-study files.

Final Python framework checks: **44 tests passed normally and 44 passed under python -O**. All earlier framework outputs were retained separately before updating the final log aliases. No receiver, native unit or encoder was invoked for this revision. No candidate source, input or native evidence changed. A service interruption during editing was recorded without sensitive service details in the preflight notes.

| Final artifact | SHA256 |
|---|---|
| `experiments/nxdn_availability_v1/run.py` | `e63ff11d6d89a3fe22ff9b0a141359719e3db6bf1bcb251833de4c8d38e906b5` |
| `experiments/nxdn_availability_v1/test_run.py` | `43ed77b6d4da687e5e7655be0420ea9a8db262c14d878b7c7dd96a4de059c21e` |
| `build/nxdn-availability-v1-unit.log` | `ae144d0ffdd0d8111be30a926c4f1a34cfef30ed40497c5d14cae85b0ea948f0` |
| `build/nxdn-availability-v1-unit-optimized.log` | `1d5e177f178be1f7c84820acdb3d4eee359cb23f249ba35b3378614ea6100e00` |
