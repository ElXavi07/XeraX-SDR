# NXDN availability v1 independent build audit

PASS: the seven private candidate files and headers match configured identity; their original product files match the registered baseline Git bytes. Full normalized private diffs are retained in the machine report. Observation inverses recover the exact candidate frame and frozen recorder sources.

Executable SHA-256 `788c655cf616ea53804f8bd70d174e42b7038a173f8a0aaf514fc2ccb47f599d`; 1359 configured translation units, 372 existing object translation units, 36 explicit linked archive inputs, 4 non-system runtime DLLs. Actual map owners, object relocations and final resolved calls connect checked reader to checked symbol, masked voice to real vocoder, and observation wrappers to the pinned real hard/soft FEC and synthesis routines. Candidate headers precede upstream headers for private source objects; no old first-sync or boundary policy macro is configured.

Radio/no-radio unit evidence records actual distinct objects, compile options, undefined symbols, unique public definitions, and per-unit maps when generated. The audit did not execute any test or receiver. Build/unit failures and corrections remain separate preserved logs; their content is not silently replaced.

Three audit-development failures are preserved: archive member maps omit archive names, common input metrics remain in no-radio objects, and a CMakeCache parser captured a leading blank line. The final audit uses unique linked-archive definitions, the actual RTL reader reference, and stricter cache-key parsing, respectively.

Runtime imports are resolved statically from the declared directories and hashed; OS DLLs remain prerequisites. These checks establish source/linkage identity and reversible observation, not runtime neutrality, FEC correctness, finite-EOF safety, speech or RF quality.
