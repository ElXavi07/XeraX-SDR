$ErrorActionPreference = 'Stop'
$availabilityBuild = Join-Path $env:LOCALAPPDATA 'XeraXSDR-build/nxdn-availability-v1-20260925'
$availabilityRoot = (Get-Location).Path
if (Test-Path -LiteralPath $availabilityBuild) { throw 'Existing candidate build directory is preserved.' }
New-Item -ItemType Directory -Path $availabilityBuild | Out-Null
Copy-Item -LiteralPath (Join-Path $availabilityRoot 'build/nxdn-clear-routing-v1-run-20260925/frozen/toolchain.cmake') -Destination (Join-Path $availabilityBuild 'toolchain.cmake')
& cmake -S experiments/nxdn_availability_v1 -B $availabilityBuild -G Ninja `
  -DCMAKE_BUILD_TYPE=Release `
  "-DCMAKE_TOOLCHAIN_FILE=$env:LOCALAPPDATA/XeraXSDR-build/vcpkg/scripts/buildsystems/vcpkg.cmake" `
  "-DVCPKG_CHAINLOAD_TOOLCHAIN_FILE=$availabilityBuild/toolchain.cmake" `
  "-DVCPKG_INSTALLED_DIR=$env:LOCALAPPDATA/XeraXSDR-build/lab-installed" `
  -DVCPKG_TARGET_TRIPLET=x64-mingw-static -DVCPKG_HOST_TRIPLET=x64-mingw-static `
  -DVCPKG_MANIFEST_MODE=OFF -DCMAKE_C_FLAGS=-Wno-unused-command-line-argument `
  -DCMAKE_CXX_FLAGS=-Wno-unused-command-line-argument -DDSD_AUDIO_BACKEND=none `
  -DDSD_ENABLE_QT_UI=OFF -DDSD_ENABLE_TERMINAL_UI=OFF -DDSD_FORCE_RADIO_PIPELINE=ON `
  -DDSD_ENABLE_LTO=OFF -DDSD_ENABLE_FAST_MATH=OFF -DDSD_ENABLE_NATIVE=OFF `
  2>&1 | Tee-Object -FilePath (Join-Path $availabilityRoot 'build/nxdn-availability-v1-configure.log')
if ($LASTEXITCODE -ne 0) { throw 'Candidate configure failed; evidence retained.' }
& cmake --build $availabilityBuild --target xerax_nxdn_availability_v1 `
  xerax_nxdn_voice_available xerax_nxdn_frame_available xerax_availability_symbol_replay `
  xerax_availability_symbol_replay_no_radio xerax_availability_symbol_wav `
  xerax_availability_symbol_wav_no_radio xerax_availability_symbol_live xerax_availability_dibit --parallel 4 `
  2>&1 | Tee-Object -FilePath (Join-Path $availabilityRoot 'build/nxdn-availability-v1-build.log')
if ($LASTEXITCODE -ne 0) { throw 'Candidate build failed; evidence retained.' }
