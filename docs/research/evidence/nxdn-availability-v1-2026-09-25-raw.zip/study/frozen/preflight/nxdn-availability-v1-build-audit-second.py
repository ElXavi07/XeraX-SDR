"""Read-only availability candidate source/object/PE audit; no receiver execution."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'experiments/nxdn_availability_v1'
BUILD = Path(os.environ['LOCALAPPDATA']) / 'XeraXSDR-build/nxdn-availability-v1-20260925'
INSTALLED = Path(os.environ['LOCALAPPDATA']) / 'XeraXSDR-build/lab-installed/x64-mingw-static'
OUT = ROOT / 'build/nxdn-availability-v1-build-audit'
BASELINE = 'ec712a0869184c0b73ec06b1ce36d3d1bdaf6b04'
REGISTRATION = '76e175aef1b8f30431c07cb3d4a50d431b858c02'
PARSER_SHA = '771f7d520ca6783aaa4a0b8e45a52e41bcd7004cc8b8bbb028e4d8c274ac6595'
MBE_SHA = '28007fa92e61618526c876656291d671f7d8bf41cc5ff8117bbe6702ac95088f'
checks = 0

def need(value, message):
    global checks
    checks += 1
    if not value: raise ValueError(message)

def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def text(path): return Path(path).read_text(encoding='utf-8').replace('\r\n', '\n')
def once(value, before, after=''):
    need(value.count(before) == 1, 'nonunique inverse observation seam: ' + before[:90])
    return value.replace(before, after)

def inspect_tool(program, *args):
    return subprocess.run([str(program), *map(str, args)], capture_output=True, text=True, check=True).stdout

def path_for(command, field):
    path = Path(command[field])
    return path if path.is_absolute() else Path(command['directory']) / path

def source_audit():
    generated = BUILD / 'generated'
    identity = json.loads((generated / 'source-identity.json').read_bytes())
    copied = json.loads((HERE / 'baseline_observer/copy-manifest.json').read_bytes())
    old_identity = json.loads((HERE / 'baseline_observer/source-identity.json').read_bytes())
    need(identity['registration_commit'] == REGISTRATION, 'registration differs')
    need(copied['parent_report_sha256'] == '50a7dbb4b33200e203e102f58195110abedf6159ce02b66b551ebb2c65b74ab0', 'parent report differs')
    need(identity['baseline_copy_manifest_sha256'] == digest(HERE / 'baseline_observer/copy-manifest.json'), 'copy manifest changed')
    need(identity['generator_sha256'] == digest(HERE / 'prepare_build.py'), 'configured generator changed')
    need(len(copied['files']) == 8, 'copied observer inventory differs')
    for name, expected in copied['files'].items():
        need(digest(HERE / 'baseline_observer' / name) == expected, 'copied observer drift: ' + name)
    for group in ('original_sources', 'observation_sources'):
        for name, expected in old_identity[group].items():
            need(digest(ROOT / name) == expected, 'historical source drift: ' + name)
            git_raw = subprocess.check_output(['git', 'show', BASELINE + ':' + name], cwd=ROOT)
            need(hashlib.sha256(git_raw).hexdigest() == expected, 'historical Git provenance differs: ' + name)
    for name, expected in identity['generated_sources'].items():
        need(digest(generated / name) == expected, 'generated source drift: ' + name)
    need(identity['frozen_generated_sources'] == copied['files'], 'frozen observer inventory differs')
    need(identity['frozen_routing_extra_sha256'] == digest(ROOT / 'experiments/nxdn_clear_routing_v1/observer_extra.inc'), 'routing observer drift')

    candidate = HERE / 'candidate'
    allowed = {'include/dsd-neo/core/dibit.h', 'include/dsd-neo/dsp/symbol.h',
        'include/dsd-neo/protocol/nxdn/nxdn_voice.h', 'src/core/frames/dsd_dibit.c',
        'src/dsp/dsd_symbol.c', 'src/protocol/nxdn/nxdn_frame.c', 'src/protocol/nxdn/nxdn_voice.c'}
    actual = {p.relative_to(candidate).as_posix() for p in candidate.rglob('*') if p.is_file()}
    need(actual == allowed, 'candidate file inventory differs')
    need(set(identity['candidate_sources']) == {'candidate/' + x for x in actual}, 'configured candidate inventory differs')
    diffs, originals = {}, {}
    for relative in sorted(actual):
        original = ROOT / 'upstream/dsd-neo' / relative
        original_raw = subprocess.check_output(['git', 'show', BASELINE + ':' + original.relative_to(ROOT).as_posix()], cwd=ROOT)
        need(original.read_bytes() == original_raw, 'product baseline changed: ' + relative)
        need(digest(candidate / relative) == identity['candidate_sources']['candidate/' + relative], 'candidate changed since configure: ' + relative)
        originals[str(original)] = digest(original)
        diffs[relative] = ''.join(difflib.unified_diff(original_raw.decode('utf-8').replace('\r\n', '\n').splitlines(True),
            text(candidate / relative).splitlines(True), fromfile='original/' + relative, tofile='candidate/' + relative))
        need(diffs[relative], 'declared candidate file has no changes: ' + relative)

    for name in ('engine_observed.c', 'dispatch_observed.c', 'nxdn_deperm_observed.c', 'observer_api.h'):
        need(text(generated / name) == text(HERE / 'baseline_observer' / name), 'unchanged observation source differs: ' + name)
    frame = once(text(generated / 'nxdn_frame_observed.c'), '#include "observer_api.h"\n')
    frame, count = re.subn(r'^    xerax_v2_lich\(state, "(?:parity_reject|direction_reject|unsupported_profile|accepted)",[^\n]+\);\n', '', frame, flags=re.M)
    # Reject hooks are indented inside the branch; remove separately.
    frame, nested_count = re.subn(r'^        xerax_v2_lich\(state, "(?:parity_reject|direction_reject|unsupported_profile)",[^\n]+\);\n', '', frame, flags=re.M)
    need(count + nested_count == 4, 'LICH observation hook count differs')
    need(frame == text(candidate / 'src/protocol/nxdn/nxdn_frame.c'), 'observed frame is not reversible to candidate')

    observer = text(generated / 'observer.c')
    old_observer = text(HERE / 'baseline_observer/observer.c')
    start = observer.index('int __real_dsd_get_dibit_soft_checked(')
    end = observer.index('int __wrap_rtl_stream_start', start)
    wrapper = observer[start:end]
    need(wrapper.count('__real_dsd_get_dibit_soft_checked(opts, state, dibit, soft)') == 1, 'checked reader not forwarded once')
    need('call.available = available;' in wrapper and 'return available;' in wrapper, 'availability return not observed')
    need('call.after = v2_consumed(state); call.eof_after = exhausted; call.symbol_after = state->symbolcnt;' in wrapper, 'after-read observation absent')
    need('body_positions[body_count] = (!call.eof_after && call.symbol_after == call.symbol_before + 1U) ? call.after : 0;' in wrapper, 'independent source-position witness altered')
    need(not re.search(r'\b(?:state|opts)->\w+\s*=(?!=)', wrapper), 'checked wrapper writes decoder state')
    old_start, old_end = old_observer.index('int\n__wrap_getDibitSoft('), old_observer.index('int __wrap_rtl_stream_start')
    observer = observer[:start] + old_observer[old_start:old_end] + observer[end:]
    observer = once(observer, '    printf(",\\"availability_schema\\":1,\\"observation_schema\\":2,', '    printf(",\\"observation_schema\\":2,')
    need(observer == old_observer, 'recorder differs outside checked-read/schema observation')

    v2 = text(generated / 'v2_observer_extra.inc')
    v2 = once(v2, '    int eof_before, eof_after, available;', '    int eof_before, eof_after;')
    v2 = once(v2, '\\"symbol_before\\":%u,\\"symbol_after\\":%u,\\"available\\":%d}', '\\"symbol_before\\":%u,\\"symbol_after\\":%u}')
    v2 = once(v2, 'c->eof_before, c->eof_after, c->symbol_before, c->symbol_after, c->available);', 'c->eof_before, c->eof_after, c->symbol_before, c->symbol_after);')
    v2 = v2.replace('__real_nxdn_voice_masked', '__real_nxdn_voice').replace('__wrap_nxdn_voice_masked', '__wrap_nxdn_voice')
    v2 = v2.replace('int, uint8_t[182], const uint8_t*, uint8_t);', 'int, uint8_t[182], const uint8_t*);')
    v2 = once(v2, 'const uint8_t* reliability, uint8_t available_slots) {', 'const uint8_t* reliability) {')
    v2 = once(v2, '__real_nxdn_voice(opts, state, voice, data, reliability, available_slots);', '__real_nxdn_voice(opts, state, voice, data, reliability);')
    need(v2 == text(HERE / 'baseline_observer/v2_observer_extra.inc'), 'V2 observation inverse differs')

    routing = text(generated / 'observer_extra.inc')
    need(not re.search(r'\b(?:state|opts)->\w+\s*=(?!=)', routing), 'routing observation writes decoder state')
    routing = routing.replace('__wrap_nxdn_voice_masked', '__wrap_nxdn_voice')
    routing = once(routing, '    int voice;\n    uint8_t available_slots;\n} routing_voice_context;', '    int voice;\n} routing_voice_context;')
    routing = once(routing, '    printf(",\\"available_slots\\":%u", (unsigned)routing_voice.available_slots);\n')
    routing = once(routing, 'int, uint8_t[182], const uint8_t*, uint8_t);', 'int, uint8_t[182], const uint8_t*);')
    routing = once(routing, 'const uint8_t* reliability, uint8_t available_slots) {', 'const uint8_t* reliability) {')
    routing = once(routing, '.reliability = reliability, .voice = voice, .available_slots = available_slots};', '.reliability = reliability, .voice = voice};')
    routing = once(routing, 'routing_v2_nxdn_voice(opts, state, voice, data, reliability, available_slots);', 'routing_v2_nxdn_voice(opts, state, voice, data, reliability);')
    need(routing == text(ROOT / 'experiments/nxdn_clear_routing_v1/observer_extra.inc'), 'routing observation inverse differs')
    return identity, originals, diffs

def parsers():
    path = ROOT / 'build/nxdn-voice-words-v1-preflight-audit.py'
    need(digest(path) == PARSER_SHA, 'read-only parser source drift')
    source = text(path)
    namespace = {'need': need, 'Path': Path, 'struct': struct}
    for node in ast.parse(source).body:
        if isinstance(node, ast.FunctionDef) and node.name in ('pe_imports', 'map_owners'):
            code = ast.get_source_segment(source, node).replace('line.strip().endswith(symbol)', '(len(line.split(maxsplit=3)) == 4 and line.split(maxsplit=3)[3] == symbol)')
            exec(compile(code, str(path), 'exec'), namespace)
    return namespace['pe_imports'], namespace['map_owners'], path

def main():
    binary = BUILD / 'xerax_nxdn_availability_v1.exe'
    link_map = BUILD / 'availability.map'
    need(binary.is_file() and link_map.is_file(), 'final binary/map absent')
    initial_binary = digest(binary)
    identity, originals, diffs = source_audit()
    pe_imports, map_owners, parser_path = parsers()
    cache = dict(re.findall(r'^([^#/:][^:\n]*):[^=\n]+=(.*)$', text(BUILD / 'CMakeCache.txt'), re.M))
    commands = json.loads((BUILD / 'compile_commands.json').read_bytes())
    nm, objdump = Path(cache['CMAKE_NM']), Path(cache['CMAKE_OBJDUMP'])
    need(all('-flto' not in c['command'].lower() for c in commands), 'LTO configured')
    forbidden = ('XERAX_FIRST_CANONICAL_NXDN48', 'XERAX_NXDN_BOUNDARY')
    need(all(not any(re.search(r'[-/]D' + x, c['command']) for x in forbidden) for c in commands), 'unregistered recovery macro configured')
    ninja = text(BUILD / 'build.ninja')
    block = re.search(r'^build xerax_nxdn_availability_v1.exe:.*?(?=\n\n)', ninja, re.M | re.S).group()
    wraps = ('dsd_get_dibit_soft_checked', 'nxdn_voice_masked', 'processMbeFrameSoft', 'processMbeFrame', 'processAudio',
        'mbe_decodeAmbe3600x2450Frame', 'mbe_decodeAmbe3600x2450SoftFrame', 'mbe_processAmbe2450Dataf',
        'rtl_stream_start', 'rtl_stream_tune', 'rtl_stream_tune_tagged', 'rtl_stream_output_rate', 'rtl_stream_request_fsk_reacquire')
    need(set(re.findall(r'--wrap=(\w+)', block)) == set(wraps), 'link wrap inventory differs')
    libraries = re.search(r'^  LINK_LIBRARIES = (.+)$', block, re.M).group(1).split()
    archives = sorted({(Path(p) if Path(p).is_absolute() else BUILD / p).resolve() for p in libraries if p.endswith('.a')})
    need(all(p.is_file() for p in archives), 'archive input missing')
    mbe = INSTALLED / 'lib/libmbe-neo-static.a'
    need(mbe.resolve() in archives and digest(mbe) == MBE_SHA, 'real pinned mbelib archive differs')
    mbe_symbols = ('mbe_decodeAmbe3600x2450Frame', 'mbe_decodeAmbe3600x2450SoftFrame', 'mbe_processAmbe2450Dataf')
    definitions = [line for line in inspect_tool(nm, '--defined-only', '--print-file-name', mbe).splitlines() if any(line.endswith(' ' + s) for s in mbe_symbols)]
    need(len(definitions) == 3 and all('ambe3600x2450.c.obj:' in x and ' T ' in x for x in definitions), 'real mbelib definition ownership differs')
    expected = {'main': 'generated/observer.c.obj:(.text)', 'xerax_run_live_loop': 'generated/engine_observed.c.obj:(.text)',
        'dsd_dispatch_handle_nxdn': 'generated/dispatch_observed.c.obj:(.text)',
        'nxdn_frame': 'nxdn_frame_observed.c.obj:(.text)', 'nxdn_deperm_facch_soft': 'nxdn_deperm_observed.c.obj:(.text)',
        'nxdn_deperm_sacch_soft': 'nxdn_deperm_observed.c.obj:(.text)', 'nxdn_voice_masked': 'nxdn_voice.c.obj:(.text)',
        'processMbeFrameSoft': 'dsd_mbe.c.obj:(.text)', 'processMbeFrame': 'dsd_mbe.c.obj:(.text)',
        'processMbeFrameInternal': 'dsd_mbe.c.obj:(.text)', 'decode_ambe2450_frame': 'dsd_mbe.c.obj:(.text)',
        'processAudio': 'dsd_audio.c.obj:(.text)', 'dsd_get_dibit_soft_checked': 'dsd_dibit.c.obj:(.text)',
        'getDibitSoft': 'dsd_dibit.c.obj:(.text)', 'getFrameSync': 'dsd_frame_sync.c.obj:(.text)',
        'getSymbol': 'dsd_symbol.c.obj:(.text)', 'dsd_get_symbol_checked': 'dsd_symbol.c.obj:(.text)',
        **{s: 'ambe3600x2450.c.obj:(.text)' for s in mbe_symbols},
        **{'__wrap_' + s: 'generated/observer.c.obj:(.text)' for s in wraps}}
    owners = map_owners(link_map, expected)
    for symbol, suffix in expected.items():
        need(len(owners[symbol]) == 1 and owners[symbol][0].replace('\\', '/').endswith(suffix), 'wrong symbol owner: ' + symbol + repr(owners[symbol]))
    for symbol in ('dsd_get_dibit_soft_checked', 'getDibitSoft'):
        need('xerax_nxdn_availability_v1.dir' in owners[symbol][0], 'original dibit selected instead of candidate')
    # LLD maps archive members by object basename, without archive provenance.
    # Establish unique new API ownership from every actual archive input too.
    private_archive_definitions = {}
    for path in archives:
        listing = inspect_tool(nm, '--defined-only', '--print-file-name', path).splitlines()
        for symbol in ('nxdn_voice_masked', 'dsd_get_symbol_checked'):
            for line in listing:
                if line.endswith(' ' + symbol) and ' T ' in line:
                    private_archive_definitions.setdefault(symbol, []).append({'archive': str(path), 'definition': line})
    for symbol, name in (('nxdn_voice_masked', 'libxerax_availability_protocol.a'),
                         ('dsd_get_symbol_checked', 'libdsd-neo_dsp_private_test_support.a')):
        found = private_archive_definitions.get(symbol, [])
        need(len(found) == 1 and Path(found[0]['archive']).name == name, 'ambiguous private API archive owner: ' + symbol)

    def object_for(name, target):
        choices = [c for c in commands if Path(c['file']).name == name and target in c['output']]
        need(len(choices) == 1, 'ambiguous object: ' + name + '/' + target)
        command = choices[0]
        path = path_for(command, 'output')
        need(path.is_file() and path.read_bytes()[:2] == b'\x64\x86', 'actual AMD64 COFF object absent: ' + str(path))
        return path, command
    selectors = {'observer': ('observer.c', 'xerax_nxdn_availability_v1'),
        'engine': ('engine_observed.c', 'xerax_nxdn_availability_v1'),
        'dispatch': ('dispatch_observed.c', 'xerax_nxdn_availability_v1'),
        'frame': ('nxdn_frame_observed.c', 'xerax_availability_protocol'),
        'channel': ('nxdn_deperm_observed.c', 'xerax_availability_protocol'),
        'voice': ('nxdn_voice.c', 'xerax_availability_protocol'),
        'dibit': ('dsd_dibit.c', 'xerax_nxdn_availability_v1'),
        'symbol': ('dsd_symbol.c', 'dsd-neo_dsp_private_test_support'),
        'sync': ('dsd_frame_sync.c', 'dsd-neo_dsp_private_test_support'),
        'vocoder': ('dsd_mbe.c', 'dsd-neo_core'), 'audio': ('dsd_audio.c', 'dsd-neo_core')}
    objects, selected_commands = {}, {}
    for key, args in selectors.items(): objects[key], selected_commands[key] = object_for(*args)
    for key in ('voice', 'dibit', 'symbol'):
        need(str(HERE / 'candidate').replace('\\', '/') in str(path_for(selected_commands[key], 'file')).replace('\\', '/'), 'private source not compiled: ' + key)
    for key in ('frame', 'voice', 'dibit', 'symbol'):
        command = selected_commands[key]['command'].replace('\\', '/')
        need(command.index(str(HERE / 'candidate/include').replace('\\', '/')) < command.index(str(ROOT / 'upstream/dsd-neo/include').replace('\\', '/')), 'candidate header precedence lost: ' + key)
    relocations = {}
    expected_relocations = {'frame': ('dsd_get_dibit_soft_checked', 'nxdn_voice_masked'),
        'dibit': ('dsd_get_symbol_checked',), 'voice': ('processMbeFrameSoft', 'processMbeFrame'),
        'vocoder': mbe_symbols, 'dispatch': ('xerax_record_frame',),
        'observer': tuple('__real_' + s for s in wraps if s not in ('rtl_stream_start', 'rtl_stream_tune', 'rtl_stream_tune_tagged'))}
    for key, symbols in expected_relocations.items():
        rows = inspect_tool(objdump, '-r', objects[key]).splitlines()
        selected = [line for line in rows if line.split() and line.split()[-1] in symbols]
        need(all(any(line.split()[-1] == symbol and 'IMAGE_REL_AMD64_REL32' in line for line in selected) for symbol in symbols), 'call relocation missing: ' + key)
        relocations[key] = selected
    named = tuple('__wrap_' + s for s in mbe_symbols) + ('decode_ambe2450_frame', 'processMbeFrameInternal',
        'nxdn_voice_masked', 'nxdn_frame', '__wrap_dsd_get_dibit_soft_checked', 'dsd_get_dibit_soft_checked')
    assembly = inspect_tool(objdump, '--disassemble-symbols=' + ','.join(named), binary)
    functions, current = {}, None
    for line in assembly.splitlines():
        match = re.match(r'^[0-9a-fA-F]+ <(.+)>:$', line)
        if match: current = match.group(1); functions.setdefault(current, [])
        elif current and re.search(r'\b(?:callq?|jmpq?)\s', line): functions[current].append(line.strip())
    calls = {}
    edges = [('__wrap_' + s, s, True) for s in mbe_symbols] + [
        ('decode_ambe2450_frame', '__wrap_mbe_decodeAmbe3600x2450Frame', False),
        ('decode_ambe2450_frame', '__wrap_mbe_decodeAmbe3600x2450SoftFrame', False),
        ('processMbeFrameInternal', '__wrap_mbe_processAmbe2450Dataf', False),
        ('nxdn_voice_masked', '__wrap_processMbeFrameSoft', False), ('nxdn_voice_masked', '__wrap_processMbeFrame', False),
        ('nxdn_frame', '__wrap_dsd_get_dibit_soft_checked', False),
        ('nxdn_frame', '__wrap_nxdn_voice_masked', False),
        ('__wrap_dsd_get_dibit_soft_checked', 'dsd_get_dibit_soft_checked', True),
        ('dsd_get_dibit_soft_checked', 'dsd_get_symbol_checked', False)]
    for caller, callee, exactly_once in edges:
        rows = [line for line in functions.get(caller, []) if re.search(r'<' + re.escape(callee) + r'>$', line)]
        need(len(rows) == 1 if exactly_once else bool(rows), 'resolved call missing/doubled: ' + caller + ' -> ' + callee)
        calls[caller + ' -> ' + callee] = rows

    radio_units = {}
    radio_obj = objects['symbol']
    for target in ('xerax_availability_symbol_replay_no_radio', 'xerax_availability_symbol_wav_no_radio'):
        obj, command = object_for('dsd_symbol.c', target)
        need('-UUSE_RADIO' in command['command'], 'no-radio undef missing')
        need(digest(obj) != digest(radio_obj), 'radio/noradio objects identical')
        undefined = inspect_tool(nm, '--undefined-only', obj)
        need('rtl_stream_' not in undefined and 'rtl_stream_' in inspect_tool(nm, '--undefined-only', radio_obj), 'radio/no-radio object references do not differ')
        unit_exe = BUILD / (target + '.exe')
        need(unit_exe.is_file(), 'no-radio unit not built')
        symbols = inspect_tool(nm, '--defined-only', unit_exe).splitlines()
        for name in ('getSymbol', 'dsd_get_symbol_checked'):
            need(sum(x.endswith(' ' + name) and ' T ' in x for x in symbols) == 1, 'unit public symbol missing/duplicate')
        unit_map = BUILD / (target + '.map')
        unit_owners = map_owners(unit_map, ('getSymbol', 'dsd_get_symbol_checked')) if unit_map.is_file() else None
        if unit_owners:
            need(all(len(v) == 1 and target + '.dir' in v[0] for v in unit_owners.values()), 'noradio unit extracted radio symbol object')
        radio_units[target] = {'command': command, 'object_sha256': digest(obj), 'binary_sha256': digest(unit_exe),
            'undefined_symbols': undefined.splitlines(), 'mapped_owners': unit_owners}

    sysroot = Path(re.search(r'--sysroot=([^ ]+)', commands[0]['command']).group(1))
    system = Path(os.environ['SystemRoot']) / 'System32'
    search = [BUILD, sysroot / 'bin', INSTALLED / 'bin', system]
    pending, graph, runtime, os_names = [binary], {}, {}, set()
    while pending:
        path = pending.pop().resolve()
        if str(path) in graph: continue
        imports = pe_imports(path); graph[str(path)] = imports
        for name in imports:
            if name.lower().startswith(('api-ms-', 'ext-ms-')): os_names.add(name); continue
            found = next((directory / name for directory in search if (directory / name).is_file()), None)
            need(found is not None, 'unresolved PE import: ' + name)
            if found.parent.resolve() == system.resolve(): os_names.add(name)
            else: found = found.resolve(); runtime[str(found)] = digest(found); pending.append(found)

    built = [c for c in commands if path_for(c, 'output').is_file()]
    deps = set(archives + list(objects.values()))
    deps.update([Path(__file__), parser_path, binary, link_map, BUILD / 'compile_commands.json',
        BUILD / 'CMakeCache.txt', BUILD / 'build.ninja', BUILD / 'CMakeFiles/rules.ninja', BUILD / 'toolchain.cmake'])
    deps.update(path_for(c, 'file') for c in built)
    deps.update(p for p in (BUILD / 'generated').rglob('*') if p.is_file())
    deps.update(p for p in (HERE / 'candidate').rglob('*') if p.is_file())
    deps.update(p for p in (HERE / 'baseline_observer').rglob('*') if p.is_file())
    deps.update(HERE / x for x in ('prepare_build.py', 'CMakeLists.txt', 'tests/acquisition.cmake', 'tests/frame_voice.cmake'))
    deps.update(Path(p) for p in originals)
    deps.update(ROOT / p for group in ('original_sources', 'observation_sources') for p in json.loads((HERE / 'baseline_observer/source-identity.json').read_bytes())[group])
    deps.update(Path(cache[k]) for k in ('CMAKE_C_COMPILER', 'CMAKE_CXX_COMPILER', 'CMAKE_AR', 'CMAKE_LINKER', 'CMAKE_NM', 'CMAKE_OBJDUMP', 'CMAKE_MAKE_PROGRAM', 'CMAKE_TOOLCHAIN_FILE'))
    # Exclude this audit's possible outer Tee log: it is not a build input and
    # may be written by the shell only after this report has been finalized.
    deps.update(p for p in (ROOT / 'build').glob('nxdn-availability-v1-*.log') if 'build-audit' not in p.name)
    deps.update((ROOT / 'build').glob('nxdn-availability-v1-configure*.ps1'))
    deps.update([INSTALLED / 'include/mbelib-neo/mbelib.h', ROOT / 'build/mbelib-voice-words-v1-source.tar.gz',
        ROOT / 'upstream/dsd-neo/vcpkg-ports/mbe-neo/portfile.cmake',
        ROOT / 'docs/research/NXDN-AVAILABILITY-V1-PREREGISTRATION-2026-09-25.md'])
    deps.update(ROOT / 'upstream/dsd-neo/include/dsd-neo/core' / x for x in ('state.h', 'opts.h', 'vocoder.h', 'call_state.h', 'ambe_interleave.h'))
    for target, entry in radio_units.items():
        deps.update([path_for(entry['command'], 'output'), BUILD / (target + '.exe')])
        if (BUILD / (target + '.map')).is_file(): deps.add(BUILD / (target + '.map'))
    need(all(p.is_file() for p in deps), 'audited dependency missing')
    dependencies = {str(p.resolve()): digest(p) for p in sorted(deps)}
    need(digest(binary) == initial_binary, 'binary changed during audit')
    result = {'schema': 1, 'source_and_linkage_pass': True, 'native_execution': False,
        'registration_commit': REGISTRATION, 'baseline_commit': BASELINE,
        'binary_sha256': initial_binary, 'binary_bytes': binary.stat().st_size,
        'configured_translation_units': len(commands), 'existing_built_object_translation_units': len(built),
        'linked_archive_inputs': len(archives), 'dependencies': dependencies, 'runtime_files': runtime,
        'source_identity': identity, 'original_source_hashes': originals, 'normalized_private_diffs': diffs,
        'private_source_inverse_comparison_pass': True, 'map_symbol_owners': owners,
        'mbelib_definition_evidence': definitions, 'private_archive_definitions': private_archive_definitions,
        'critical_compile_commands': selected_commands,
        'object_relocation_evidence': relocations, 'final_resolved_calls': calls,
        'radio_noradio_units': radio_units, 'binary_import_graph': graph,
        'system_runtime_prerequisites': sorted(os_names), 'runtime_search_directories': list(map(str, search)),
        'checks': checks, 'limits': [
            'No receiver or DLL executed/loaded. LLVM tools inspect stored COFF/PE/archive bytes only.',
            'Configured commands are not claimed to be compiled objects; existing objects and selected final map owners are separately checked.',
            'The study runner must freeze/copy the listed runtime closure. Windows system DLLs remain prerequisites.',
            'Source/linkage validation does not establish actual receiver quality, finite-input safety, speech, RF, timing or product readiness.',
            'Mutable runner/checker files require a separate final freeze and are not certified by this build audit.']}
    OUT.with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    OUT.with_suffix('.md').write_text('# NXDN availability v1 independent build audit\n\n'
        'PASS: the seven private candidate files and headers match configured identity; their original product files match the registered baseline Git bytes. '
        'Full normalized private diffs are retained in the machine report. Observation inverses recover the exact candidate frame and frozen recorder sources.\n\n'
        f'Executable SHA-256 `{initial_binary}`; {len(commands)} configured translation units, {len(built)} existing object translation units, '
        f'{len(archives)} explicit linked archive inputs, {len(runtime)} non-system runtime DLLs. '
        'Actual map owners, object relocations and final resolved calls connect checked reader to checked symbol, masked voice to real vocoder, and observation wrappers to the pinned real hard/soft FEC and synthesis routines. '
        'Candidate headers precede upstream headers for private source objects; no old first-sync or boundary policy macro is configured.\n\n'
        'Radio/no-radio unit evidence records actual distinct objects, compile options, undefined symbols, unique public definitions, and per-unit maps when generated. '
        'The audit did not execute any test or receiver. Build/unit failures and corrections remain separate preserved logs; their content is not silently replaced.\n\n'
        'Runtime imports are resolved statically from the declared directories and hashed; OS DLLs remain prerequisites. '
        'These checks establish source/linkage identity and reversible observation, not runtime neutrality, FEC correctness, finite-EOF safety, speech or RF quality.\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('source_and_linkage_pass', 'binary_sha256', 'checks', 'configured_translation_units', 'existing_built_object_translation_units', 'linked_archive_inputs')}, indent=2))

if __name__ == '__main__': main()
