# Independent availability v1 raw-result audit

PASS: 98559 checks; 0 discrepancies. No native execution or frozen checker import.

Report SHA256 `dc6e7ad0f363db329108d29b02c990fbbdd774bd5e26b339f31b8d85c7c8a14c`; source commit `0551423572dc056b6e8d6f10f114e7a77bece193`. All20 distinct processes exited0. The audit rehashed all preserved groups and report files.

Independent gates: `{"complete_baseline_equality_pass": true, "complete_slot_retention_pass": false, "exposure_pass": true, "finite_voice_safety_pass": true, "parity_and_later_call_pass": true, "progression_pass": false, "routing_pass": true, "targeted_guard_pass": true}`. Targeted availability succeeds; overall progression remains a failure.

| Scenario (per invocation) | Frames | FEC / synthesis | Complete / partial / empty body calls | Unsafe routes |
|---|---:|---:|---|---:|
| active_prefix_6159 | 2 | 0 / 0 | 255 / 1 / 108 | 0 |
| active_prefix_6160 | 2 | 1 / 1 | 256 / 0 / 108 | 0 |
| active_prefix_6161 | 2 | 1 / 1 | 256 / 1 / 107 | 0 |
| active_bad_lich | 8 | 12 / 12 | 1282 / 0 / 0 | 0 |
| cold_clean | 9 | 24 / 24 | 1638 / 0 / 0 | 0 |

Totals: `{"FEC": 152, "frames": 92, "hard_FEC": 0, "nested_FEC": 0, "routes": 152, "soft_FEC": 152, "synthesis": 152}`. Independent CRC observations: `{"accepted_supported": 78}`. Actual ERASURE/REPEAT/MUTE masks32/64/128: `{"ERASURE": 8, "MUTE": 0, "REPEAT": 0}`.

At6159, V0 slot0 contains35 complete dibits and19 real samples of its unfinished final dibit; no slot reaches FEC, synthesis or audio/media activity. At6160/6161, slot0 completes before later EOF and is preserved as exact known word0; the next logical call consumes zero/one sample without completing, respectively. Later slots remain unavailable. Every explicit availability bit agrees with the independently observed span and symbol completion, with full per-call numeric pop coverage in detail mode.

The candidate removes all40 previously recorded unavailable-slot synthesis calls across the12 prefix identities. It preserves the two distinct complete early-word cases and all their four detail/chunk versions. Source identity is grounded in canonical per-dibit positions and the pinned known air/channel/49-bit words, not the decoder output. Every actually routed channel matrix and detailed reliability mapping is independently checked.

Full cold clean and bad-LICH common outcomes, stable channel/FEC detail and pop traces match their immutable cached baselines after stripping only added availability telemetry. Bad LICH remains exposed and rejected with no current proof/voice; its known call later terminates at the trailer. It still loses source ordinals2 and3 (words4–11), retaining12/20 eligible words. The unchanged observed search/wrong-frame chronology is retained in JSON; this is a separate acquisition failure, not an availability improvement.

All24 known source occurrences survive the cold clean control. Flags are descriptive vocoder results, not sample-availability evidence or accepted speech. PCM values are not used for source or neutrality proof; no speaker-output, physical-radio, encrypted-call or Android/app claim follows.

Source mechanism: private candidate dsd_symbol.c reports explicit complete-symbol/record status while retaining legacy getSymbol bookkeeping; dsd_dibit.c returns before slicing/capture/ring updates on unavailable input. nxdn_frame.c keeps a local182-entry map, requires complete control ranges and derives an absolute voice-slot mask; nxdn_voice.c skips missing slots before FEC and media/audio copying. The inherited Pulse/headful WAV adapter limitation remains outside this finite discriminator result.

The audit uses only Python standard-library parsing/arithmetic and a separate prior raw auditor as a starting point. No frozen experiment source, gate, input, baseline or binary was changed. The auditor authored the acquisition helper implementation; independence here is from the experiment checker and output-derived truth, not from candidate authorship.
