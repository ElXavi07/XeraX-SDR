"""Describe saved availability results without invoking a receiver or changing gates."""
import collections
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
study = root / 'build/nxdn-availability-v1-run-20260925'
raw = (study / 'report.json').read_bytes()
report = json.loads(raw)
if len(report.get('attempts', [])) != 20 or 'files' not in report:
    raise ValueError('Registered study incomplete')
rows = []
for attempt in report['attempts']:
    a = json.loads((study/'runs'/attempt['id']/str(attempt['observed'])/'audit.json').read_bytes())['audit']
    events = [json.loads(line) for line in (study/'runs'/attempt['id']/str(attempt['observed'])/'events.jsonl').read_bytes().splitlines()]
    flags = dict(collections.Counter(str(e['result_after']['flags']) for e in events if e['kind']=='synthesis'))
    rows.append({'id': attempt['id'], 'detail': attempt['observed'],
        'gates': {k:v for k,v in a.items() if k.endswith('_pass')},
        'summary': a['summary'], 'source_occurrences': a['source_occurrences'],
        'baseline_equal': a['complete_input_baseline_equal'],
        'unsafe_synthesis': a['unsafe_synthesis'], 'flags': flags,
        'guard_issues': a['guard_issues'], 'retention_issues': a['retention_issues'],
        'frames': [{'source':f['source'], 'lich_source':f['lich_source'],
                    'classes':dict(collections.Counter(f['classes'])),
                    'begin':f['begin'], 'end':f['end'], 'routes':len(f['routes'])} for f in a['frames']]})
before = json.loads((study/'before-execution.json').read_bytes())
out = {'report_sha256': hashlib.sha256(raw).hexdigest(), 'comparison':report['comparison'],
       'preservation_pass':report['preservation_pass'],
       'groups':{k:len(v) for k,v in before.items() if isinstance(v,dict)},
       'report_files':len(report['files']), 'invocations':rows}
(root/'build/nxdn-availability-v1-summary.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='invocations'},indent=2))
for r in rows:
    if r['detail']==1 and r['id'].endswith('c37'):
        print(json.dumps({'id':r['id'],'gates':r['gates'],'fec':r['summary']['fec_soft_calls'],
                         'synthesis':r['summary']['synthesis_calls'], 'baseline_equal':r['baseline_equal'],
                         'source_exact':sum(v['exact'] for v in r['source_occurrences']),
                         'unsafe':r['unsafe_synthesis'],'flags':r['flags']}))
