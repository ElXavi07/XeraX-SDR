"""Audit saved availability candidate observations; no experiment/encoder imports or native calls."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
STUDY = ROOT / 'build/nxdn-availability-v1-run-20260925'
OUT = ROOT / 'build/nxdn-availability-v1-results-audit'
NAMES = ('active_prefix_6159', 'active_prefix_6160', 'active_prefix_6161', 'active_bad_lich', 'cold_clean')
OPTIONAL = {'crc', 'lich', 'scch', 'voice_begin', 'voice_end', 'mbe_begin', 'mbe_end', 'audio_begin', 'audio_end', 'fec_input'}
failures = []
checks = 0


def check(ok, why):
    global checks
    checks += 1
    if not ok: failures.append(why)


def need(ok, why):
    if not ok: raise ValueError(why)


def sha(raw): return hashlib.sha256(raw).hexdigest()


def parse(raw):
    def unique(pairs):
        out = {}
        for k, v in pairs:
            need(k not in out, 'Duplicate JSON key ' + k); out[k] = v
        return out
    def nonfinite(value): raise ValueError('Nonfinite JSON ' + value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=nonfinite)


def bits(raw): return ''.join(f'{b:08b}' for b in raw)


def crc(info, width):
    value = (1 << width) - 1
    for bit in info:
        carry = (value >> (width - 1)) ^ int(bit)
        value = (value << 1) & ((1 << width) - 1)
        if carry & 1: value ^= {6: 0x27, 12: 0x80f}[width]
    return value


def decode_whitening(body, seed):
    register = seed or 228
    out = []
    for d in body:
        out.append(int(d) ^ ((register & 1) << 1))
        register = (register >> 1) | (((register ^ (register >> 4)) & 1) << 8)
    return out


def oracle():
    base = STUDY / 'inputs/active/parent/reference'
    raw = (base / 'linked-source.bin').read_bytes()
    need(sha(raw) == '8f4116e67a4c950a524c8568caf17d550e9b0b0bbdac3f9e3761ce76c0056e41', 'Source word identity')
    words = []
    for n in range(0, 130, 13):
        pair = bits(raw[n:n+13]); words.extend((pair[:49], pair[49:98]))
    records = (base / 'primary.records96').read_bytes()
    packed = (base / 'input.records41').read_bytes()
    channels = (base / 'voice-reference.channels9').read_bytes()
    need(sha(records) == 'bedb3ae824c357e68e8d2883b808b357e228e74c7ce253acf0a41cf257234c0b', 'AIR reference identity')
    need(sha(packed) == '74c0fd60a05624623157f82598cf20ad9da7f9ea86a957b396933672f5efcaab', 'Input record identity')
    need(sha(channels) == '05ed6f2d7c548e6b6e94e81bb12534afde0c2e13301791a8f1d4d2778dd6eed3', 'Channel reference identity')
    frames = []
    for n in range(9):
        rec = packed[n*41:(n+1)*41]; air = records[n*96+48:(n+1)*96]
        slots = {} if n in (0,8) else {2:2,3:3} if n == 6 else {0:4,1:5} if n == 7 else {s:4*(n-1)+s for s in range(4)}
        frames.append({'ordinal': n, 'start': 640+3840*n, 'slots': slots,
                       'air_dibits': [(b >> shift)&3 for b in air for shift in (6,4,2,0)],
                       'lich': rec[0], 'sacch': bits(rec[1:5])[:26], 'facch': bits(rec[5:15])})
    return frames, words, [bits(channels[n*9:(n+1)*9]) for n in range(20)]


def complete(call):
    return (call['eof_before'] == call['eof_after'] == 0 and call['after']-call['before'] == 20
            and ((call['symbol_after']-call['symbol_before']) & 0xffffffff) == 1)


def identify(frame, indices, truth):
    calls = frame['end']['body_calls']
    if frame['begin']['sync'] != 28 or any(i >= len(calls) or not complete(calls[i]) for i in indices): return None
    found = []
    for source in truth:
        deviations = [calls[i]['after'] - (source['start'] + 20*(11+i)) for i in indices]
        if all(-20 < d < 20 for d in deviations): found.append((source['ordinal'], min(deviations), max(deviations)))
    need(len(found) <= 1, 'Ambiguous source interval')
    return found[0] if found else None


def clear(call):
    return call is not None and tuple(call[k] for k in ('phase','kind','source','target','crypto','algid','kid','audio_permitted')) == (1,2,901,1201,1,0,0,1)


def semantics(rows, chunk=False):
    ignore = {'seq','frontier','pops','observed','crcs','skipped'}
    if chunk: ignore |= {'provided','cache_pos','cache_len','read_start','chunk'}
    return [{k:v for k,v in r.items() if k not in ignore} for r in rows if r['kind'] not in OPTIONAL]


def inspect(rows, trace, scenario, chunk, mode, samples, truth, words, channels):
    tag = f'{scenario}-c{chunk}/{mode}'
    def test(ok, why): check(ok, tag+':'+why)
    test([r['seq'] for r in rows] == list(range(len(rows))), 'sequence')
    test(rows[0]['kind']=='configuration' and rows[-1]['kind']=='summary', 'stream bounds')
    summary = rows[-1]
    test((summary['fast'],summary['chunk'],summary['observed'],summary['samples']) == (1,chunk,mode,samples), 'invocation identity')
    test(summary['errors']==summary['starts']==summary['tunes']==0 and summary['eof']==1, 'native error/boundaries')
    config=rows[0]
    test(all(config.get(k)==v for k,v in {'availability_schema':1,'routing_schema':1,'observation_schema':2,
        'datascope':0,'audio_out':0,'cosine_filter':0,'scanner':0,'trunk':0,'trunk_scan':0,
        'voice_gate':0,'visit_ms':0,'msize':1,'ssize':128,'nxdn48':1,'search_enabled':0,
        'initial_manual_key':0,'initial_forced_cipher':0,'initial_cipher':0,'initial_keyloader':0,
        'initial_aes_key_loaded':0,'pulse_digi_rate_out':8000,'floating_point':0,'dmr_stereo':1}.items()),'fixed clear finite profile')
    for row in rows:
        if 'call' in row and row['call']:
            call=row['call']
            test((call['protocol'],call['kind'],call['source'],call['target'],call['policy_target'],call['crypto'],call['algid'],call['kid'])
                 ==(28,2,901,1201,1201,1,0,0),'known clear call metadata')
        for key in ('cipher','manual_key','forced_cipher','keyloader','search_ready','search_applied'):
            if key in row: test(row[key]==0,'unexpected key/search state:'+key)
    for kind,key in [('reset_begin','resets'),('crc','crcs'),('lich','v2_lich_events'),('scch','v2_scch_events'),
                     ('voice_begin','v2_voice_calls'),('mbe_begin','v2_mbe_calls'),('audio_begin','v2_audio_calls')]:
        if mode or kind=='reset_begin': test(sum(r['kind']==kind for r in rows)==summary[key],kind+' total')
    pop_ids = list(struct.unpack('<'+'I'*(len(trace)//4), trace)) if len(trace)%4 == 0 else None
    test(pop_ids == (list(range(samples)) if mode else []), 'exact real sample ownership trace')
    test(summary['skipped']==0 and summary['pops']==(samples if mode else 0), 'pop accounting')
    if not mode: test(not any(r['kind'] in OPTIONAL for r in rows), 'detail leaked into off mode')
    frames=[]; active=None
    for r in rows:
        if r['kind']=='frame_begin':
            need(active is None, tag+':nested frame'); active={'begin':r,'events':[]}
        elif r['kind']=='frame_end':
            need(active is not None, tag+':unowned frame end'); active['end']=r;frames.append(active);active=None
        elif active is not None:active['events'].append(r)
    test(active is None and len(frames)==summary['frames']==summary['dispatches'], 'frame totals')
    call_classes=Counter(); slot_records=[]; frame_records=[]; crc_records=[]; quality=[]
    all_fec=[];all_synth=[];actual_occurrences=[];missing=[];unsafe=[];source_frame_map={}
    for f in frames:
        e=f['end']; fid=f['begin']['frame']; calls=e['body_calls']; body=e['body']; previous=None
        test(len(calls)==len(body)==len(e['body_positions'])==e['body_count'], 'body dimensions')
        for i,c in enumerate(calls):
            test(0 <= c['before'] <= c['after'] <= samples, 'body frontier')
            if previous is not None:test((c['before'],c['eof_before'],c['symbol_before'])==previous, 'body call chain')
            previous=(c['after'],c['eof_after'],c['symbol_after'])
            if complete(c): label='complete'
            else:
                test(c['eof_after']==1 and c['after']==samples and c['symbol_before']==c['symbol_after']
                     and 0<=c['after']-c['before']<20, 'invalid partial/empty call')
                label='already_eof' if c['eof_before'] else 'crossing_partial' if c['after']>c['before'] else 'crossing_empty'
                if c['eof_before']:test(c['before']==c['after'], 'new delivery after EOF')
            call_classes[label]+=1
            test(type(c.get('available')) is int and c['available']==int(label=='complete'),'explicit checked-read availability')
            if label!='complete': test(body[i]=='0','unavailable checked output not initialized')
            test(e['body_positions'][i] == (c['after'] if label=='complete' else 0), 'unavailable position exposed')
            if mode:
                test(pop_ids[c['before']:c['after']]==list(range(c['before'],c['after'])), 'call lacks pop interval')
        loc=identify(f,range(8),truth); ordinal=loc[0] if loc else None
        if ordinal is not None:
            test(ordinal not in source_frame_map, 'duplicate source frame'); source_frame_map[ordinal]=f
        target=truth[ordinal] if ordinal is not None else None
        bad=bool(scenario=='active_bad_lich' and ordinal==1)
        if target:
            supplied=list(target['air_dibits'])
            if bad:supplied[17]^=2
            for i,c in enumerate(calls):
                if complete(c) and int(body[i])!=supplied[10+i]: quality.append({'reason':'supplied_dibit_mismatch','frame':fid,'index':i})
        plain_lich=decode_whitening(body[:8],f['begin']['pn95'])
        observed_lich=[r for r in f['events'] if r['kind']=='lich']
        if mode:
            test(len(observed_lich)==1 and len(plain_lich)==8,'one real LICH decision')
            full=sum((d>>1)<<(7-i) for i,d in enumerate(plain_lich))
            parity=sum((full>>i)&1 for i in range(1 if full>>1 in (8,0x4a,0x48,0x46) else 4,8))&1
            for row in observed_lich:
                test((row['full_lich'],row['lich'],row['parity_received'],row['parity_computed'])==(full,full>>1,full&1,parity),'LICH arithmetic')
                test(not row['result'] or full&1==parity,'accepted LICH parity')
                test(row['frontier']==calls[7]['after'] and row['symbolcnt']==calls[7]['symbol_after'],'LICH observation location')
        for event in f['events']:
            if event['kind']=='crc':
                width=6 if event['channel']==1 else 12
                computed=crc(event['bits'],width); received=event['received']
                test(type(received) is int and 0<=received<(1<<width),'received CRC range')
                test(computed==event['computed'] and received==event['received'], 'CRC arithmetic/received field')
                test(not event['soft_pass'] or computed==received, 'contradictory soft CRC pass')
                owned_indices=range(8,38) if width==6 else range(38,110) if event['part'] in (0,1) else range(110,182)
                channel_loc=identify(f,owned_indices,truth)
                supported=bool(target and channel_loc and channel_loc[0]==ordinal
                               and event['bits']==target['sacch' if width==6 else 'facch']
                               and received==computed==crc(target['sacch' if width==6 else 'facch'],width))
                crc_records.append({'frame':fid,'source':ordinal,'channel':event['channel'],'part':event['part'],
                                    'accepted':computed==received,'full_source_support':supported})
                if computed==received and not supported:quality.append({'reason':'accepted_CRC_without_complete_known_channel','frame':fid})
        if mode and e['value']==2:
            if not any(r['frame']==fid and r['accepted'] and r['full_source_support'] for r in crc_records):
                quality.append({'reason':'current_proof_not_supported_by_available_known_channel','frame':fid})
        routes=[]; route=None
        for r in f['events']:
            k=r['kind']
            if k=='route_begin':need(route is None,'nested route');route={'begin':r,'fec':[],'synthesis':[],'inputs':[]}
            elif k=='route_end':
                need(route is not None,'unowned route end');route['end']=r;routes.append(route);route=None
            elif k in ('fec','synthesis','fec_input'):
                need(route is not None,'unowned API observation');test(r['route_id']==route['begin']['route_id'],'API route ID')
                route[{'fec':'fec','synthesis':'synthesis','fec_input':'inputs'}[k]].append(r)
        test(route is None,'unfinished route')
        plain=decode_whitening(body,f['begin']['pn95'])
        for route in routes:
            b=route['begin'];slot=b['slot'];indices=list(range(38+36*slot,74+36*slot))
            full=all(i<len(calls) and complete(calls[i]) for i in indices)
            selected={1:(0,1),2:(2,3),3:(0,1,2,3)}.get(b['voice'],())
            expected_mask=sum(1<<slot for slot in selected if all(i<len(calls) and complete(calls[i])
                                for i in range(38+36*slot,74+36*slot)))
            test(b.get('available_slots')==route['end'].get('available_slots')==expected_mask,'actual complete-slot mask')
            if not full or slot not in selected or not(expected_mask&(1<<slot)):
                quality.append({'reason':'unavailable_or_unselected_route','frame':fid,'slot':slot})
            slot_loc=identify(f,list(range(8))+indices,truth)
            source_id=target['slots'].get(slot) if target else None
            outer=[r for r in route['fec'] if r['outer']]; synth=route['synthesis']
            all_fec.extend(route['fec']);all_synth.extend(synth)
            test(b['confirmed']==1,'unconfirmed route')
            test(route['end']['route_id']==b['route_id'] and route['end']['slot']==slot,'route identity continuity')
            test(b['fec_outer']==b['syntheses']==0,'clean route counters')
            test(route['end']['fec_outer']==len(outer) and route['end']['syntheses']==len(synth),'route completion counters')
            test(clear(b.get('call')),'clear call owns routed word')
            for r in synth:
                prior=[fec for fec in outer if fec['seq']<r['seq'] and fec['status']>=0 and fec['bits49']==r['input49']]
                test(len(prior)==1,'synthesis consumes own initialized FEC result')
            for r in route['fec']:
                test(r['input_unchanged']==1,'FEC mutated input')
                test((r['bits49'] is None and r['result'] is None) if r['status']<0 else isinstance(r['bits49'],str) and len(r['bits49'])==49 and r['result'] is not None,'FEC status/output contract')
            for r in synth:
                test(r['input_unchanged']==1,'synthesis mutated input')
                test(r['result_after'] is None if r['status']<0 else r['result_after'] is not None,'synthesis negative-result contract')
            actual_channel=''.join(f'{d:02b}' for d in plain[indices[0]:indices[-1]+1])
            if mode:
                inputs=[r for r in route['inputs'] if r['outer']]
                test(len(inputs)==len(outer),'detailed FEC input count')
                for r in inputs:
                    test(r['channel72']==actual_channel,'actual supplied matrix channel')
                    expected=['0']*96
                    for p,bit in enumerate(actual_channel):
                        k=18*(p%4)+p//4
                        rr,cc=(0,23-k) if k<24 else (1,46-k) if k<47 else (2,57-k) if k<58 else (3,71-k)
                        expected[24*rr+cc]=bit
                    test(r['matrix96']==''.join(expected),'actual 96-cell FEC matrix')
                    test(r['channel_dibits']==''.join(map(str,plain[indices[0]:indices[-1]+1])),'actual dibit matrix input')
                    reliability=r['channel_reliability']; matrix_reliability=[0]*96
                    test(len(reliability)==36 and all(type(v) is int and 0<=v<=255 for v in reliability),'channel reliability dimensions')
                    for p in range(72):
                        k=18*(p%4)+p//4
                        rr,cc=(0,23-k) if k<24 else (1,46-k) if k<47 else (2,57-k) if k<58 else (3,71-k)
                        matrix_reliability[24*rr+cc]=reliability[p//2]
                    test(r['reliability']==(matrix_reliability if r['mode']=='soft' else None),'matrix reliability mapping')
            known=bool(slot_loc and source_id is not None and not bad)
            exact=bool(known and actual_channel==channels[source_id] and len(outer)==len(synth)==1
                       and outer[0]['status']>=0 and outer[0]['bits49']==words[source_id]
                       and synth[0]['input49']==words[source_id])
            if known:
                actual_occurrences.append((ordinal,slot,source_id))
                if not exact:quality.append({'reason':'complete_source_bits_or_route_mismatch','source':ordinal,'slot':slot})
            if synth and not full:unsafe.append({'frame':fid,'source':ordinal,'slot':slot,'route_id':b['route_id'],
                'complete_dibits':sum(i<len(calls) and complete(calls[i]) for i in indices),'synthesis_calls':len(synth)})
            if bad and route['fec']+synth:quality.append({'reason':'rejected_source_has_API_call','frame':fid})
            slot_records.append({'frame':fid,'source':ordinal,'slot':slot,'route_id':b['route_id'],'source_word':source_id,
                'complete_dibits':sum(i<len(calls) and complete(calls[i]) for i in indices),'fully_available':full,
                'source_owned':known,'exact_complete_source_route':exact,'fec_count':len(route['fec']),
                'synthesis_count':len(synth),'fec_statuses':[r['status'] for r in route['fec']],
                'synthesis_statuses':[r['status'] for r in synth],
                'fec_bits49':[r['bits49'] for r in outer],'synthesis_inputs49':[r['input49'] for r in synth],
                'diagnostic_source_bit_differences':[[i for i,(a,z) in enumerate(zip(words[source_id],r['bits49'])) if a!=z]
                    if source_id is not None and r['bits49'] is not None else None for r in outer],
                'synthesis_flags':[r['result_after']['flags'] if r['result_after'] else None for r in synth]})
        if target and not bad:
            for slot,sid in target['slots'].items():
                loc_slot=identify(f,list(range(8))+list(range(38+36*slot,74+36*slot)),truth)
                if loc_slot:
                    count=sum(r['begin']['slot']==slot for r in routes)
                    if count!=1:missing.append({'source':ordinal,'slot':slot,'source_word':sid,'routes':count})
        lich=[r for r in f['events'] if r['kind']=='lich']
        frame_records.append({'frame':fid,'source':ordinal,'phase':list(loc[1:]) if loc else None,
            'body_count':len(calls),'complete_calls':sum(map(complete,calls)),'result':e['value'],'confirmed':e['confirmed'],
            'begin_sample':calls[0]['before'] if calls else None,'end_sample':calls[-1]['after'] if calls else None,
            'first_unavailable_call':next(({'body_index':i,**c} for i,c in enumerate(calls) if not complete(c)),None),
            'evidence':e['evidence'],'proved':e['proved'],'call':e.get('call'),'ran':e['ran'],
            'audio_indices_before':f['begin']['audio_indices'],'audio_indices_after':e['audio_indices'],
            'voice_calls':sum(r['kind']=='voice_begin' for r in f['events']),
            'audio_calls':sum(r['kind']=='audio_begin' for r in f['events']),
            'lich':[{k:r[k] for k in ('reason','result','full_lich','parity_received','parity_computed')} for r in lich],
            'routes':len(routes)})
    test(len(all_fec)==summary['fec_soft_calls']+summary['fec_hard_calls'],'FEC total')
    test(len(all_synth)==summary['synthesis_calls'] and len(slot_records)==summary['route_words'],'route/synthesis total')
    test(len(actual_occurrences)==len(set(actual_occurrences)),'duplicate source occurrence')
    header=next((f for f in frame_records if f['source']==0),None)
    v0=next((f for f in frame_records if f['source']==1),None)
    header_ok=bool(header and header['body_count']==header['complete_calls']==182 and header['result']==2 and clear(header['call']))
    prefix=scenario.startswith('active_prefix_')
    if prefix:
        expected=[(f['ordinal'],slot,sid) for f in truth for slot,sid in f['slots'].items()
                  if f['ordinal'] in source_frame_map and identify(source_frame_map[f['ordinal']],
                    list(range(8))+list(range(38+36*slot,74+36*slot)),truth)]
        v0_ok=bool(v0 and v0['body_count']==182 and v0['complete_calls']<182 and v0['confirmed']==1)
        if mode:v0_ok=bool(v0_ok and v0['lich'] and v0['lich'][0]['reason']=='accepted')
        retention=not missing and all(r['exact_complete_source_route'] for r in slot_records if r['source_owned'])
        parity=True
        trailer=None
    elif scenario=='cold_clean':
        v0_ok=bool(v0 and v0['body_count']==v0['complete_calls']==182 and v0['routes']==4)
        expected=[(f['ordinal'],slot,sid) for f in truth for slot,sid in f['slots'].items()]
        retention=actual_occurrences==expected and all(r['exact_complete_source_route'] for r in slot_records)
        trailer=next((f for f in frame_records if f['source']==8),None)
        call=trailer['call'] if trailer else None
        parity=bool(trailer and trailer['result']==2 and header_ok and call and
            tuple(call[k] for k in ('epoch','phase','end_reason','media_active','audio_permitted'))==(header['call']['epoch'],2,3,0,0))
    else:
        v0_ok=bool(v0 and v0['body_count']==v0['complete_calls']==8 and v0['evidence']==v0['proved']==0)
        if mode:v0_ok=bool(v0_ok and v0['lich']==[{'reason':'parity_reject','result':0,'full_lich':175,'parity_received':1,'parity_computed':0}])
        parity=bool(v0_ok and v0['routes']==0)
        expected=[(f['ordinal'],slot,sid) for f in truth[2:] for slot,sid in f['slots'].items()]
        retention=actual_occurrences==expected and all(r['exact_complete_source_route'] for r in slot_records)
        trailer=next((f for f in frame_records if f['source']==8),None)
        call=trailer['call'] if trailer else None
        parity=bool(parity and header_ok and call and tuple(call[k] for k in ('epoch','phase','end_reason','media_active','audio_permitted'))==(header['call']['epoch'],2,3,0,0))
        for f in frame_records:
            if f['source'] is not None and 2<=f['source']<=7:
                parity=bool(parity and clear(f['call']) and f['call']['epoch']==header['call']['epoch'])
    if prefix:
        expected_routes=0 if scenario.endswith('6159') else 1
        test(len(all_fec)==len(all_synth)==len(slot_records)==expected_routes,'registered available-prefix word count')
        if expected_routes==0:
            test(v0['call']['media_active']==0 and v0['audio_indices_before']==v0['audio_indices_after'],'zero-slot frame activity unchanged')
            test(summary['v2_voice_calls']==summary['v2_mbe_calls']==summary['v2_audio_calls']==0,'zero-slot frame has no voice/audio call')
        else:
            test([r['source_word'] for r in slot_records]==[0] and all(r['exact_complete_source_route'] for r in slot_records),'complete early source word retained')
    test([r['call_id'] for r in all_fec]==list(range(len(all_fec))),'FEC serial identities')
    test([r['call_id'] for r in all_synth]==list(range(len(all_synth))),'synthesis serial identities')
    test([r['route_id'] for r in slot_records]==list(range(len(slot_records))) if all('route_id' in r for r in slot_records) else True,'route serial identities')
    flags=Counter(r['result_after']['flags'] for r in all_synth if r['result_after'] is not None)
    return {'exposure_pass':header_ok and v0_ok,'finite_voice_safety_pass':not unsafe,
        'complete_slot_retention_pass':retention,'parity_and_later_call_pass':parity,
        'frames':frame_records,'slots':slot_records,'CRCs':crc_records,'missing_complete_slots':missing,
        'unsafe_synthesis':unsafe,'quality_observations':quality,'source_occurrences':actual_occurrences,
        'expected_complete_occurrences':expected,'missing_source_occurrences':[x for x in expected if x not in actual_occurrences],
        'sync_and_frame_chronology':[{k:r[k] for k in ('seq','kind','frame','value','last_sync','sync','confirmed','evidence','proved') if k in r}
            | {'sample':samples if r['eof'] else r.get('read_start',0)+r.get('cache_pos',0)}
            for r in rows if r['kind'] in ('search_begin','search_end','frame_begin','frame_end','reset_begin','reset_end')],
        'call_classes':dict(call_classes),'counts':{'frames':len(frames),'routes':len(slot_records),'FEC':len(all_fec),
        'soft_FEC':sum(r['mode']=='soft' for r in all_fec),'hard_FEC':sum(r['mode']=='hard' for r in all_fec),
        'nested_FEC':sum(not r['outer'] for r in all_fec),'synthesis':len(all_synth)},
        'synthesis_flag_histogram':dict(flags),'flag_counts':{name:sum(n for f,n in flags.items() if f&mask)
        for name,mask in [('ERASURE',32),('REPEAT',64),('MUTE',128)]},
        'fec_status_histogram':dict(Counter(r['status'] for r in all_fec)),
        'synthesis_status_histogram':dict(Counter(r['status'] for r in all_synth)),
        '_common':semantics(rows),'_chunk':semantics(rows,True),'trace_sha256':sha(trace)}



def without_availability(rows):
    out=[]
    for row in rows:
        r={k:v for k,v in row.items() if k not in ('availability_schema','available_slots')}
        if 'body_calls' in r:
            r['body_calls']=[{k:v for k,v in c.items() if k!='available'} for c in r['body_calls']]
        out.append(r)
    return out


def baseline_unavailable_synthesis(rows):
    ends={r['frame']:r for r in rows if r['kind']=='frame_end'}
    slots={r['route_id']:(r['frame'],r['slot']) for r in rows if r['kind']=='route_begin'}
    missing=[]
    for row in rows:
        if row['kind']!='synthesis':continue
        frame,slot=slots[row['route_id']]; calls=ends[frame]['body_calls']
        if not all(i<len(calls) and complete(calls[i]) for i in range(38+36*slot,74+36*slot)):
            missing.append({'frame':frame,'slot':slot,'status':row['status'],
                            'flags':row['result_after']['flags'] if row['result_after'] else None})
    return missing


def main():
    report_raw=(STUDY/'report.json').read_bytes();report=parse(report_raw)
    need(len(report.get('attempts',[]))==20 and 'files' in report and 'preservation_pass' in report,'Await completed once-only study')
    need(sha(report_raw)=='dc6e7ad0f363db329108d29b02c990fbbdd774bd5e26b339f31b8d85c7c8a14c','Final registered report identity')
    before=parse((STUDY/'before-execution.json').read_bytes());manifest=parse((STUDY/'inputs/manifest.json').read_bytes())
    need(before['commit']=='0551423572dc056b6e8d6f10f114e7a77bece193','Frozen candidate commit')
    need(sha((STUDY/'inputs/manifest.json').read_bytes())=='d42a311b1367b0a200dd3c52ab0aaa3bfd292a429785a9ac534ee54348dad98c','Copied input pin')
    group_counts={}; hashed={}
    def filehash(path):
        p=Path(path).resolve();stat=p.stat();key=(str(p),stat.st_size,stat.st_mtime_ns)
        if key not in hashed:hashed[key]=sha(p.read_bytes())
        return hashed[key]
    for group in ('frozen_files','original_files','copied_identities','configured_sources','protected'):
        group_counts[group]=len(before[group])
        for path,expected in before[group].items():check(Path(path).is_file() and filehash(path)==expected,'preservation:'+path)
    for name,expected in report['files'].items():check(filehash(STUDY/name)==expected,'report file:'+name)
    binary=STUDY/'frozen/engine.exe'
    check(filehash(binary)==before['binary_sha256']=='788c655cf616ea53804f8bd70d174e42b7038a173f8a0aaf514fc2ccb47f599d','Exact private candidate binary')
    check(before['baseline_receiver_rerun'] is False and before['native_invocations_registered']==20,'No baseline rerun identity')
    build_audit=parse((STUDY/'frozen/nxdn-availability-v1-build-audit.json').read_bytes())
    check(build_audit['source_and_linkage_pass'] and build_audit['binary_sha256']==before['binary_sha256'],'Preserved build audit binds actual binary')
    for path,digest in build_audit['runtime_files'].items():
        check(filehash(STUDY/'frozen'/Path(path).name)==digest,'Copied runtime:'+Path(path).name)
    wanted={(f'{name}-c{chunk}',mode) for name in NAMES for chunk in (37,512) for mode in (0,1)}
    check(len(report['attempts'])==20 and {(r['id'],r['observed']) for r in report['attempts']}==wanted,'20 distinct recorded attempts')
    check(all(r['exit_code']==0 for r in report['attempts']),'20 recorded zero exits')
    check(len(list((STUDY/'runs').glob('*/*/invocation.json')))==20,'No extra invocation record')
    truth,words,channels=oracle()
    # Source controls/voice bits come from the pinned AIR/voice reference, never
    # from current decoder output. All registered maps preserve original indices.
    source_base=STUDY/'inputs/active/parent/vectors'
    for source in truth:
        vector=(source_base/f"r{source['ordinal']}.dibits").read_bytes()
        check(list(vector)==source['air_dibits'],'Agreed numeric vector:'+str(source['ordinal']))
    bad=list(truth[1]['air_dibits']);bad[17]^=2
    check(list((source_base/'r1_bad_lich.dibits').read_bytes())==bad,'Only registered LICH parity dibit changed')
    for name in NAMES:
        wave=manifest['waveforms'][name];sample_count=wave['samples']
        raw=(STUDY/'inputs'/wave['file']).read_bytes()
        check(len(raw)==4*sample_count and sha(raw)==wave['sha256'],'Unchanged finite waveform:'+name)
        for field in ('lineage','occurrence'):
            data=(STUDY/'inputs'/wave[field+'_file']).read_bytes()
            check(len(data)==4*sample_count and sha(data)==wave[field+'_sha256'],'Map identity:'+name+field)
            values=struct.unpack('<'+'I'*sample_count,data)
            check(values==tuple(range(sample_count)) if field=='lineage' else not any(values),'Original sample mapping:'+name+field)
        for source in wave['frames']:
            check((source['ordinal'],source['source_frame'],source['start'],source['end'])==
                  (source['ordinal'],source['ordinal'],640+3840*source['ordinal'],4480+3840*source['ordinal']),
                  'Canonical frame coordinates:'+name)
    cases={};baseline_differences=[];baseline_removed=0;baseline_unsafe=[]
    for name in NAMES:
        samples=manifest['waveforms'][name]['samples']
        for chunk in (37,512):
            cid=f'{name}-c{chunk}'
            for mode in (0,1):
                ident=cid+'/'+str(mode);folder=STUDY/'runs'/cid/str(mode)
                invocation=parse((folder/'invocation.json').read_bytes());args=invocation['arguments']
                check(args[2:5]==['1',str(chunk),str(mode)] and Path(args[0]).resolve()==binary.resolve(),'Exact CLI:'+ident)
                check(Path(args[1]).resolve()==(STUDY/'inputs'/manifest['waveforms'][name]['file']).resolve()
                      and Path(args[5]).resolve()==(folder/'pops.u32le').resolve(),'Actual supplied input/trace:'+ident)
                check(invocation['timeout_seconds']==60 and invocation['dsd_environment_removed'] is True,'Launch contract:'+ident)
                check(parse((folder/'process.json').read_bytes())=={'exit_code':0},'Process exit:'+ident)
                rows=[parse(line) for line in (folder/'events.jsonl').read_bytes().splitlines()]
                trace=(folder/'pops.u32le').read_bytes()
                result=inspect(rows,trace,name,chunk,mode,samples,truth,words,channels)
                baseline=(STUDY/'inputs/active/anchors'/f'cold_fast-c{chunk}'/str(mode) if name=='cold_clean'
                          else STUDY/'inputs/baseline-active'/cid/str(mode))
                old_rows=[parse(line) for line in (baseline/'events.jsonl').read_bytes().splitlines()]
                check(trace==(baseline/'pops.u32le').read_bytes(),'Unchanged real sample trace:'+ident)
                old_calls=[r['body_calls'] for r in old_rows if r['kind']=='frame_end']
                current_calls=[r['body_calls'] for r in without_availability(rows) if r['kind']=='frame_end']
                check(current_calls==old_calls,'Same logical per-call sample consumption:'+ident)
                if name in ('cold_clean','active_bad_lich'):
                    equal=semantics(without_availability(rows))==semantics(old_rows)
                    result['complete_input_baseline_equal']=equal
                    check(equal,'Complete-input cached common equality:'+ident)
                    detailed={'crc','lich','scch','fec_input','voice_begin','voice_end','mbe_begin','mbe_end'}
                    ignore={'seq','frontier','pops','observed','crcs','skipped'}
                    stable=lambda rs:[{k:v for k,v in r.items() if k not in ignore} for r in rs if r['kind'] in detailed]
                    detail_equal=stable(without_availability(rows))==stable(old_rows)
                    result['complete_input_detail_equal']=detail_equal
                    check(detail_equal,'Complete-input cached stable detail equality:'+ident)
                    if not equal or not detail_equal:baseline_differences.append(ident)
                else:
                    removed=baseline_unavailable_synthesis(old_rows)
                    baseline_removed+=len(removed)
                    baseline_unsafe.extend({'id':ident,**v} for v in removed)
                    result['baseline_unavailable_synthesis']=removed
                cases[ident]=result
    for name in NAMES:
        for chunk in (37,512):
            a,b=[cases[f'{name}-c{chunk}/{m}'] for m in (0,1)]
            check(a['_common']==b['_common'],'Callback neutrality:'+name+str(chunk))
        for mode in (0,1):
            a,b=[cases[f'{name}-c{c}/{mode}'] for c in (37,512)]
            check(a['_chunk']==b['_chunk'] and a['trace_sha256']==b['trace_sha256'],'Chunk neutrality:'+name+str(mode))
    independent={k:all(v[k] for v in cases.values()) for k in
                 ('exposure_pass','finite_voice_safety_pass','complete_slot_retention_pass','parity_and_later_call_pass')}
    independent['routing_pass']=not any(v['quality_observations'] for v in cases.values())
    independent['complete_baseline_equality_pass']=not baseline_differences
    independent['targeted_guard_pass']=independent['exposure_pass'] and independent['finite_voice_safety_pass'] and independent['routing_pass'] and independent['parity_and_later_call_pass'] and not baseline_differences and all(v['complete_slot_retention_pass'] for k,v in cases.items() if not k.startswith('active_bad_lich'))
    independent['progression_pass']=all(independent.values())
    check(report['measurement_pass'] is True and report['preservation_pass'] is True,'Recorded measurement/preservation')
    check(report['targeted_guard_pass']==independent['targeted_guard_pass'],'Independent target guard agrees')
    check(report['progression_pass']==independent['progression_pass'],'Independent overall quality agrees')
    totals=Counter();calls=Counter();flags=Counter();unsafe=0;crcs=Counter();statuses=Counter()
    for value in cases.values():
        totals.update(value['counts']);calls.update(value['call_classes']);flags.update(value['flag_counts'])
        unsafe+=len(value['unsafe_synthesis'])
        for observation in value['CRCs']:crcs.update({('accepted_supported' if observation['accepted'] and observation['full_source_support'] else 'other'):1})
        statuses.update(value['fec_status_histogram'])
        del value['_common'];del value['_chunk']
    check(baseline_removed==40,'All forty prior unavailable synthesis calls absent from candidate scope')
    check(unsafe==0,'No candidate unavailable synthesis')
    result={'schema':1,'audit_pass':not failures,'native_execution':False,'experiment_modules_imported':False,
        'checks':checks,'failures':failures,'report_sha256':sha(report_raw),'auditor_sha256':sha(Path(__file__).read_bytes()),
        'adapted_auditor_sha256':sha((ROOT/'build/nxdn-active-boundaries-v1-results-audit.py').read_bytes()),
        'native_invocations':20,'preserved_group_counts':group_counts,'unique_file_versions_hashed':len(hashed),
        'report_file_hashes_verified':len(report['files']),'independent_gates':independent,'totals':dict(totals),
        'body_call_classes':dict(calls),'final_crc_observations':dict(crcs),'synthesis_flag_counts':dict(flags),
        'unavailable_slot_synthesis_routes':unsafe,'baseline_unavailable_synthesis_removed':baseline_removed,
        'baseline_unavailable_synthesis':baseline_unsafe,'cases':cases,'auditor_development_corrections':[],
        'scope':'Separate raw/source arithmetic and availability audit, without frozen checker/encoder imports or native execution. This auditor implemented the candidate acquisition APIs; no claim of independent candidate authorship, speech, speaker output, RF or all-backend safety.'}
    OUT.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    lines=['# Independent availability v1 raw-result audit','',
        ('PASS' if result['audit_pass'] else 'FAIL')+f': {checks} checks; {len(failures)} discrepancies. No native execution or frozen checker import.',
        '',f'Report SHA256 `{result["report_sha256"]}`; source commit `0551423572dc056b6e8d6f10f114e7a77bece193`. All20 distinct processes exited0. The audit rehashed all preserved groups and report files.',
        '',f'Independent gates: `{json.dumps(independent,sort_keys=True)}`. Targeted availability succeeds; overall progression remains a failure.',
        '', '| Scenario (per invocation) | Frames | FEC / synthesis | Complete / partial / empty body calls | Unsafe routes |',
        '|---|---:|---:|---|---:|']
    for name in NAMES:
        v=cases[name+'-c37/1'];t=v['counts'];c=v['call_classes']
        lines.append(f'| {name} | {t["frames"]} | {t["FEC"]} / {t["synthesis"]} | {c.get("complete",0)} / {c.get("crossing_partial",0)} / {c.get("crossing_empty",0)+c.get("already_eof",0)} | {len(v["unsafe_synthesis"])} |')
    lines += ['',f'Totals: `{json.dumps(dict(totals),sort_keys=True)}`. Independent CRC observations: `{json.dumps(dict(crcs))}`. Actual ERASURE/REPEAT/MUTE masks32/64/128: `{json.dumps(dict(flags),sort_keys=True)}`.',
        '', 'At6159, V0 slot0 contains35 complete dibits and19 real samples of its unfinished final dibit; no slot reaches FEC, synthesis or audio/media activity. At6160/6161, slot0 completes before later EOF and is preserved as exact known word0; the next logical call consumes zero/one sample without completing, respectively. Later slots remain unavailable. Every explicit availability bit agrees with the independently observed span and symbol completion, with full per-call numeric pop coverage in detail mode.',
        '', 'The candidate removes all40 previously recorded unavailable-slot synthesis calls across the12 prefix identities. It preserves the two distinct complete early-word cases and all their four detail/chunk versions. Source identity is grounded in canonical per-dibit positions and the pinned known air/channel/49-bit words, not the decoder output. Every actually routed channel matrix and detailed reliability mapping is independently checked.',
        '', 'Full cold clean and bad-LICH common outcomes, stable channel/FEC detail and pop traces match their immutable cached baselines after stripping only added availability telemetry. Bad LICH remains exposed and rejected with no current proof/voice; its known call later terminates at the trailer. It still loses source ordinals2 and3 (words4–11), retaining12/20 eligible words. The unchanged observed search/wrong-frame chronology is retained in JSON; this is a separate acquisition failure, not an availability improvement.',
        '', 'All24 known source occurrences survive the cold clean control. Flags are descriptive vocoder results, not sample-availability evidence or accepted speech. PCM values are not used for source or neutrality proof; no speaker-output, physical-radio, encrypted-call or Android/app claim follows.',
        '', 'Source mechanism: private candidate dsd_symbol.c reports explicit complete-symbol/record status while retaining legacy getSymbol bookkeeping; dsd_dibit.c returns before slicing/capture/ring updates on unavailable input. nxdn_frame.c keeps a local182-entry map, requires complete control ranges and derives an absolute voice-slot mask; nxdn_voice.c skips missing slots before FEC and media/audio copying. The inherited Pulse/headful WAV adapter limitation remains outside this finite discriminator result.',
        '', 'The audit uses only Python standard-library parsing/arithmetic and a separate prior raw auditor as a starting point. No frozen experiment source, gate, input, baseline or binary was changed. The auditor authored the acquisition helper implementation; independence here is from the experiment checker and output-derived truth, not from candidate authorship.']
    if failures:lines+=['','Discrepancies:']+['- '+v for v in failures]
    OUT.with_suffix('.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('audit_pass','checks','failures','independent_gates','totals','final_crc_observations','baseline_unavailable_synthesis_removed')},indent=2))


if __name__=='__main__':main()
