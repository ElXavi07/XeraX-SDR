"""Package completed candidate evidence; never execute or rerun native identities."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]
STUDY=ROOT/'build/nxdn-availability-v1-run-20260925'
DEST=ROOT/'docs/research/evidence'
STEM='nxdn-availability-v1-2026-09-25'
ARCHIVE=DEST/(STEM+'-raw.zip'); INDEX=DEST/(STEM+'.json')
HARNESS='0551423572dc056b6e8d6f10f114e7a77bece193'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def need(ok,why):
    if not ok: raise ValueError(why)

need(not ARCHIVE.exists() and not INDEX.exists(),'Existing publication is immutable')
raw_report=(STUDY/'report.json').read_bytes(); report=json.loads(raw_report)
summary=json.loads((ROOT/'build/nxdn-availability-v1-summary.json').read_bytes())
need(summary['report_sha256']==sha(raw_report),'Summary report identity changed')
need(report['measurement_pass'] and report['preservation_pass'],'Incomplete or invalid measurement')
need(len(report['attempts'])==20 and all(a['exit_code']==0 for a in report['attempts']),'Invocation inventory changed')
need(report['targeted_guard_pass'] and not report['progression_pass'] and not report['product_promotion'],
     'Registered candidate outcome differs from publication scope')
for name,d in report['files'].items(): need(sha((STUDY/name).read_bytes())==d,'Report file changed: '+name)
before=json.loads((STUDY/'before-execution.json').read_bytes())
need(before['commit']==HARNESS and before['baseline_receiver_rerun'] is False,'Wrong frozen source/execution identity')
groups=('frozen_files','original_files','copied_identities','configured_sources','protected')
for group in groups:
    need(all(Path(p).is_file() and sha(Path(p).read_bytes())==d for p,d in before[group].items()),'Preservation failed: '+group)
audit_raw=(ROOT/'build/nxdn-availability-v1-results-audit.json').read_bytes()
audit=json.loads(audit_raw); need(audit['audit_pass'],'Independent raw results audit failed')
ci={}
for event,number in (('push',36203868209),('pr',36203871241)):
    value=json.loads((ROOT/f'build/nxdn-availability-v1-ci-{event}-status.json').read_bytes())
    need(value['databaseId']==number and value['headSha']==HARNESS and value['status']=='completed'
         and value['conclusion']=='success' and len(value['jobs'])==4
         and all(j['conclusion']=='success' for j in value['jobs']),'Wrong CI result/identity')
    ci[event]=number
payload={'study/'+p.relative_to(STUDY).as_posix():p.read_bytes()
         for p in sorted(STUDY.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
extras=('results-audit.py','results-audit.json','results-audit.md','summary.py','summary.json',
        'summary-initial.py','summary-development.txt',
        'ci-push.log','ci-pr.log','ci-push-status.json','ci-pr-status.json','execution.log')
for suffix in extras:
    p=ROOT/('build/nxdn-availability-v1-'+suffix); payload['publication/'+p.name]=p.read_bytes()
for event in ('push','pr'):
    folder=ROOT/f'build/nxdn-availability-v1-ci-{event}-artifacts'
    for p in sorted(folder.rglob('*')):
        if p.is_file(): payload[f'publication/ci-{event}/'+p.relative_to(folder).as_posix()]=p.read_bytes()
for p in sorted((ROOT/'build').glob('nxdn-availability-v1-results-audit-*')):
    if p.is_file(): payload['publication/'+p.name]=p.read_bytes()
for p in (Path(__file__),ROOT/'.github/workflows/nxdn-availability-candidate.yml'):
    payload['publication/'+p.name]=p.read_bytes()
payload['licenses/XeraX-LICENSE.txt']=(ROOT/'LICENSE').read_bytes()
payload['licenses/dsd-neo-LICENSE.txt']=(ROOT/'upstream/dsd-neo/LICENSE').read_bytes()
build_audit=json.loads((STUDY/'frozen/nxdn-availability-v1-build-audit.json').read_bytes())
headers=[Path(p) for p in build_audit['dependencies'] if p.replace('\\','/').endswith('include/mbelib-neo/mbelib.h')]
need(len(headers)==1,'Codec header identity missing')
for p in sorted((headers[0].parents[2]/'share').glob('*/copyright')):
    payload['licenses/installed/'+p.parent.name+'.txt']=p.read_bytes()
payload['publication/mbelib.h']=headers[0].read_bytes()
payload['publication/mbelib-source.tar.gz']=(ROOT/'build/mbelib-voice-words-v1-source.tar.gz').read_bytes()
payload['README.txt']=(
    'XeraX NXDN availability v1 research evidence, registered 25 September 2026.\n'
    'Frozen harness '+HARNESS+'. Exactly 20 new receiver identities, no retries.\n'
    'Targeted missing-input guard passes; separate bad-LICH recovery gate fails.\n'
    'Prefix FEC/synthesis counts change from 4/4/4 to 0/1/1 while retaining the\n'
    'fully received early word. Clean 24-word routing and bad-LICH 12-word\n'
    'common measured outcomes equal cached baseline using frozen normalization\n'
    '(additive telemetry removed; optional PCM excluded).\n'
    'The missing 8 later clean words remain unresolved. Product promotion=false.\n\n'
    'study/ retains every attempt, inputs, source/pop traces, copied baseline\n'
    'anchors, frozen checked-reader/masked-voice/FEC observers, actual research\n'
    'executable and runtime DLLs, preflight failures, tests and source identities.\n'
    'Original product source: https://github.com/ElXavi07/XeraX-SDR/tree/ec712a0869184c0b73ec06b1ce36d3d1bdaf6b04\n'
    'Candidate changes are under experiments/nxdn_availability_v1 at the frozen\n'
    'harness commit. No upstream/default/setting/released artifact changed.\n'
    'The included executable is a research tool, not an application installer.\n'
    'publication/ adds post-execution independent audits and completed CI logs.\n\n'
    'Offline review, no native execution: import analyze from\n'
    'study/frozen/source_repository/experiments/nxdn_availability_v1, retaining\n'
    'sibling frozen helper hierarchy. validate_inputs(study/inputs), then\n'
    'inspect(rows,trace_path,case,manifest,inputs,detail) for all 20 saved\n'
    'events.jsonl/pops.u32le pairs; compare the complete grid. Reproduce\n'
    'measurement=true, targeted_guard=true, progression=false. Absolute machine\n'
    'identities are historical provenance and must not be rewritten.\n\n'
    'Only synthetic clear conventional NXDN48 discriminator input is covered.\n'
    'Pulse/headful WAV adapter limitations, encrypted missing-slot history,\n'
    'prior off-phase/malformed-header controls, impaired complex IQ, physical\n'
    'receivers and application/audio acceptance remain separate. No speech\n'
    'quality, crypto, GPU, whole-app speed or RF sensitivity claim follows.\n'
).encode()
inventory={'schema':1,'kind':'nxdn_availability_v1_archive','native_execution_by_publication':False,
           'files':{n:{'bytes':len(r),'sha256':sha(r)} for n,r in sorted(payload.items())}}
payload['archive-manifest.json']=(json.dumps(inventory,indent=2)+'\n').encode()
with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(payload.items()):
        z.writestr(zipfile.ZipInfo(name,date_time=(2026,9,25,0,0,0)),raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(ARCHIVE) as z:
    need(len(z.namelist())==len(payload) and set(z.namelist())==set(payload) and z.testzip() is None
         and all(z.read(n)==r for n,r in payload.items()),'Archive verification failed')
totals={key:sum(r['summary'][key] for r in summary['invocations'])
        for key in ('fec_hard_calls','fec_soft_calls','synthesis_calls')}
totals['exact_source_occurrences']=sum(sum(v['exact'] for v in r['source_occurrences']) for r in summary['invocations'])
out={'schema':1,'kind':'nxdn_availability_v1','harness_commit':HARNESS,
     'registration_commit':before['registration_commit'],'source_baseline':before['source_baseline'],
     **{k:report[k] for k in ('measurement_pass','preservation_pass','targeted_guard_pass','progression_pass','product_promotion')},
     'comparison':report['comparison'],'native_invocations':20,'native_exit_zero':20,'totals':totals,
     'baseline_receiver_rerun':False,'report_sha256':sha(raw_report),'report_files':len(report['files']),
     'candidate_executable_sha256':before['binary_sha256'],
     'preservation_group_counts':{g:len(before[g]) for g in groups},
     'independent_results_audit_sha256':sha(audit_raw),
     'ci':{'framework_tests':44,'framework_platforms':['Windows','Linux'],'framework_modes':['normal','optimized'],
           'native_unit_contracts':8,'native_platform':'Linux','native_modes':['Release','ASan/UBSan'],
           **ci,'receiver_matrix_in_ci':False},
     'archive':{'file':ARCHIVE.name,'bytes':ARCHIVE.stat().st_size,'entries':len(payload),
                'sha256':sha(ARCHIVE.read_bytes()),'every_entry_verified':True},
     'limits':['synthetic clear conventional NXDN48 discriminator input only',
               'bad-LICH later recovery still retains 12/20 words',
               'legacy Pulse/headful WAV availability contracts not certified',
               'prior off-phase and malformed-header controls require separate integration gates',
               'no app package, speech, complex-IQ/RF, encryption or speed claim']}
INDEX.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out['archive']))
