XeraX NXDN availability v1 research evidence, registered 25 September 2026.
Frozen harness 0551423572dc056b6e8d6f10f114e7a77bece193. Exactly 20 new receiver identities, no retries.
Targeted missing-input guard passes; separate bad-LICH recovery gate fails.
Prefix FEC/synthesis counts change from 4/4/4 to 0/1/1 while retaining the
fully received early word. Clean 24-word routing and bad-LICH 12-word
common measured outcomes equal cached baseline using frozen normalization
(additive telemetry removed; optional PCM excluded).
The missing 8 later clean words remain unresolved. Product promotion=false.

study/ retains every attempt, inputs, source/pop traces, copied baseline
anchors, frozen checked-reader/masked-voice/FEC observers, actual research
executable and runtime DLLs, preflight failures, tests and source identities.
Original product source: https://github.com/ElXavi07/XeraX-SDR/tree/ec712a0869184c0b73ec06b1ce36d3d1bdaf6b04
Candidate changes are under experiments/nxdn_availability_v1 at the frozen
harness commit. No upstream/default/setting/released artifact changed.
The included executable is a research tool, not an application installer.
publication/ adds post-execution independent audits and completed CI logs.

Offline review, no native execution: import analyze from
study/frozen/source_repository/experiments/nxdn_availability_v1, retaining
sibling frozen helper hierarchy. validate_inputs(study/inputs), then
inspect(rows,trace_path,case,manifest,inputs,detail) for all 20 saved
events.jsonl/pops.u32le pairs; compare the complete grid. Reproduce
measurement=true, targeted_guard=true, progression=false. Absolute machine
identities are historical provenance and must not be rewritten.

Only synthetic clear conventional NXDN48 discriminator input is covered.
Pulse/headful WAV adapter limitations, encrypted missing-slot history,
prior off-phase/malformed-header controls, impaired complex IQ, physical
receivers and application/audio acceptance remain separate. No speech
quality, crypto, GPU, whole-app speed or RF sensitivity claim follows.
