"""Independent read-only input oracle; never imports recovery preparer or decoder."""
import collections
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "build/nxdn-recovery-inputs-20260925"
ANCHOR = ROOT / "build/nxdn-engine-gap-pair-20260925"
ENCODER_HASH = "3e2c63b57dba137bbb35cdb9457a17deb9d0363fff8b8117e5d530e5990be9bd"
LEVEL = (8000, 24000, -8000, -24000)
DECLARED = {
    "warm_clean": ("CCSSSSSS", "none", 0, 0),
    "warm_sync_blank": ("CCSSSSSS", "blank", 16000, 200),
    "warm_sync_invert": ("CCSSSSSS", "invert", 16000, 200),
    "warm_drop1": ("CCSSSSSS", "drop", 16217, 1),
    "warm_repeat1": ("CCSSSSSS", "repeat", 16217, 1),
    "warm_drop20": ("CCSSSSSS", "drop", 16217, 20),
    "warm_repeat20": ("CCSSSSSS", "repeat", 16217, 20),
    "cold_clean": ("SSSSSSSS", "none", 0, 0),
    "cold_sync_blank": ("SSSSSSSS", "blank", 640, 200),
    "cold_drop1": ("SSSSSSSS", "drop", 737, 1),
    "cold_repeat1": ("SSSSSSSS", "repeat", 737, 1),
    "bad_crc": ("CCCCCCCC", "none", 0, 0),
    "zero": ("CCCCCCCC", "zero", 0, 0),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def bit_text(number, width):
    return format(number, f"0{width}b")


def crc_division(information, width):
    # Polynomial long division, not the encoder's feedback register recurrence.
    divisor = (1 << width) + {6: 0x27, 12: 0x80F}[width]
    dividend = (((1 << width) - 1) << len(information)) ^ (int(information, 2) << width)
    while dividend.bit_length() > width:
        dividend ^= divisor << (dividend.bit_length() - width - 1)
    return dividend


def channel(information, width, corrupt):
    computed = crc_division(information, width)
    received = computed ^ ((1 << (width - 1)) if corrupt else 0)
    checks = bit_text(received, width)
    uncoded = information + checks + "0000"
    register, symbols = 0, []
    for bit in uncoded:
        register = ((register << 1) + int(bit)) & 31
        symbols.extend(((register & 0x19).bit_count() % 2, (register & 0x17).bit_count() % 2))
    period, residue, rows, columns = (6, 5, 12, 5) if width == 6 else (4, 1, 16, 9)
    kept = [value for pos, value in enumerate(symbols) if pos % period != residue]
    transmitted = [None] * len(kept)
    for column in range(columns):
        for row in range(rows):
            transmitted[row * columns + column] = kept[column * rows + row]
    text = lambda values: "".join(str(v) for v in values)
    metadata = {
        "information_bits": information, "crc_width": width,
        "computed_crc": computed, "transmitted_crc": received, "check_bits": checks,
        "crc_expected_pass": not corrupt, "convolution_input_bits": uncoded,
        "coded_bits": text(symbols), "punctured_bits": text(kept), "channel_bits": text(transmitted),
        "flipped_check_bit_index": 0 if corrupt else None,
    }
    return metadata


def air_frame(sacch, facch, full_lich=0x83):
    lich = "".join(bit + "1" for bit in bit_text(full_lich, 8))
    body_bits = lich + sacch["channel_bits"] + facch["channel_bits"] * 2
    body = [int(body_bits[pos:pos + 2], 2) for pos in range(0, len(body_bits), 2)]
    # Explicit nine bit stages ordered low-to-high; no integer encoder import.
    stages = collections.deque(int(bit) for bit in reversed(bit_text(228, 9)))
    air = []
    for dibit in body:
        air.append(dibit ^ (2 * stages[0]))
        feedback = stages[0] ^ stages[4]
        stages.popleft()
        stages.append(feedback)
    fsw_bits = bit_text(0xCDF59, 20)
    return bytes([int(fsw_bits[pos:pos + 2], 2) for pos in range(0, 20, 2)] + air)


def vector(payload, kind):
    ran, tail10, tail72 = ((11, 0x155, 0x123456789ABCDEF012),
                           (53, 0x2D3, 0xFEDCBA9876543210AB))[payload]
    sacch = channel("00" + bit_text(ran, 6) + "00010000" + bit_text(tail10, 10), 6, kind == "C")
    facch = channel("00010000" + bit_text(tail72, 72), 12, kind == "C")
    raw = air_frame(sacch, facch)
    return raw, {"payload": payload, "name": kind, "lich": 0x41, "full_lich": 0x83,
                 "sacch": sacch, "facch": facch, "sha256": sha(raw)}


def pack(values, code):
    return struct.pack("<" + str(len(values)) + code, *values)


def independent_wave(vectors, payload, sequence):
    # Prefix sum with explicit four-left/three-right boundary extension, avoiding
    # the preparer's per-sample clamp/window implementation.
    dibits = [1, 3] * 16
    for kind in sequence:
        dibits.extend(vectors[(payload, kind)])
    dibits.extend([0] * 64)
    nrz = [LEVEL[value] for value in dibits for _ in range(20)]
    padded = [nrz[0]] * 4 + nrz + [nrz[-1]] * 3
    cumulative = [0]
    for value in padded:
        cumulative.append(cumulative[-1] + value)
    return [(cumulative[pos + 8] - cumulative[pos]) / 8 for pos in range(len(nrz))]


def independently_edited(original, kind, position, count):
    length = len(original) + (count if kind == "repeat" else -count if kind == "drop" else 0)
    samples, origins, occurrences = [], [], []
    for delivered_index in range(length):
        index, occurrence = delivered_index, 0
        if kind == "drop" and delivered_index >= position:
            index += count
        elif kind == "repeat" and delivered_index >= position + count:
            index -= count
            occurrence = int(delivered_index < position + 2 * count)
        value = original[index]
        if kind == "zero" or (kind == "blank" and position <= index < position + count):
            value = 0.0
        elif kind == "invert" and position <= index < position + count:
            value = -value
        samples.append(value)
        origins.append(index)
        occurrences.append(occurrence)
    return samples, origins, occurrences


def checked_file(path, expected, digest=None):
    raw = path.read_bytes()
    require(raw == expected, "Exact independent bytes differ: " + str(path))
    if digest is not None:
        require(sha(raw) == digest, "Manifest hash differs: " + str(path))
    return {"bytes": len(raw), "sha256": sha(raw)}


def audit():
    manifest_path = INPUT / "manifest.json"
    manifest = json.loads(manifest_path.read_bytes())
    old = json.loads((ANCHOR / "inputs/manifest.json").read_bytes())
    require(sha((ROOT / "experiments/nxdn_frames/generate_vectors.py").read_bytes()) == ENCODER_HASH, "Frozen encoder identity changed")
    expected_header = {"schema": 1, "domain": "discriminator_samples", "rate_hz": 48000,
                       "symbol_rate": 2400, "samples_per_symbol": 20, "ramp": 8, "encoder_sha256": ENCODER_HASH}
    require(all(manifest.get(k) == v for k, v in expected_header.items()), "Input domain/profile changed")
    # Golden independent CRCs and complete published frame prevent silent oracle drift.
    gs = channel("00" + bit_text(23, 6) + "00010000" + "0" * 10, 6, False)
    gf = channel("00010000" + "0" * 72, 12, False)
    require(gs["computed_crc"] == 0x12 and gf["computed_crc"] == 0x830, "CRC oracle golden mismatch")
    require(sha(air_frame(gs, gf)) == "f9a9ddcf3005ff69815ac6edef66afbd9d2188bb17d327fcdb98c26f49d5c7ef", "Full-frame oracle golden mismatch")
    file_checks, vector_checks, waveform_checks, vectors = {}, [], [], {}
    expected_files = {"manifest.json"}
    for payload in (0, 1):
        for kind in ("S", "C"):
            raw, expected = vector(payload, kind)
            name = f"h{payload}-{kind}.dibits"
            require(manifest["vectors"]["vectors"][name] == expected, "Independent bit/CRC metadata differs: " + name)
            file_checks["vectors/" + name] = checked_file(INPUT / "vectors" / name, raw, expected["sha256"])
            expected_files.add("vectors/" + name)
            vectors[(payload, kind)] = raw
            signs = "".join("1" if LEVEL[d] > 0 else "3" for d in raw)
            vector_checks.append({"name": name, "sha256": sha(raw), "crc6": expected["sacch"]["computed_crc"],
                                  "crc12": expected["facch"]["computed_crc"], "all_crc_valid": kind == "S",
                                  "positive_sign_windows": [i for i in range(183) if signs[i:i+10] == "3131331131"],
                                  "negative_sign_windows": [i for i in range(183) if signs[i:i+10] == "1313113313"]})
        for scenario, (sequence, kind, position, count) in DECLARED.items():
            name = f"h{payload}-{scenario}"
            wave = manifest["waveforms"][name]
            original = independent_wave(vectors, payload, sequence)
            delivered, origin, occurrence = independently_edited(original, kind, position, count)
            require(len(original) == 32640, "Wrong original length")
            expected_frames = [{"ordinal": ordinal, "kind": frame_kind,
                                "start": 640 + 3840 * ordinal, "end": 4480 + 3840 * ordinal,
                                "vector": f"h{payload}-{frame_kind}.dibits", "sha256": sha(vectors[(payload, frame_kind)])}
                               for ordinal, frame_kind in enumerate(sequence)] if kind != "zero" else []
            for key, value in {"frames": expected_frames, "original_samples": 32640, "samples": len(delivered),
                               "zero_gaps_before_shaping": [], "payload": payload, "scenario": scenario,
                               "legacy": False, "edit": {"kind": kind, "source_start": position, "count": count}}.items():
                require(wave[key] == value, name + " metadata differs: " + key)
            for file_key, hash_key, suffix, values, code in (
                    ("original_file", "original_sha256", ".original.f32le", original, "f"),
                    ("file", "sha256", ".f32le", delivered, "f"),
                    ("lineage_file", "lineage_sha256", ".origin.u32le", origin, "I"),
                    ("occurrence_file", "occurrence_sha256", ".occurrence.u32le", occurrence, "I")):
                require(wave[file_key] == name + suffix, "Unexpected path/name")
                file_checks[wave[file_key]] = checked_file(INPUT / wave[file_key], pack(values, code), wave[hash_key])
                expected_files.add(wave[file_key])
            waveform_checks.append({"name": name, "original_samples": len(original), "delivered_samples": len(delivered),
                                    "edit": wave["edit"], "second_occurrences": sum(occurrence),
                                    "backward_origin_steps": sum(a > b for a, b in zip(origin, origin[1:])),
                                    "source_frame_truth_count": len(expected_frames)})
    legacy = manifest["waveforms"]["legacy_clean_weak"]
    legacy_expected = dict(old["waveforms"]["p0-clean_weak"], legacy=True, legacy_waveform="p0-clean_weak", scenario="legacy_clean_weak")
    require(legacy == legacy_expected, "Legacy metadata drift")
    file_checks[legacy["file"]] = checked_file(INPUT / legacy["file"], (ANCHOR / "inputs" / legacy["file"]).read_bytes(), legacy["sha256"])
    expected_files.add(legacy["file"])
    legacy_names = {f["vector"] for f in legacy["frames"]}
    for name in legacy_names:
        require(manifest["vectors"]["vectors"][name] == old["vectors"]["vectors"][name], "Legacy vector metadata drift")
        path = "vectors/" + name
        file_checks[path] = checked_file(INPUT / path, (ANCHOR / "inputs" / path).read_bytes(), old["vectors"]["vectors"][name]["sha256"])
        expected_files.add(path)
    expected_waves = {f"h{p}-{s}" for p in (0, 1) for s in DECLARED} | {"legacy_clean_weak"}
    require(set(manifest["waveforms"]) == expected_waves, "Waveform grid differs")
    require(set(manifest["vectors"]["vectors"]) == {f"h{p}-{k}.dibits" for p in (0, 1) for k in ("S", "C")} | legacy_names, "Vector grid differs")
    expected_cases = {(f"{name}-c{chunk}", name, chunk) for name in expected_waves for chunk in (37, 512)}
    actual_cases = [(c["id"], c["waveform"], c["chunk"]) for c in manifest["cases"]]
    require(len(actual_cases) == 54 and set(actual_cases) == expected_cases, "Case grid differs or duplicates")
    require(all(set(c) == {"id", "waveform", "chunk"} for c in manifest["cases"]), "Case fields differ")
    invocations = [{"case_id": c[0], "waveform": c[1], "chunk": c[2], "fast": fast, "observed": observed}
                   for c in sorted(actual_cases) for fast in (0, 1) for observed in (0, 1)]
    require(len(invocations) == 216, "Invocation grid differs")
    anchors = []
    for c in invocations:
        if c["waveform"] != "legacy_clean_weak":
            continue
        item = dict(c, files={})
        for name in ("events.jsonl", "pops.u32le"):
            path = ANCHOR / f"runs/p0-clean_weak-f{c['fast']}-c{c['chunk']}/candidate/{c['observed']}/{name}"
            raw = path.read_bytes()
            item["files"][str(path.relative_to(ANCHOR))] = {"bytes": len(raw), "sha256": sha(raw)}
        anchors.append(item)
    actual_files = {p.relative_to(INPUT).as_posix() for p in INPUT.rglob("*") if p.is_file()}
    require(actual_files == expected_files, "Unlisted/missing generated file")
    require((INPUT / "h0-zero.f32le").read_bytes() == (INPUT / "h1-zero.f32le").read_bytes() == bytes(32640*4), "Zero replicas differ")
    sources = ["experiments/nxdn_recovery/prepare.py", "experiments/nxdn_recovery/run.py", "experiments/nxdn_recovery/analyze.py",
               "docs/research/NXDN-RECOVERY-PREREGISTRATION-2026-09-25.md", "experiments/nxdn_frames/generate_vectors.py"]
    return {"audit_schema": 1, "input_contract_pass": True, "native_execution": False,
            "scope": "Independent pre-execution oracle, not decoder correctness or recovery result",
            "git_head_at_audit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
            "input_directory": str(INPUT), "anchor_directory": str(ANCHOR),
            "manifest_sha256": sha(manifest_path.read_bytes()),
            "source_hashes": {p: sha((ROOT / p).read_bytes()) for p in sources if (ROOT / p).is_file()},
            "independence": "No preparer/encoder/decoder imports. Polynomial division CRC, shift-mask convolution, matrix transpose, deque whitening, prefix-sum smoothing and piecewise index maps.",
            "golden_crc_and_frame_pass": True, "vectors": vector_checks, "waveforms": waveform_checks,
            "files": file_checks, "file_count_including_manifest": len(expected_files),
            "new_waveforms": 26, "legacy_waveforms": 1, "cases": 54, "planned_native_invocations": 216,
            "new_invocations": 208, "legacy_invocations": 8, "invocations": invocations,
            "legacy_anchor_inputs_exact": True, "existing_anchor_outputs": anchors,
            "decoder_result_status": "Not run or inferred; eight future anchor outputs must still match retained hashes."}


if __name__ == "__main__":
    output = ROOT / "build/nxdn-recovery-input-audit.json"
    try:
        result = audit()
    except Exception as error:
        result = {"input_contract_pass": False, "native_execution": False,
                  "exception": type(error).__name__, "detail": str(error)}
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: result.get(key) for key in ("input_contract_pass", "cases", "planned_native_invocations", "detail")}))
    sys.exit(0 if result["input_contract_pass"] else 1)
