# Independent NXDN recovery input preflight — 2026-09-25

The input contract passes. This is an input and runner review, not a receiver
result. No native decoder, matrix, benchmark, RF source or product build was run.
The review was made at repository HEAD
`38552e4b7d7391a79f4599ff9d6bbc2ce6601371` against the registered specification.

## Independently checked evidence

The companion `nxdn-recovery-input-audit.py` never imports the preparer, frozen
encoder, recovery analyzer or production decoder. It reconstructs the CRCs with
integer polynomial long division, convolution with shift-register parity masks,
interleaving by explicit matrix transpose, whitening with nine separate bit
stages, waveform smoothing by prefix sums, and edits by piecewise delivered-index
equations. The published old full-frame golden SHA and CRC6/CRC12 values are
checked first to guard against an incorrect new oracle.

All four held-out vectors and every information/check/coded/punctured/channel-bit
metadata string match exactly. All 26 new original waveforms, delivered waveforms,
origin maps and occurrence maps match independent bytes. The checks cover
13,679,232 binary bytes in 111 binary files; the manifest is the 112th input file.
The source/input identities and complete per-file checks are in
`nxdn-recovery-input-audit.json`.

| Held-out payload | Valid CRC6 | Valid CRC12 | RAN |
| --- | ---: | ---: | ---: |
| 0 | 59 | 345 | 11 |
| 1 | 59 | 2139 | 53 |

For C vectors, the highest checkword bit is flipped before convolutional
encoding, so the transmitted values are CRC6 27, and CRC12 2393 / 91,
respectively. Information fields remain identical to the corresponding S vector.
This deliberately inconsistent codeword is a negative CRC/confirmation control;
it is not a random RF corruption experiment or a promise that FEC should repair
the wrong checkword.

There are exactly 27 waveforms, 54 unique waveform/chunk cases, and 216 distinct
planned waveform/chunk/option/observer invocations: 208 new and eight legacy.
Both chunks are 37 / 512, both faster-acquisition settings and both observer
settings are represented once. This count is the actual manifest expanded by the
runner's two binary loops; it is not a claim that any native invocation ran.

The legacy clean_weak waveform is byte-identical to the old anchor, as are its
two referenced vector files and original metadata (apart from declared legacy
labels). All 16 old events/pop-trace files needed by the eight future anchors
exist and have saved hashes. The forthcoming outputs still must match them.

## Interpretation constraints

- The trailer is **dibit zero**, with amplitude +8000, not zero-valued samples.
  The phrase “level 0” should be read in that symbol sense. The zero controls
  separately replace all 32,640 delivered samples with +0.0.
- The two zero controls are identical replicas. The two held-out payloads also
  happen to share CRC6=59; distinct information-bit comparisons remain essential.
  CRC6 equality alone cannot establish source identity or payload correctness.
- The eight-sample shaping window is `[i-4, i+3]`, including clamped endpoint
  extension. Its half-sample convention and three-sample forward influence do
  not establish an original complex-IQ or hardware latency reference.
- Blank/invert faults affect exactly the first 200 *already shaped* samples of
  the selected FSW. Shaping transients outside that interval remain. This is not
  erasure of every sample influenced by the synchronization dibits.
- Warm deletion/repetition starts at original sample 16,217: frame 4 start +217,
  17 samples into the LICH interval. Cold slips start at 737, inside frame 0 FSW.
  This is a delivered discriminator discontinuity, not a sample-clock offset,
  multipath, oscillator error, RF dropout or continuous drift model.
- Repeat inserts the next k samples before their original occurrence. The later
  duplicate has occurrence 1; occurrence 0 remains the first delivered copy.
  Original coordinates may decrease for repeat-20 and repeat for repeat-1.
  Delivered coordinates must remain strictly increasing.
- The held-out S/C individual vectors each have only the canonical positive
  ten-symbol sign window at offset 0 and no inverted ten-symbol sign windows.
  This narrows the input family; it is not a guarantee against false sync across
  frame boundaries, after edits or after real demodulation.
- The legacy waveform intentionally has no new original/occurrence-map files.
  It belongs to the original identity/anchor path; its old exact semantics must
  not be silently synthesized from the new transformed-waveform contract.
- The current content-attribution rule is conservative. A correctly recovered
  codeword outside the registered sample-boundary interval is ungrounded, not
  independently proven false decoding. No latency/improvement claim may count
  historical confirmation alone as fresh decoded content.

## Runner review at the recorded source hashes

One definite result-label bug was reported and corrected before execution:
`run.py` initially queried `quality.warm_progression_pass`, whereas `compare`
returns `progression_pass`. The reviewed runner now uses `progression_pass`.

Two remaining items were sent to the parent for resolution before execution:

1. Frozen script copies are hashed, but the invocation executes live imported
   `run.py` / `analyze.py` / `prepare.py`. The then-current final preservation check
   covers frozen copies and inputs/anchors, not the identities of the actual
   live script files before and after execution. Bind those identities or execute
   the captured source bytes. The old inspector has its own exact SHA check, but
   that does not bind the new adapter/runner to its archived copies.
2. The then-current `measurement_pass` excludes `chunk_differences`; only the
   warm progression result rejects them. The preregistration requires exact
   chunk-invariant traces/outcomes. Include that gate in the declared measurement
   contract, or distinguish the labels explicitly rather than reporting an
   undifferentiated measurement pass when the invariant fails.

The runner already refuses an existing output directory, keeps individual stdout,
stderr, invocation/audit/failure evidence, removes DSD_* overrides, bounds each
native invocation, never retries a poor result, hashes copied inputs/binary and
DLLs, compares each legacy anchor, and preserves partial failure at the outer
boundary. Before-source checks for the normalized frame and other archived
native source files are present. No new algorithm or product default is changed
by the declared matrix.

The JSON snapshot records the exact source versions audited. Later runner fixes
do not retroactively change that snapshot; their final source hashes should be
captured by the parent's execution manifest.
