# NXDN48 impaired-stream recovery design review

Read-only review at `04c0ed3e4e4689bc5ee483cc432c4dc6c4ea62db`; no native matrix or product/harness edit performed for this review.

Use the already frozen engine-gap candidate executable, SHA-256 `ace9de618e098fe4878607fc43ad0d0480c3a7e80f225b5bae7ea880900882fe`, for both public option values. This hash was reopened. Its engine, dispatcher, sync, symbol, dibit, confirmation and channel decoder sources still match the current files byte-for-byte; its frame policy matches integrated RC3 modulo LF/CRLF. Retain DLLs, source manifests, maps and the binary hash. A new native decoder build or patch is unnecessary for this bounded study.

The actual live loop, dispatch and reset wrappers are reusable (`experiments/nxdn_engine_gap/observer.c:66-110`). Sample trace positions are delivered-input coordinates; body positions are exclusive consumed frontiers (lines 113-123, 141-180). Its optional sample/CRC callbacks can remain off/on, with the common boundary logger present in both. Preserve observer neutrality, all incidental frames, provider exhaustion, backend-operation guards and actual reset events.

## Bounded matrix

The proposed 216 invocations are sufficient for a first falsifiable study: two new deterministic payloads, 13 waveforms each, public option 0/1, chunks 37/512, optional observers off/on, plus one unchanged legacy waveform across the same eight configurations.

- Warm: `CCSSSSSS`, clean; blank/invert 200 sync samples at frame 4; drop/repeat 1 or 20 samples at frame 4 start + 217.
- Cold: `SSSSSSSS`, clean; blank the first sync; drop/repeat one sample at first-frame start + 97.
- Negative: `CCCCCCCC` and true zero-amplitude input.
- Legacy: frozen payload-0 clean-weak waveform and exact old candidate outputs/traces for each matching option/chunk/observer setting.

Frame starts, edit position, repeat convention, values, lengths and hashes must be registered before execution. Position +217 is inside the first LICH symbol, so describe those cases as LICH-boundary slips, not payload-specific corruption. Blank/invert after shaping and record that choice; do not silently regenerate the modulation after deleting/repeating samples. Repeat must specify exactly which existing samples are duplicated and where.

The faster option only changes unconfirmed canonical-positive acquisition (`dsd_frame_sync.c:1726-1741`). A nominal warm case is not exposure: require independently correct frame 3/current proof and confirmed state in both option runs, then no reset before the impairment reaches the consumer. Separate continuously confirmed recovery from later actual-reset recovery. Cold improvements cannot satisfy a warm-recovery claim; no warm difference is a valid result.

## Truth and lineage changes

Use a new hash-guarded encoder import, without calling the old LICH preparer or relaxing historical source guards. Preserve per-frame expected information bits and transmitted checkwords; distinct per-frame payload identifiers are helpful if semantically valid, but source geometry remains mandatory even if contents match.

Store a complete delivered-index-to-canonical-index map. For exclusive body frontier `p`, use `origin[p-1]+1`. Delivered trace indices must be increasing and backed by this frame's own callback segment. Canonical indices may jump forward on a declared deletion or backward/repeat on a declared duplication. Distinguish intentional input edits from samples the decoder itself skipped. Byte equality must compare the delivered waveform against the declared edit of the original, not against an unedited source at the same index.

The old attribution function requires exact whole returned dibits (`analyze.py:29-49`); that would discard genuine FEC correction. Attribute geometry first, then test decoded channel content. A preregistered strict ±20 canonical-boundary rule is conservative: some whole-symbol slips may remain unattributed despite matching decoded content. Retain that as an attribution limitation and never widen the tolerance after outcomes.

The CRC hook is final post-fallback (`nxdn_test_support.h:29-36`, `nxdn_deperm.c:1182-1189,1261-1268`). Final acceptance is `computed == received`, independently recomputed from final bits. `soft_pass` and its complementary fallback flag describe the route taken, not final acceptance. Count a full frame only if all three expected channels have correct final information/checkwords. At least one independently correct accepted channel can support a current proof, subject to the real confirmation-history rules; a lone CRC6 cannot confirm a fresh transmission.

## Gates and falsification

Measurement: immutable binary/source/input hashes; complete finite case grid; balanced event grammar; exact delivered value/index accounting; CRC recurrence and field bounds; no backend starts/tunes; observed/unobserved common-output equality; unchanged legacy raw anchors. Preserve malformed/timeout/negative outputs and stop favorable claims if measurement fails.

Safety: no unsupported current proof, no current proof at truncated EOF, and no incorrect CRC-passing content in either option. One correct channel must not hide another channel that passes CRC with wrong information or a wrong received checkword. Recompute confirmation/current-proof and real dispatcher verdict/profile stamp from observed final channel evidence and reset history. CRC failures and uncorrected source frames are valid receiver outcomes, not recorder errors.

Retention: preserve every correctly decoded default-off source frame under option-on, with at most 20 delivered samples of completion delay; report every missing ordinal, duplicate decode, partial-success change, incidental frame and reset. Compare the same edited waveform for each option. Treat missing recovery as missing, never an infinite speedup.

Promotion: require all measurement/safety/retention/control gates, plus at least one registered impaired scenario with first verified recovery gain >=3360 delivered samples across both payloads and both chunks. Publish cold and warm gains separately; warm promotion additionally requires actual matched warm exposure. Clean anchors alone cannot qualify. Chunk disagreement blocks promotion. A useful negative result is no qualifying warm gain, lost frames, unsupported proof, or insufficient actual exposure; do not tune or rerun a favorable subset.

Limits remain finite discriminator replay through the real engine; no RF frontend, hardware tuning, audio quality, real elapsed-radio timers, mixed protocols or whole-application performance claim. Linux/sanitizer repetition and independent raw audit would be subsequent gates before expanding any product claim.
