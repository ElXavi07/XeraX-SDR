# Independent review of retained recovery chunk failures

The registered result remains **measurement FAIL / progression FAIL**. This is a read-only examination of the single completed matrix, not a replacement result or a relaxed gate. No native process was run and no experiment source, gate or raw evidence was changed.

The six reported observed chunk differences are recorder positions after EOF, with no observed chunk-dependent receiver decision. A separate, real payload-dependent recovery failure makes those EOF paths reachable: payload h0 repeatedly matches a supported sync pattern inside its encoded payload and does not recover a complete source frame before the finite input ends.

## Exact chunk difference

Compared all 216 raw invocations directly, without importing the analyzer or runner. All 54 observed chunk-pair pop traces are byte-identical; all contain the same delivered samples across chunk sizes. After excluding the five already-declared provider fields (`provided`, `cache_pos`, `cache_len`, `read_start`, `chunk`), the only differences in the entire matrix are `body_positions` on these final EOF-truncated frames:

| Waveform | Fast option | Observed event seq / frame | Differing body indices | Final return |
| --- | --- | --- | --- | --- |
| h0-warm_sync_invert | 0 / 1 | 59 / 7; 62 / 7 | 109–181 inclusive | 1 / 1 |
| h0-warm_repeat20 | 0 / 1 | 65 / 8; 68 / 8 | 109–181 inclusive | 1 / 1 |
| h0-cold_sync_blank | 0 / 1 | 50 / 7; 50 / 7 | 109–181 inclusive | 0 / 0 |

The same six differences occur with observation disabled, making 12 differing pairs among 108 observed/unobserved chunk comparisons. Observer-on/off common outcomes agree for every option/base case.

For each affected frame, the first 109 body positions agree. The remaining 73 calls consume no new samples, but their recorded positions become **32634 for chunk 37** versus **32256 for chunk 512**. Both are the last successful refill's start, not a new consumed frontier. For ordinary-length waves, the last genuine frontier is 32640; for repeat20 it is 32660. At frame end, both cache position and length are zero. The body strings, body counts, actual consumed frontiers, return values, confirmation/proof state, dispatch verdicts and CRC information/checkwords agree across chunks. CRC JSON records themselves still contain ordinary provider-field differences.

The mechanism is explicit in the frozen recorder: `__wrap_getDibitSoft` records `read_start + rtl_symbol_cache_pos` after every call without a delivered-sample/EOF qualifier ([observer.c](../experiments/nxdn_engine_gap/observer.c), lines 110–118). At EOF, the provider leaves `read_start` unchanged (lines 147–158), while the real cache refill clears position and length ([dsd_symbol.c](../upstream/dsd-neo/src/dsp/dsd_symbol.c), lines 887–892 and 1017–1023). Failed sample acquisition returns symbol zero (lines 1543–1553 and 2176–2178); the real dibit path still digitizes the result ([dsd_dibit.c](../upstream/dsd-neo/src/core/frames/dsd_dibit.c), lines 1012–1030). The frame's finite body loop continues ([nxdn_frame.c](../upstream/dsd-neo/src/protocol/nxdn/nxdn_frame.c), lines 633–637). Consequently, the position entries go backward even though the true pop trace never repeats or goes backward.

This explains the recorded difference; it does not justify changing the preregistered exact-event equality gate after execution. The older frame-level signature omits body positions, whereas this study's runner compares them; the stricter runner correctly retains the failure.

## Why payload h0 exposes the path

In the immutable h0-S numeric vector, zero-based dibits 137–146 are `3331330011`. Their sign-only projection is `3331331111`, one of the positive patterns accepted by the real hunt ([dsd_frame_sync.c](../upstream/dsd-neo/src/dsp/dsd_frame_sync.c), lines 1645–1657 and 2355–2371). The following eight transmitted dibits are `30330222`. Independently applying PN95 seed 228 gives full LICH **0x90**, profile **0x48**, with matching parity. That supported profile selects the Japanese DCR/PICH-TCH path ([nxdn_descramble.c](../upstream/dsd-neo/src/protocol/nxdn/nxdn_descramble.c), lines 32–45; [nxdn_frame.c](../upstream/dsd-neo/src/protocol/nxdn/nxdn_frame.c), lines 146, 184–218 and 536–540).

The corresponding h1 sign window is `1333133131`, which is not in the accepted set. The h0 raw search endpoints repeat at source-frame start +2940 samples, placing the body at the wrong canonical phase. The last such dispatch starts at delivered frontier 30460, or 30480 after repeat20, and runs beyond the finite input. This exact encoded-pattern and dispatch-position correspondence supports the payload-specific explanation; it is not a claim that all h1 payloads or arbitrary payloads avoid incidental syncs.

Those wrong-phase h0 bodies are **not** attributed to a canonical source frame. Warm cases retain historical confirmation and return 1; the cold case returns 0. None of these incidental bodies reports a new current proof. Their Japanese DCR channel path is outside the three recorded SACCH6/FACCH12 hooks: absence of hook events is not independent validation of every channel CRC on that path. Stderr reports CRC errors, but this review does not use that text as an independent channel oracle.

## Source truth and retained costs

Detailed independent attribution covered the three flagged scenarios for both payloads, both options and both chunks: **24 observed invocations, 174 dispatched frames, 98 canonical attributions and 74 full correct frames**. Every attributed body is byte-identical to its immutable numeric source vector at the credited interval. Independent mapped-frontier attribution and final expected-channel truth agree with the saved audits, with no accepted recorded channel lacking exact expected source content in this scope. Every affected EOF frame remains unattributed and uncredited.

Across the complete matrix, independently recomputed **1,908 recorded CRC6/CRC12 events** match their reported computed values. This recomputation distinguishes computed and received checks; it does not treat soft-pass as final acceptance. All **1,243 files** listed in the final report still match their hashes. Full details, raw-event hashes, per-frame attributions and comparison records are in [the review JSON](nxdn-recovery-chunk-review.json).

The unfavorable recovery costs are real and remain visible despite identical chunk outcomes:

- h0 warm_sync_invert and warm_repeat20 recover source ordinals 2 and 3 only, versus clean 2–7: ordinals 4–7 are missing under both options, with no complete post-fault endpoint before EOF.
- h1 for the same warm faults recovers 2, 3, 6 and 7 under both options: ordinals 4 and 5 are missing. Recovery is 7680 canonical samples later than clean; repeat20 is 7700 delivered samples later because of its 20 added samples. There is no option-on warm gain.
- h0 cold_sync_blank recovers no full source frame under either option. h1 recovers 2–7 with option off and 1–7 with option on. Its individual 3840-sample cold difference cannot overcome the missing h0 endpoint or pass the warm hypothesis.

The saved quality result also remains false because all four warm_drop20 base cases are absent from the successfully inspected grid after 16 audio-buffer guard failures. That separate failure is outside this focused diagnosis. There is no qualifying warm scenario. The study's aggregate failure and censored outcomes cannot be replaced by a favorable subset.

Any future EOF-recorder correction needs a separately registered experiment with an explicit distinction between a dibit call and actual delivered samples. It must preserve this completed run and its failure.

Evidence report SHA-256: `c32a8922e7e4a939194a1a71c8da0cd0b74faf9a79740317830e26b027b0337f`.
