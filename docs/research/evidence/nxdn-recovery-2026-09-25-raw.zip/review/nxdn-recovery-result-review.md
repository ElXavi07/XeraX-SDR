# Independent recovery result review — 2026-09-25

The single registered matrix is complete: **216 invocations, 200 individually
passing measurement audits, 16 retained measurement failures**. Every native
process exited zero and reported zero recorder errors and finite-source EOF.
That does not override the Python measurement contract. The final aggregate
`measurement_pass` and `warm_progression_pass` are both false.

This review reads existing evidence only. It does not modify the inspector,
preregistration, input vectors, raw events, reports or product source; it does not
rerun a native process. The companion JSON records exact input/result/source hashes
and all 16 affected cases. The six separately reported chunk differences remain
failures and are being reviewed independently by the other agent.

## Failure mechanism observed in all 16 cases

The failures are exactly `warm_drop20`, for both held-out payloads, both chunks,
both acquisition settings and both observer settings. The source deletes original
samples `[16217,16237)`, starting 17 samples into the frame-4 LICH interval.

1. A prior control frame has confirmed the stream. Its three observed channel
   CRCs pass; for the representative h0/fast0/chunk37 case it completes at
   delivered frontier 16000, with return 2, evidence 2 and proof 1.
2. The affected search returns positive NXDN synchronization at delivered
   frontier 16200. The subsequent 182-dibit body is consumed through 19840.
3. Independently removing PN95 whitening from the logged first eight body dibits
   `33113110` yields `33313332`. The reconstructed full LICH is **0xEF**, with
   seven-bit profile **0x77**. Its received parity bit and upper-nibble parity
   are both 1. The transmitted source profile was full **0x83 / 0x41**.
4. The existing profile table routes 0x77 to **IDAS, SCCH and voice=3**. Stderr
   independently contains `IDAS D RTCH2 Voice SCCH`. Profile 0x41 normally routes
   this input to data with SACCH and two FACCH1 blocks.
5. The voice guard uses sticky `nxdn_confirm_is_confirmed(state)`. The stream was
   already confirmed, so the parity-valid wrong LICH can enter the voice path
   despite the affected frame acquiring no current evidence.
6. The affected frame ends with **confirmed 1, evidence 0, proof 0, return 1** and
   audio indices **[0,640,0,0]**, up from [0,0,0,0]. This triggers the frozen
   inspector's explicit requirement that all four audio indices remain zero.

These observations are identical across the 16 cases. The eight observed variants
contain no registered SACCH/FACCH CRC callback during the affected frame. That
does **not** mean no CRC was attempted: this alternate route calls the SCCH CRC7
decoder, which the frozen observer does not instrument. Its actual computed and
received CRC7 values are unavailable. The frame's zero final evidence provides
no accepted current evidence; it must not be described as a CRC-proved voice frame.

All affected body-frontier positions map to original positions exactly 20 samples
later than the expected canonical coordinates. They lie outside the registered
strict `(-20,20)` attribution interval. The recorded delivered interval
16220..19840 maps to original frontiers 16240..19860, extending 20 samples beyond
the original frame-4 end. This is a consequence of the explicit deletion and the
receiver's body consumption; it is not corrected by relabeling timestamps.

For diagnostic context only, projecting the affected observer-off/on raw rows
with the frozen common-field convention gives parity in all eight pairs. This
does not rehabilitate those failed audits or make them eligible recovery samples.

## Audio bookkeeping, PCM and playback are different observations

The map file links real `nxdn_voice`, `processMbeFrameSoft`, `processAudio` and
`playSynthesizedVoiceMS`; these are not the old standalone frame-test stubs.
The source path for voice=3 processes four AMBE blocks. The audio defaults include
short output, 8000 samples/s and `dmr_stereo=1`; the harness does not change those
defaults. The shared post-vocoder left path can stage 160 samples per block even
with `audio_out=0`. `processAudio` advances both left indices; mono playback resets
the working index while the cumulative index remains, matching `[0,640,0,0]`.

This establishes an **internal buffer/staging side effect**. The observer does
not log PCM sample values, energy, vocoder return values or exact call counts.
Consequently it does not establish that the PCM was nonzero, intelligible,
correct speech, or even successful AMBE synthesis. A source-path inference of
four 160-sample staging blocks must not be presented as directly counted PCM
emission.

The harness explicitly sets `audio_out=0`, never opens WAV outputs and checks that
those settings remain disabled. The output routine returns without writing when
`audio_out != 1`. Thus this evidence supports no claim of audio emitted to a
device, played through speakers or heard by a person. The finding is still a
useful routing/measurement failure and remains rejected under the original gate.

Nor is this a fresh-proof false acceptance: affected return 1 means historical
confirmation; `proved=0` and `evidence=0` remain distinct from return 2/current
proof. Product behavior with real voice, enabled audio and RF impairments is
outside this experiment.

## Artifact and truth preservation

Independent hash verification passes for:

| Evidence group | Files checked |
| --- | ---: |
| Before-execution frozen files | 146 |
| Final report output identities | 1243 |
| Pre-recorded legacy anchor files | 16 |
| Actual live executed scripts | 4 |
| Other recorded native source files | 8 |
| Preflight inputs copied into this run | 112 |
| Original preflight input directory | 112 |
| Preserved preflight audit artifacts | 3 |

The normalized frame hash remains the expected candidate hash
`457bc11c3672d7cffc6b70facd19afe1de3c6fa433d075d5f511bb44b8ad8181`.
All 16 new legacy events/pop files byte-match their old anchor counterparts.
The input audit was not rewritten. The final run records commit
`78b584687fef430fcae38b531f87d9e2291ce101` and the expected frozen executable.

Polynomial long division independently reproduces **all 1908 recorded CRC6/CRC12
computed values**, with zero mismatches. This checks those recorded computations,
not unobserved SCCH values or complete validity of the failed cases. Audio-related
source files read for the path explanation match the old source lineage after
line-ending normalization; the frame file differs by the already registered and
normalized candidate correction.

The final report's cold-drop1/cold-repeat1 candidate gain labels are not a passing
experiment: aggregate quality and measurement gates fail, and there are no
qualifying warm scenarios. Preserve this as a failed, informative recovery study.
Any expanded observer capable of SCCH/voice/PCM inspection needs a separate
registered experiment; it cannot retroactively relax this matrix's conditions.
