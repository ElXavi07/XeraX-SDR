"""Package retained negative recovery evidence; never execute a receiver."""
import collections
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "build/nxdn-recovery-pair-20260925"
OUT = ROOT / "docs/research/evidence"


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def require(value, detail):
    if not value:
        raise RuntimeError(detail)


report = json.loads((EVIDENCE / "report.json").read_text())
for name, digest in report["files"].items():
    require(sha(EVIDENCE / name) == digest, "Native evidence changed: " + name)
preserved = json.loads((ROOT / "build/nxdn-recovery-preservation-before.json").read_text())
for category in preserved.values():
    for name, digest in category.items():
        require(sha(ROOT / name) == digest, "Protected file changed: " + name)
after = ROOT / "build/nxdn-recovery-preservation-after.json"
with after.open("x", encoding="utf-8") as f:
    json.dump({"pass": True, **preserved}, f, indent=2)

extras = [
    "build/nxdn-recovery-input-audit.py", "build/nxdn-recovery-input-audit.json", "build/nxdn-recovery-input-audit.md",
    "build/nxdn-recovery-design-review.md", "build/nxdn-recovery-primary-research.md",
    "build/nxdn-recovery-result-review.md", "build/nxdn-recovery-result-review.json",
    "build/nxdn-recovery-chunk-review.md", "build/nxdn-recovery-chunk-review.json",
    "build/nxdn-recovery-framework-tests.log", "build/nxdn-recovery-framework-tests-optimized.log",
    "build/nxdn-recovery-ci-push.json", "build/nxdn-recovery-ci-push.log",
    "build/nxdn-recovery-ci-pr.json", "build/nxdn-recovery-ci-pr.log",
    "build/nxdn-recovery-preservation-before.json", "build/nxdn-recovery-preservation-after.json",
    "build/package-nxdn-recovery.py",
]
members = {"native/" + p.relative_to(EVIDENCE).as_posix(): p for p in EVIDENCE.rglob("*") if p.is_file()}
members.update({"review/" + Path(name).name: ROOT / name for name in extras})
for p in (ROOT / "build").glob("nxdn-recovery-*-review.py"):
    members["review/" + p.name] = p
identities = {name: {"bytes": p.stat().st_size, "sha256": sha(p)} for name, p in members.items()}
archive = OUT / "nxdn-recovery-2026-09-25-raw.zip"
require(not archive.exists(), "Do not replace an existing archive")
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, p in sorted(members.items()):
        z.writestr(name, p.read_bytes())
    z.writestr("FILES.json", json.dumps(identities, indent=2) + "\n")
with zipfile.ZipFile(archive) as z:
    require(z.testzip() is None, "Corrupt ZIP")
    require(len(z.namelist()) == len(set(z.namelist())) == len(identities) + 1, "Duplicate/missing archive member")
    for name, identity in identities.items():
        data = z.read(name)
        require(len(data) == identity["bytes"] and hashlib.sha256(data).hexdigest() == identity["sha256"], name)

counts = collections.Counter()
for attempt in report["attempts"]:
    if not attempt["measurement_pass"] or attempt["observed"] != 1:
        continue
    path = EVIDENCE / "runs" / attempt["id"] / str(attempt["fast"]) / "1/audit.json"
    audit = json.loads(path.read_text())["audit"]
    counts["observed_invocations_passing_individual_inspector"] += 1
    for frame in audit["frames"]:
        counts["frames"] += 1
        counts["source_attributed"] += bool(frame["source"])
        counts["full_correct_frames"] += frame["full_correct"]
        counts["supported_current_proofs"] += frame["supported_current_proof"]
        counts["EOF_frames"] += bool(frame["end"]["eof"])
        counts["final_CRC_events"] += len(frame["crcs"])
        counts["incorrect_or_unattributed_accepted_channels"] += sum(c["accepted"] and not c["exact_source_content"] for c in frame["channel_results"])

summary = {"schema": 1, "kind": "nxdn_recovery_retained_negative_measurement",
    "preregistration_commit": "38552e4b7d7391a79f4599ff9d6bbc2ce6601371",
    "execution_commit": json.loads((EVIDENCE / "before-execution.json").read_text())["commit"],
    "native_invocations": len(report["attempts"]), "native_exit_zero": sum(a["exit_code"] == 0 for a in report["attempts"]),
    "measurement_pass": report["measurement_pass"], "warm_progression_pass": report["warm_progression_pass"],
    "measurement_failures": report["measurement_failures"], "chunk_differences": report["chunk_differences"],
    "observer_differences": report["observer_differences"], "legacy_anchor_differences": report["anchor_differences"],
    "executed_sources_preserved": report["executed_sources_preserved"], "frozen_evidence_preserved": report["preservation_pass"],
    "release_files_preserved": len(preserved["release_files"]), "protected_native_files_preserved": len(preserved["protected_native_files"]),
    "individually_valid_observed_subset_including_legacy": dict(counts),
    "quality": report["quality"], "native_report_sha256": sha(EVIDENCE / "report.json"),
    "raw_archive": {"file": archive.name, "bytes": archive.stat().st_size, "sha256": sha(archive),
                    "entries": len(identities) + 1, "every_entry_reopened_and_verified": True},
    "scope": "Windows finite discriminator replay; overall measurement gate failed. Subset outcomes are descriptive only. No native rerun, product change, new package, physical RF/phone/audio or Linux native recovery claim."}
with (OUT / "nxdn-recovery-2026-09-25.json").open("x", encoding="utf-8") as f:
    json.dump(summary, f, indent=2); f.write("\n")
print(json.dumps({"measurement_pass": summary["measurement_pass"], "native_invocations": summary["native_invocations"], "raw_archive": summary["raw_archive"]}))
