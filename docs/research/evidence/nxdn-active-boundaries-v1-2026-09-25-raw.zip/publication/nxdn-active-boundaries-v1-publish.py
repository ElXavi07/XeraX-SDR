"""Package completed active-boundary evidence without native execution."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
STUDY = ROOT / 'build/nxdn-active-boundaries-v1-run-20260925'
DEST = ROOT / 'docs/research/evidence'
STEM = 'nxdn-active-boundaries-v1-2026-09-25'
ARCHIVE, INDEX = DEST / (STEM + '-raw.zip'), DEST / (STEM + '.json')
HARNESS = '2a5af570a71d03a7753c4d73ba11c0c379e2b165'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def need(ok, reason):
    if not ok: raise ValueError(reason)

need(not ARCHIVE.exists() and not INDEX.exists(), 'Existing publication is immutable')
raw_report = (STUDY / 'report.json').read_bytes()
need(sha(raw_report) == '058cf74cb23a390d0815e20ae0a2faeb8cf8e2c4e2c4fee98beb04ac290864db', 'Report identity changed')
report = json.loads(raw_report)
need(report['measurement_pass'] and report['preservation_pass'] and not report['progression_pass']
     and not report['product_promotion'], 'Measured failed result changed')
need(len(report['attempts']) == 16 and all(a['exit_code'] == 0 for a in report['attempts']), 'Attempt inventory changed')
for name, digest in report['files'].items():
    need(sha(STUDY.joinpath(*name.replace('\\', '/').split('/')).read_bytes()) == digest, 'Report file changed: ' + name)
before = json.loads((STUDY / 'before-execution.json').read_bytes())
need(before['commit'] == HARNESS and before['receiver_rebuilt'] is False, 'Wrong reused-executable provenance')
groups = ('frozen_files', 'original_files', 'copied_identities', 'configured_sources', 'protected')
for group in groups:
    need(all(Path(p).is_file() and sha(Path(p).read_bytes()) == digest for p, digest in before[group].items()), 'Preservation failed: ' + group)
audit_path = ROOT / 'build/nxdn-active-boundaries-v1-results-audit.json'
audit_raw = audit_path.read_bytes(); audit = json.loads(audit_raw)
need(audit['audit_pass'], 'Independent raw audit failed')
ci = {}
for event, number in (('push',36193709852), ('pr',36193715105)):
    value = json.loads((ROOT / f'build/nxdn-active-boundaries-v1-ci-{event}-status.json').read_bytes())
    need(value['databaseId'] == number and value['headSha'] == HARNESS and value['status'] == 'completed'
         and value['conclusion'] == 'success' and len(value['jobs']) == 2
         and all(job['conclusion'] == 'success' for job in value['jobs']), 'Wrong CI identity or result')
    ci[event] = number

payload = {'study/' + p.relative_to(STUDY).as_posix(): p.read_bytes()
           for p in sorted(STUDY.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
extras = ['results-audit.py','results-audit.json','results-audit.md','summary.py','summary.json',
          'ci-push.log','ci-pr.log','ci-push-status.json','ci-pr-status.json','execution.log',
          'next-guard-design.md']
for suffix in extras:
    p = ROOT / ('build/nxdn-active-boundaries-v1-' + suffix)
    payload['publication/' + p.name] = p.read_bytes()
for p in (Path(__file__), ROOT / '.github/workflows/nxdn-active-boundaries-framework.yml'):
    payload['publication/' + p.name] = p.read_bytes()
payload['licenses/XeraX-LICENSE.txt'] = (ROOT / 'LICENSE').read_bytes()
payload['licenses/dsd-neo-LICENSE.txt'] = (ROOT / 'upstream/dsd-neo/LICENSE').read_bytes()
build_audit = json.loads((STUDY / 'frozen/receiver/nxdn-clear-routing-v1-build-audit.json').read_bytes())
headers = [Path(p) for p in build_audit['dependencies'] if p.endswith('include\\mbelib-neo\\mbelib.h')]
need(len(headers) == 1, 'Codec header identity missing')
for p in sorted((headers[0].parents[2] / 'share').glob('*/copyright')):
    payload['licenses/installed/' + p.parent.name + '.txt'] = p.read_bytes()
payload['publication/mbelib.h'] = headers[0].read_bytes()
payload['publication/mbelib-source.tar.gz'] = (ROOT / 'build/mbelib-voice-words-v1-source.tar.gz').read_bytes()
payload['README.txt'] = (
    'XeraX NXDN active-boundary evidence, 25 September 2026\n'
    'Registration b3a8cee; frozen harness ' + HARNESS + '.\n'
    'Exactly 16 new Windows receiver processes, all exit zero. No rebuild.\n'
    'Measurement, exposure and parity restriction PASS; finite voice safety and\n'
    'subsequent clean retention FAIL. No app or product promotion.\n'
    'There are 96 real synthesis calls, 40 with unavailable slot input; 56\n'
    'completely source-owned occurrences preserve exact known FEC/synthesis bits.\n'
    'The exposed bad-LICH sequence retains only 12 of 20 subsequent clean words.\n'
    'Complete early slots survive later EOF, which a future fix must preserve.\n\n'
    'study/ contains every attempt, raw events and actual sample-pop traces, inputs,\n'
    'pre-execution identities, reviews, frozen observer/checker sources, the unchanged\n'
    'research executable and runtime DLLs. No historical receiver case was rerun.\n'
    'The four input anchors are copied previous observations, not new invocations.\n'
    'The receiver source baseline is\n'
    'https://github.com/ElXavi07/XeraX-SDR/tree/289a82f8fd9c0495b64bf948fd45413bc63261c4\n'
    'The included executable is not a phone APK or Windows application installer.\n'
    'publication/ includes separate post-execution audits, CI and a next-candidate\n'
    'design proposal; these do not constitute pre-execution evidence or a fix.\n\n'
    'Offline review without native execution: import analyze from\n'
    'study/frozen/source_repository/experiments/nxdn_active_boundaries_v1; retain\n'
    'that hierarchy and sibling frozen helpers. Call validate_inputs(study/inputs),\n'
    'inspect(rows,trace_path,case,manifest,inputs,detail) for each of the 16 saved\n'
    'events.jsonl/pops.u32le pairs, then compare the complete grid. The result must\n'
    'reproduce measurement=true and progression=false, with failed safety/retention.\n'
    'Absolute identities refer to the original machine and are not rewritten.\n'
    'No speech, playback, complex-I/Q, RF, privacy, GPU or performance claim.\n'
).encode('utf-8')
inventory = {'schema':1,'kind':'nxdn_active_boundaries_v1_archive','native_execution_by_publication':False,
             'files':{name:{'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(payload.items())}}
payload['archive-manifest.json'] = (json.dumps(inventory,indent=2)+'\n').encode()
with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(payload.items()):
        z.writestr(zipfile.ZipInfo(name,date_time=(2026,9,25,0,0,0)),raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(ARCHIVE) as z:
    need(len(z.namelist()) == len(payload) and set(z.namelist()) == set(payload) and z.testzip() is None
         and all(z.read(name) == raw for name,raw in payload.items()), 'Archive contents changed')
publication = {'schema':1,'kind':'nxdn_active_boundaries_v1','registration_commit':'b3a8cee4608db93ba3bc446281ed1ded954a6270',
    'harness_commit':HARNESS,'receiver_baseline':before['receiver_product_baseline'],'receiver_rebuilt':False,
    'measurement_pass':True,'preservation_pass':True,
    **{k:v for k,v in report['comparison'].items() if k.endswith('_pass')},'product_promotion':False,
    'native_invocations':16,'native_exit_zero':16,
    'native_totals':{'frames':56,'soft_fec_calls':96,'synthesis_calls':96,'source_exact_routes':56,
                     'unavailable_slot_synthesis_calls':40,'erasure_flag_calls':4,'repeat_flag_calls':0,'mute_flag_calls':0},
    'prefixes':{'6159':{'complete_retained_words':0,'unavailable_synthesis_calls':4},
                '6160':{'complete_retained_words':1,'unavailable_synthesis_calls':3},
                '6161':{'complete_retained_words':1,'unavailable_synthesis_calls':3}},
    'prefix_count_scope':'per invocation; each has four synthesis calls',
    'bad_lich':{'actually_exposed':True,'rejected_without_target_voice':True,'later_expected_words':20,'later_exact_words':12,
                'missing_source_ordinals':[2,3],'same_clear_epoch_terminated':True},
    'report_sha256':sha(raw_report),'report_files':len(report['files']),
    'preservation_group_counts':{g:len(before[g]) for g in groups},
    'independent_results_audit':{'sha256':sha(audit_raw),'audit_pass':True},
    'ci':{'tests':41,'modes':['normal','optimized'],'platforms':['Windows','Linux'],**ci,'native_matrix_in_ci':False},
    'archive':{'file':ARCHIVE.name,'bytes':ARCHIVE.stat().st_size,'entries':len(payload),
               'sha256':sha(ARCHIVE.read_bytes()),'every_entry_verified':True},
    'limits':['synthetic clear conventional NXDN48 discriminator input, not complex I/Q or RF',
              'real finite-input safety and subsequent clean-retention failures remain unresolved',
              'internal synthesis does not establish speaker output or intelligibility',
              'no new receiver policy, native rebuild, key/privacy operation or speed measurement',
              'released Android and Windows packages unchanged']}
INDEX.write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
print(json.dumps(publication['archive']))
