"""Audit saved active-boundary observations; no experiment/encoder imports or native calls."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
STUDY = ROOT / 'build/nxdn-active-boundaries-v1-run-20260925'
OUT = ROOT / 'build/nxdn-active-boundaries-v1-results-audit'
NAMES = ('active_prefix_6159', 'active_prefix_6160', 'active_prefix_6161', 'active_bad_lich')
OPTIONAL = {'crc', 'lich', 'scch', 'voice_begin', 'voice_end', 'mbe_begin', 'mbe_end', 'audio_begin', 'audio_end', 'fec_input'}
failures = []
checks = 0


def check(ok, why):
    global checks
    checks += 1
    if not ok: failures.append(why)


def need(ok, why):
    if not ok: raise ValueError(why)


def sha(raw): return hashlib.sha256(raw).hexdigest()


def parse(raw):
    def unique(pairs):
        out = {}
        for k, v in pairs:
            need(k not in out, 'Duplicate JSON key ' + k); out[k] = v
        return out
    def nonfinite(value): raise ValueError('Nonfinite JSON ' + value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=nonfinite)


def bits(raw): return ''.join(f'{b:08b}' for b in raw)


def crc(info, width):
    value = (1 << width) - 1
    for bit in info:
        carry = (value >> (width - 1)) ^ int(bit)
        value = (value << 1) & ((1 << width) - 1)
        if carry & 1: value ^= {6: 0x27, 12: 0x80f}[width]
    return value


def decode_whitening(body, seed):
    register = seed or 228
    out = []
    for d in body:
        out.append(int(d) ^ ((register & 1) << 1))
        register = (register >> 1) | (((register ^ (register >> 4)) & 1) << 8)
    return out


def oracle():
    base = STUDY / 'inputs/parent/reference'
    raw = (base / 'linked-source.bin').read_bytes()
    need(sha(raw) == '8f4116e67a4c950a524c8568caf17d550e9b0b0bbdac3f9e3761ce76c0056e41', 'Source word identity')
    words = []
    for n in range(0, 130, 13):
        pair = bits(raw[n:n+13]); words.extend((pair[:49], pair[49:98]))
    records = (base / 'primary.records96').read_bytes()
    packed = (base / 'input.records41').read_bytes()
    channels = (base / 'voice-reference.channels9').read_bytes()
    need(sha(records) == 'bedb3ae824c357e68e8d2883b808b357e228e74c7ce253acf0a41cf257234c0b', 'AIR reference identity')
    need(sha(packed) == '74c0fd60a05624623157f82598cf20ad9da7f9ea86a957b396933672f5efcaab', 'Input record identity')
    need(sha(channels) == '05ed6f2d7c548e6b6e94e81bb12534afde0c2e13301791a8f1d4d2778dd6eed3', 'Channel reference identity')
    frames = []
    for n in range(9):
        rec = packed[n*41:(n+1)*41]; air = records[n*96+48:(n+1)*96]
        slots = {} if n in (0,8) else {2:2,3:3} if n == 6 else {0:4,1:5} if n == 7 else {s:4*(n-1)+s for s in range(4)}
        frames.append({'ordinal': n, 'start': 640+3840*n, 'slots': slots,
                       'air_dibits': [(b >> shift)&3 for b in air for shift in (6,4,2,0)],
                       'lich': rec[0], 'sacch': bits(rec[1:5])[:26], 'facch': bits(rec[5:15])})
    return frames, words, [bits(channels[n*9:(n+1)*9]) for n in range(20)]


def complete(call):
    return (call['eof_before'] == call['eof_after'] == 0 and call['after']-call['before'] == 20
            and ((call['symbol_after']-call['symbol_before']) & 0xffffffff) == 1)


def identify(frame, indices, truth):
    calls = frame['end']['body_calls']
    if frame['begin']['sync'] != 28 or any(i >= len(calls) or not complete(calls[i]) for i in indices): return None
    found = []
    for source in truth:
        deviations = [calls[i]['after'] - (source['start'] + 20*(11+i)) for i in indices]
        if all(-20 < d < 20 for d in deviations): found.append((source['ordinal'], min(deviations), max(deviations)))
    need(len(found) <= 1, 'Ambiguous source interval')
    return found[0] if found else None


def clear(call):
    return call is not None and tuple(call[k] for k in ('phase','kind','source','target','crypto','algid','kid','audio_permitted')) == (1,2,901,1201,1,0,0,1)


def semantics(rows, chunk=False):
    ignore = {'seq','frontier','pops','observed','crcs','skipped'}
    if chunk: ignore |= {'provided','cache_pos','cache_len','read_start','chunk'}
    return [{k:v for k,v in r.items() if k not in ignore} for r in rows if r['kind'] not in OPTIONAL]


def inspect(rows, trace, scenario, chunk, mode, samples, truth, words, channels):
    tag = f'{scenario}-c{chunk}/{mode}'
    def test(ok, why): check(ok, tag+':'+why)
    test([r['seq'] for r in rows] == list(range(len(rows))), 'sequence')
    test(rows[0]['kind']=='configuration' and rows[-1]['kind']=='summary', 'stream bounds')
    summary = rows[-1]
    test((summary['fast'],summary['chunk'],summary['observed'],summary['samples']) == (1,chunk,mode,samples), 'invocation identity')
    test(summary['errors']==summary['starts']==summary['tunes']==0 and summary['eof']==1, 'native error/boundaries')
    pop_ids = list(struct.unpack('<'+'I'*(len(trace)//4), trace)) if len(trace)%4 == 0 else None
    test(pop_ids == (list(range(samples)) if mode else []), 'exact real sample ownership trace')
    test(summary['skipped']==0 and summary['pops']==(samples if mode else 0), 'pop accounting')
    if not mode: test(not any(r['kind'] in OPTIONAL for r in rows), 'detail leaked into off mode')
    frames=[]; active=None
    for r in rows:
        if r['kind']=='frame_begin':
            need(active is None, tag+':nested frame'); active={'begin':r,'events':[]}
        elif r['kind']=='frame_end':
            need(active is not None, tag+':unowned frame end'); active['end']=r;frames.append(active);active=None
        elif active is not None:active['events'].append(r)
    test(active is None and len(frames)==summary['frames']==summary['dispatches'], 'frame totals')
    call_classes=Counter(); slot_records=[]; frame_records=[]; crc_records=[]; quality=[]
    all_fec=[];all_synth=[];actual_occurrences=[];missing=[];unsafe=[];source_frame_map={}
    for f in frames:
        e=f['end']; fid=f['begin']['frame']; calls=e['body_calls']; body=e['body']; previous=None
        test(len(calls)==len(body)==len(e['body_positions'])==e['body_count'], 'body dimensions')
        for i,c in enumerate(calls):
            test(0 <= c['before'] <= c['after'] <= samples, 'body frontier')
            if previous is not None:test((c['before'],c['eof_before'],c['symbol_before'])==previous, 'body call chain')
            previous=(c['after'],c['eof_after'],c['symbol_after'])
            if complete(c): label='complete'
            else:
                test(c['eof_after']==1 and c['after']==samples and c['symbol_before']==c['symbol_after']
                     and 0<=c['after']-c['before']<20, 'invalid partial/empty call')
                label='already_eof' if c['eof_before'] else 'crossing_partial' if c['after']>c['before'] else 'crossing_empty'
                if c['eof_before']:test(c['before']==c['after'], 'new delivery after EOF')
            call_classes[label]+=1
            test(e['body_positions'][i] == (c['after'] if label=='complete' else 0), 'unavailable position exposed')
            if mode:
                test(pop_ids[c['before']:c['after']]==list(range(c['before'],c['after'])), 'call lacks pop interval')
        loc=identify(f,range(8),truth); ordinal=loc[0] if loc else None
        if ordinal is not None:
            test(ordinal not in source_frame_map, 'duplicate source frame'); source_frame_map[ordinal]=f
        target=truth[ordinal] if ordinal is not None else None
        bad=bool(scenario=='active_bad_lich' and ordinal==1)
        if target:
            supplied=list(target['air_dibits'])
            if bad:supplied[17]^=2
            for i,c in enumerate(calls):
                if complete(c) and int(body[i])!=supplied[10+i]: quality.append({'reason':'supplied_dibit_mismatch','frame':fid,'index':i})
        for event in f['events']:
            if event['kind']=='crc':
                width=6 if event['channel']==1 else 12
                computed=crc(event['bits'],width); received=event['received']
                test(type(received) is int and 0<=received<(1<<width),'received CRC range')
                test(computed==event['computed'] and received==event['received'], 'CRC arithmetic/received field')
                test(not event['soft_pass'] or computed==received, 'contradictory soft CRC pass')
                owned_indices=range(8,38) if width==6 else range(38,110) if event['part'] in (0,1) else range(110,182)
                channel_loc=identify(f,owned_indices,truth)
                supported=bool(target and channel_loc and channel_loc[0]==ordinal
                               and event['bits']==target['sacch' if width==6 else 'facch']
                               and received==computed==crc(target['sacch' if width==6 else 'facch'],width))
                crc_records.append({'frame':fid,'source':ordinal,'channel':event['channel'],'part':event['part'],
                                    'accepted':computed==received,'full_source_support':supported})
                if computed==received and not supported:quality.append({'reason':'accepted_CRC_without_complete_known_channel','frame':fid})
        routes=[]; route=None
        for r in f['events']:
            k=r['kind']
            if k=='route_begin':need(route is None,'nested route');route={'begin':r,'fec':[],'synthesis':[],'inputs':[]}
            elif k=='route_end':
                need(route is not None,'unowned route end');route['end']=r;routes.append(route);route=None
            elif k in ('fec','synthesis','fec_input'):
                need(route is not None,'unowned API observation');test(r['route_id']==route['begin']['route_id'],'API route ID')
                route[{'fec':'fec','synthesis':'synthesis','fec_input':'inputs'}[k]].append(r)
        test(route is None,'unfinished route')
        plain=decode_whitening(body,f['begin']['pn95'])
        for route in routes:
            b=route['begin'];slot=b['slot'];indices=list(range(38+36*slot,74+36*slot))
            full=all(i<len(calls) and complete(calls[i]) for i in indices)
            slot_loc=identify(f,list(range(8))+indices,truth)
            source_id=target['slots'].get(slot) if target else None
            outer=[r for r in route['fec'] if r['outer']]; synth=route['synthesis']
            all_fec.extend(route['fec']);all_synth.extend(synth)
            test(b['confirmed']==1,'unconfirmed route')
            for r in route['fec']:
                test(r['input_unchanged']==1,'FEC mutated input')
                test((r['bits49'] is None and r['result'] is None) if r['status']<0 else isinstance(r['bits49'],str) and len(r['bits49'])==49 and r['result'] is not None,'FEC status/output contract')
            for r in synth:
                test(r['input_unchanged']==1,'synthesis mutated input')
                test(r['result_after'] is None if r['status']<0 else r['result_after'] is not None,'synthesis negative-result contract')
            actual_channel=''.join(f'{d:02b}' for d in plain[indices[0]:indices[-1]+1])
            if mode:
                inputs=[r for r in route['inputs'] if r['outer']]
                test(len(inputs)==len(outer),'detailed FEC input count')
                for r in inputs:
                    test(r['channel72']==actual_channel,'actual supplied matrix channel')
                    expected=['0']*96
                    for p,bit in enumerate(actual_channel):
                        k=18*(p%4)+p//4
                        rr,cc=(0,23-k) if k<24 else (1,46-k) if k<47 else (2,57-k) if k<58 else (3,71-k)
                        expected[24*rr+cc]=bit
                    test(r['matrix96']==''.join(expected),'actual 96-cell FEC matrix')
            known=bool(slot_loc and source_id is not None and not bad)
            exact=bool(known and actual_channel==channels[source_id] and len(outer)==len(synth)==1
                       and outer[0]['status']>=0 and outer[0]['bits49']==words[source_id]
                       and synth[0]['input49']==words[source_id])
            if known:
                actual_occurrences.append((ordinal,slot,source_id))
                if not exact:quality.append({'reason':'complete_source_bits_or_route_mismatch','source':ordinal,'slot':slot})
            if synth and not full:unsafe.append({'frame':fid,'source':ordinal,'slot':slot,'route_id':b['route_id'],
                'complete_dibits':sum(i<len(calls) and complete(calls[i]) for i in indices),'synthesis_calls':len(synth)})
            if bad and route['fec']+synth:quality.append({'reason':'rejected_source_has_API_call','frame':fid})
            slot_records.append({'frame':fid,'source':ordinal,'slot':slot,'source_word':source_id,
                'complete_dibits':sum(i<len(calls) and complete(calls[i]) for i in indices),'fully_available':full,
                'source_owned':known,'exact_complete_source_route':exact,'fec_count':len(route['fec']),
                'synthesis_count':len(synth),'fec_statuses':[r['status'] for r in route['fec']],
                'synthesis_statuses':[r['status'] for r in synth],
                'fec_bits49':[r['bits49'] for r in outer],'synthesis_inputs49':[r['input49'] for r in synth],
                'diagnostic_source_bit_differences':[[i for i,(a,z) in enumerate(zip(words[source_id],r['bits49'])) if a!=z]
                    if source_id is not None and r['bits49'] is not None else None for r in outer],
                'synthesis_flags':[r['result_after']['flags'] if r['result_after'] else None for r in synth]})
        if target and not bad:
            for slot,sid in target['slots'].items():
                loc_slot=identify(f,list(range(8))+list(range(38+36*slot,74+36*slot)),truth)
                if loc_slot:
                    count=sum(r['begin']['slot']==slot for r in routes)
                    if count!=1:missing.append({'source':ordinal,'slot':slot,'source_word':sid,'routes':count})
        lich=[r for r in f['events'] if r['kind']=='lich']
        frame_records.append({'frame':fid,'source':ordinal,'phase':list(loc[1:]) if loc else None,
            'body_count':len(calls),'complete_calls':sum(map(complete,calls)),'result':e['value'],'confirmed':e['confirmed'],
            'begin_sample':calls[0]['before'] if calls else None,'end_sample':calls[-1]['after'] if calls else None,
            'first_unavailable_call':next(({'body_index':i,**c} for i,c in enumerate(calls) if not complete(c)),None),
            'evidence':e['evidence'],'proved':e['proved'],'call':e.get('call'),'ran':e['ran'],
            'lich':[{k:r[k] for k in ('reason','result','full_lich','parity_received','parity_computed')} for r in lich],
            'routes':len(routes)})
    test(len(all_fec)==summary['fec_soft_calls']+summary['fec_hard_calls'],'FEC total')
    test(len(all_synth)==summary['synthesis_calls'] and len(slot_records)==summary['route_words'],'route/synthesis total')
    test(len(actual_occurrences)==len(set(actual_occurrences)),'duplicate source occurrence')
    header=next((f for f in frame_records if f['source']==0),None)
    v0=next((f for f in frame_records if f['source']==1),None)
    header_ok=bool(header and header['body_count']==header['complete_calls']==182 and header['result']==2 and clear(header['call']))
    prefix=scenario.startswith('active_prefix_')
    if prefix:
        expected=[(f['ordinal'],slot,sid) for f in truth for slot,sid in f['slots'].items()
                  if f['ordinal'] in source_frame_map and identify(source_frame_map[f['ordinal']],
                    list(range(8))+list(range(38+36*slot,74+36*slot)),truth)]
        v0_ok=bool(v0 and v0['body_count']==182 and v0['complete_calls']<182 and v0['confirmed']==1)
        if mode:v0_ok=bool(v0_ok and v0['lich'] and v0['lich'][0]['reason']=='accepted')
        retention=not missing and all(r['exact_complete_source_route'] for r in slot_records if r['source_owned'])
        parity=True
        trailer=None
    else:
        v0_ok=bool(v0 and v0['body_count']==v0['complete_calls']==8 and v0['evidence']==v0['proved']==0)
        if mode:v0_ok=bool(v0_ok and v0['lich']==[{'reason':'parity_reject','result':0,'full_lich':175,'parity_received':1,'parity_computed':0}])
        parity=bool(v0_ok and v0['routes']==0)
        expected=[(f['ordinal'],slot,sid) for f in truth[2:] for slot,sid in f['slots'].items()]
        retention=actual_occurrences==expected and all(r['exact_complete_source_route'] for r in slot_records)
        trailer=next((f for f in frame_records if f['source']==8),None)
        call=trailer['call'] if trailer else None
        parity=bool(parity and header_ok and call and tuple(call[k] for k in ('epoch','phase','end_reason','media_active','audio_permitted'))==(header['call']['epoch'],2,3,0,0))
        for f in frame_records:
            if f['source'] is not None and 2<=f['source']<=7:
                parity=bool(parity and clear(f['call']) and f['call']['epoch']==header['call']['epoch'])
    flags=Counter(r['result_after']['flags'] for r in all_synth if r['result_after'] is not None)
    return {'exposure_pass':header_ok and v0_ok,'finite_voice_safety_pass':not unsafe,
        'complete_slot_retention_pass':retention,'parity_and_later_call_pass':parity,
        'frames':frame_records,'slots':slot_records,'CRCs':crc_records,'missing_complete_slots':missing,
        'unsafe_synthesis':unsafe,'quality_observations':quality,'source_occurrences':actual_occurrences,
        'expected_complete_occurrences':expected,'missing_source_occurrences':[x for x in expected if x not in actual_occurrences],
        'sync_and_frame_chronology':[{k:r[k] for k in ('seq','kind','frame','value','last_sync','sync','confirmed','evidence','proved') if k in r}
            | {'sample':samples if r['eof'] else r.get('read_start',0)+r.get('cache_pos',0)}
            for r in rows if r['kind'] in ('search_begin','search_end','frame_begin','frame_end','reset_begin','reset_end')],
        'call_classes':dict(call_classes),'counts':{'frames':len(frames),'routes':len(slot_records),'FEC':len(all_fec),
        'soft_FEC':sum(r['mode']=='soft' for r in all_fec),'hard_FEC':sum(r['mode']=='hard' for r in all_fec),
        'nested_FEC':sum(not r['outer'] for r in all_fec),'synthesis':len(all_synth)},
        'synthesis_flag_histogram':dict(flags),'flag_counts':{name:sum(n for f,n in flags.items() if f&mask)
        for name,mask in [('ERASURE',32),('REPEAT',64),('MUTE',128)]},
        'fec_status_histogram':dict(Counter(r['status'] for r in all_fec)),
        'synthesis_status_histogram':dict(Counter(r['status'] for r in all_synth)),
        '_common':semantics(rows),'_chunk':semantics(rows,True),'trace_sha256':sha(trace)}


def main():
    report_raw=(STUDY/'report.json').read_bytes();report=parse(report_raw)
    need(len(report.get('attempts',[]))==16 and 'files' in report and 'preservation_pass' in report,'Await completed once-only study')
    before=parse((STUDY/'before-execution.json').read_bytes());manifest=parse((STUDY/'inputs/manifest.json').read_bytes())
    need(before['commit']=='2a5af570a71d03a7753c4d73ba11c0c379e2b165','Frozen harness commit')
    need(sha((STUDY/'inputs/manifest.json').read_bytes())=='899bc2f55403b4b5f465dfbf8939d3dc396e86d197feef86654d3a6529b7a0c6','Corpus pin')
    group_counts={}
    for group in ('frozen_files','original_files','copied_identities','configured_sources','protected'):
        group_counts[group]=len(before[group])
        for path,expected in before[group].items():check(Path(path).is_file() and sha(Path(path).read_bytes())==expected,'preservation:'+path)
    for name,expected in report['files'].items():check(sha((STUDY/name).read_bytes())==expected,'report file:'+name)
    check(sha((STUDY/'frozen/receiver/engine.exe').read_bytes())==before['binary_sha256']=='6682f833c9c9a9ec23b596af2c8fe3f176de28134a90f3f487e8ab996b464704','reused binary')
    check(before['receiver_rebuilt'] is False,'recorded no rebuild')
    wanted={(f'{name}-c{chunk}',mode) for name in NAMES for chunk in (37,512) for mode in (0,1)}
    check(len(report['attempts'])==16 and {(r['id'],r['observed']) for r in report['attempts']}==wanted,'16 distinct recorded attempts')
    check(all(r['exit_code']==0 for r in report['attempts']),'16 recorded zero exits')
    check(len(list((STUDY/'runs').glob('*/*/invocation.json')))==16,'No extra native invocation record')
    truth,words,channels=oracle();cases={}
    for name in NAMES:
        samples=manifest['waveforms'][name]['samples']
        for chunk in (37,512):
            cid=f'{name}-c{chunk}'
            for mode in (0,1):
                folder=STUDY/'runs'/cid/str(mode)
                invocation=parse((folder/'invocation.json').read_bytes())
                args=invocation['arguments']
                check(args[2:5]==['1',str(chunk),str(mode)] and Path(args[0]).resolve()==(STUDY/'frozen/receiver/engine.exe').resolve(),'Exact CLI:'+cid+'/'+str(mode))
                check(parse((folder/'process.json').read_bytes())=={'exit_code':0},'Process exit:'+cid+'/'+str(mode))
                rows=[parse(line) for line in (folder/'events.jsonl').read_bytes().splitlines()]
                cases[cid+'/'+str(mode)]=inspect(rows,(folder/'pops.u32le').read_bytes(),name,chunk,mode,samples,truth,words,channels)
    for name in NAMES:
        for chunk in (37,512):
            a,b=[cases[f'{name}-c{chunk}/{m}'] for m in (0,1)]
            check(a['_common']==b['_common'],'callback neutrality:'+name+str(chunk))
        for mode in (0,1):
            a,b=[cases[f'{name}-c{c}/{mode}'] for c in (37,512)]
            check(a['_chunk']==b['_chunk'] and a['trace_sha256']==b['trace_sha256'],'chunk neutrality:'+name+str(mode))
    independent={k:all(v[k] for v in cases.values()) for k in ('exposure_pass','finite_voice_safety_pass','complete_slot_retention_pass','parity_and_later_call_pass')}
    independent['progression_pass']=all(independent.values()) and not any(v['quality_observations'] for v in cases.values())
    check(report['measurement_pass'] is True and report['preservation_pass'] is True,'Recorded measurement/preservation')
    check(report['progression_pass']==independent['progression_pass'],'Independent aggregate quality agrees')
    totals=Counter();call_totals=Counter();flag_totals=Counter();unsafe_total=0
    for v in cases.values():
        totals.update(v['counts']);call_totals.update(v['call_classes']);flag_totals.update(v['flag_counts']);unsafe_total+=len(v['unsafe_synthesis'])
        del v['_common'];del v['_chunk']
    result={'schema':1,'audit_pass':not failures,'native_execution':False,'checks':checks,'failures':failures,
        'report_sha256':sha(report_raw),'auditor_sha256':sha(Path(__file__).read_bytes()),'native_invocations':16,
        'preserved_group_counts':group_counts,'report_file_hashes_verified':len(report['files']),
        'independent_gates':independent,'totals':dict(totals),'body_call_classes':dict(call_totals),
        'synthesis_flag_counts':dict(flag_totals),'unavailable_slot_synthesis_routes':unsafe_total,'cases':cases,
        'auditor_development_corrections':['Initial auditor used an absent check_bits field for the inherited CRC6/12 event. The first run stopped with KeyError before producing a conclusion. The unchanged recorder supplies received as an integer; the audit now independently recomputes CRC from information bits, validates received range and compares both against known source truth. No experiment source, evidence or gate was changed.'],
        'scope':'Direct independent raw/source inspection without importing frozen analyzer/generator/encoder or invoking native code. Quality failure is an observation, not an auditor-integrity failure.'}
    OUT.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    lines=['# Independent active-boundaries v1 raw-result audit','',
        ('PASS' if result['audit_pass'] else 'FAIL')+f': {checks} audit checks; {len(failures)} discrepancies. No native execution or experiment-source imports.',
        '',f'Report SHA-256: `{result["report_sha256"]}`. All 16 distinct attempts and preservation groups were examined.',
        '',f'Independent quality gates: `{json.dumps(independent,sort_keys=True)}`. These gates remain separate from audit integrity.',
        '', '| Scenario (per invocation) | Frames | FEC / synthesis | Complete / partial / empty calls | Unsafe synthesis slots |',
        '|---|---:|---:|---|---|']
    for name in NAMES:
        v=cases[name+'-c37/1'];ct=v['counts'];cl=v['call_classes']
        lines.append(f'| {name} | {ct["frames"]} | {ct["FEC"]} / {ct["synthesis"]} | {cl.get("complete",0)} / {cl.get("crossing_partial",0)} / {cl.get("crossing_empty",0)+cl.get("already_eof",0)} | '+', '.join(str(x['slot']) for x in v['unsafe_synthesis'])+' |')
    lines.extend(['',f'Totals: `{json.dumps(dict(totals),sort_keys=True)}`. Actual masks 32/64/128 yield `{json.dumps(dict(flag_totals),sort_keys=True)}`.',
        '', 'Slot identities come from the real per-dibit completed sample intervals and canonical frame/slot coordinates before known 49-bit comparison. Incomplete slots remain unavailable even if FEC returns zero or a plausible word. Every detailed pop trace is checked against the finite sample range, including partial EOF consumption. Callback/chunk comparisons exclude optional telemetry/declared provider bookkeeping and random PCM, not common source/FEC/call outcomes.',
        '', 'Source explanation: `upstream/dsd-neo/src/dsp/dsd_symbol.c:2035–2045,2143–2183` returns numeric zero on unfinished symbols without committing symbolcnt; `src/core/frames/dsd_dibit.c:1012–1056` still slices that number. `src/protocol/nxdn/nxdn_frame.c:633–661` reads the remaining body without completion status and gates voice on sticky confirmation (`554–568`). `src/protocol/nxdn/nxdn_voice.c:56–90` forwards every selected slot to FEC/synthesis and audio handling. Later EOF does not erase an earlier complete slot, but absent later slots also do not become supplied data. This source-backed mechanism is distinct from any RF or audible-speech claim.',
        '', 'No CRC rule, source oracle, input, recorder binary, frozen checker gate or historical failure was edited. A later receiver fix requires separate registration and binary. Detailed per-slot statuses, bits, flags, source ownership, call transitions and CRC observations are retained in the JSON.'])
    lines.extend(['','## Concrete failed boundaries and clean-word loss','',
        'All three prefixes actually acquire the strong header and V0. At 6159, slot0 has 35 completed dibits plus a 19-sample unfinished dibit; its FEC and synthesis both return status0/flags3, yet source bit48 changes from1 to0. This is not a valid received word. At6160 slot0 completes and the next call is empty; at6161 slot0 completes and the next call consumes one sample without completing. Both retain the exact source word0. All three still make four synthesis calls; slots1–3 have zero complete dibits and statuses3/4/3, with flags3. Across the12 prefix invocations this produces40 unavailable-slot synthesis calls. There is no ERASURE/REPEAT/MUTE flag on these40 calls, showing that those flags are not finite-input availability evidence.',
        '', 'The bad-parity source is actually rejected at sample4840 after exactly8 body dibits, full LICH0xaf and parity1 versus0, with no current evidence/proof or target voice route. Sticky confirmation and the known call survive; return1 is expected. The later known epoch terminates correctly at the actual trailer. The other20 expected transmitted occurrences are not all retained: only12 return, and all eight words in source ordinals2/3 (V1/V2, words4–11) are absent.',
        '', 'The raw chronology explains the loss without inventing a receiver branch trace: parity rejection clears last_sync/sync at4840; the next search spans4840→11200 rather than dispatching V1 at its nominal body start8520. It returns an off-source hit at11200; that frame consumes182 dibits through14840, accepts full LICH0x5e (nonvoice profile0x2f), produces no current proof and no voice. The V2 sync/body start12360 falls inside that wrong frame consumption. The next search returns at16200, exactly V3 body start, and the remaining V3/V4/FACCH/trailer frames route normally. No intervening noCarrier/reset is recorded; the only reset is the initial one. Thus these are acquisition/attribution gaps, not wrong known-word FEC returns.',
        '', 'Source support for that interpretation: nxdn_frame.c:166–168,222–227,600–604 clears sync on parity rejection without clearing confirmation; dsd_frame_sync.c:1726–1746 enables the first-canonical shortcut only while unconfirmed, otherwise requiring a matching previous sync polarity. The known confirmed call is therefore outside that shortcut after this reject. An internal silent priming match is plausible, but the frozen recorder does not emit every attempted sync match, so the precise intervening match sequence is not directly proved. The observed wrong-frame span and missed source frames are proved. No source-level hypothesis is promoted to a measured RF mechanism.',
        '', 'Four ERASURE flags occur only on the real retained source word19 in the four bad-parity invocations; none is REPEAT or MUTE. Internal synthesis calls are not speaker output, accepted speech, Android behavior or RF safety. The unavailable-input failure and the separate clean-retention failure remain failures.'])
    if failures:lines.extend(['','Discrepancies:']+['- '+x for x in failures])
    OUT.with_suffix('.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('audit_pass','checks','failures','independent_gates','totals','unavailable_slot_synthesis_routes')},indent=2))


if __name__=='__main__':main()
