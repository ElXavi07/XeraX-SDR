"""Post-execution description only; does not change frozen decisions."""
import collections
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
study = root / 'build/nxdn-active-boundaries-v1-run-20260925'
report_raw = (study / 'report.json').read_bytes()
report = json.loads(report_raw)
if len(report.get('attempts', [])) != 16 or 'files' not in report:
    raise ValueError('Native matrix is incomplete')
rows = []
for attempt in report['attempts']:
    audit = json.loads((study / 'runs' / attempt['id'] / str(attempt['observed']) / 'audit.json').read_bytes())['audit']
    frames = audit['frames']
    rows.append({
        'id': attempt['id'], 'detail': attempt['observed'],
        'gates': {k: audit.get(k) for k in ('measurement_pass', 'routing_pass', 'exposure_pass', 'retention_pass', 'negative_pass', 'finite_voice_safety_pass')},
        'summary': audit['summary'],
        'source_occurrences': audit['source_occurrences'],
        'expected': audit['expected_complete_occurrences'],
        'unsafe_synthesis': audit['unsafe_synthesis'],
        'flags': audit['synthesis_flags'],
        'issues': {k: audit[k] for k in ('routing_issues', 'exposure_issues', 'retention_issues', 'negative_issues')},
        'frames': [{'source': f['source'], 'lich_source': f['lich_source'],
                    'classes': dict(collections.Counter(f['classes'])), 'begin': f['begin'], 'end': f['end'],
                    'lich': f['lich'], 'route_count': len(f['routes'])} for f in frames]
    })
out = {'report_sha256': hashlib.sha256(report_raw).hexdigest(),
       'comparison': report['comparison'], 'preservation_pass': report['preservation_pass'],
       'groups': {k: len(v) for k, v in json.loads((study / 'before-execution.json').read_bytes()).items() if isinstance(v, dict)},
       'report_files': len(report['files']), 'invocations': rows}
(root / 'build/nxdn-active-boundaries-v1-summary.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: out[k] for k in ('report_sha256', 'preservation_pass', 'groups', 'report_files')}))
print(json.dumps({k: v for k, v in report['comparison'].items() if k.endswith('_pass')}))
for row in rows:
    if row['detail'] == 1 and row['id'].endswith('c37'):
        print(json.dumps({'id': row['id'], 'gates': row['gates'], 'frames': len(row['frames']),
              'fec': row['summary']['fec_soft_calls'], 'synth': row['summary']['synthesis_calls'],
              'source_exact': sum(o['exact'] for o in row['source_occurrences']), 'unsafe': row['unsafe_synthesis'],
              'flags': row['flags'], 'issues': row['issues'], 'expected': row['expected']}))
