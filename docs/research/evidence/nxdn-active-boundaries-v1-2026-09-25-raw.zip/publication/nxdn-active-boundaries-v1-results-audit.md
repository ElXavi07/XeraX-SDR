# Independent active-boundaries v1 raw-result audit

PASS: 42075 audit checks; 0 discrepancies. No native execution or experiment-source imports.

Report SHA-256: `058cf74cb23a390d0815e20ae0a2faeb8cf8e2c4e2c4fee98beb04ac290864db`. All 16 distinct attempts and preservation groups were examined.

Independent quality gates: `{"complete_slot_retention_pass": false, "exposure_pass": true, "finite_voice_safety_pass": false, "parity_and_later_call_pass": true, "progression_pass": false}`. These gates remain separate from audit integrity.

| Scenario (per invocation) | Frames | FEC / synthesis | Complete / partial / empty calls | Unsafe synthesis slots |
|---|---:|---:|---|---|
| active_prefix_6159 | 2 | 4 / 4 | 255 / 1 / 108 | 0, 1, 2, 3 |
| active_prefix_6160 | 2 | 4 / 4 | 256 / 0 / 108 | 1, 2, 3 |
| active_prefix_6161 | 2 | 4 / 4 | 256 / 1 / 107 | 1, 2, 3 |
| active_bad_lich | 8 | 12 / 12 | 1282 / 0 / 0 |  |

Totals: `{"FEC": 96, "frames": 56, "hard_FEC": 0, "nested_FEC": 0, "routes": 96, "soft_FEC": 96, "synthesis": 96}`. Actual masks 32/64/128 yield `{"ERASURE": 4, "MUTE": 0, "REPEAT": 0}`.

Slot identities come from the real per-dibit completed sample intervals and canonical frame/slot coordinates before known 49-bit comparison. Incomplete slots remain unavailable even if FEC returns zero or a plausible word. Every detailed pop trace is checked against the finite sample range, including partial EOF consumption. Callback/chunk comparisons exclude optional telemetry/declared provider bookkeeping and random PCM, not common source/FEC/call outcomes.

Source explanation: `upstream/dsd-neo/src/dsp/dsd_symbol.c:2035–2045,2143–2183` returns numeric zero on unfinished symbols without committing symbolcnt; `src/core/frames/dsd_dibit.c:1012–1056` still slices that number. `src/protocol/nxdn/nxdn_frame.c:633–661` reads the remaining body without completion status and gates voice on sticky confirmation (`554–568`). `src/protocol/nxdn/nxdn_voice.c:56–90` forwards every selected slot to FEC/synthesis and audio handling. Later EOF does not erase an earlier complete slot, but absent later slots also do not become supplied data. This source-backed mechanism is distinct from any RF or audible-speech claim.

No CRC rule, source oracle, input, recorder binary, frozen checker gate or historical failure was edited. A later receiver fix requires separate registration and binary. Detailed per-slot statuses, bits, flags, source ownership, call transitions and CRC observations are retained in the JSON.

## Concrete failed boundaries and clean-word loss

All three prefixes actually acquire the strong header and V0. At 6159, slot0 has 35 completed dibits plus a 19-sample unfinished dibit; its FEC and synthesis both return status0/flags3, yet source bit48 changes from1 to0. This is not a valid received word. At6160 slot0 completes and the next call is empty; at6161 slot0 completes and the next call consumes one sample without completing. Both retain the exact source word0. All three still make four synthesis calls; slots1–3 have zero complete dibits and statuses3/4/3, with flags3. Across the12 prefix invocations this produces40 unavailable-slot synthesis calls. There is no ERASURE/REPEAT/MUTE flag on these40 calls, showing that those flags are not finite-input availability evidence.

The bad-parity source is actually rejected at sample4840 after exactly8 body dibits, full LICH0xaf and parity1 versus0, with no current evidence/proof or target voice route. Sticky confirmation and the known call survive; return1 is expected. The later known epoch terminates correctly at the actual trailer. The other20 expected transmitted occurrences are not all retained: only12 return, and all eight words in source ordinals2/3 (V1/V2, words4–11) are absent.

The raw chronology explains the loss without inventing a receiver branch trace: parity rejection clears last_sync/sync at4840; the next search spans4840→11200 rather than dispatching V1 at its nominal body start8520. It returns an off-source hit at11200; that frame consumes182 dibits through14840, accepts full LICH0x5e (nonvoice profile0x2f), produces no current proof and no voice. The V2 sync/body start12360 falls inside that wrong frame consumption. The next search returns at16200, exactly V3 body start, and the remaining V3/V4/FACCH/trailer frames route normally. No intervening noCarrier/reset is recorded; the only reset is the initial one. Thus these are acquisition/attribution gaps, not wrong known-word FEC returns.

Source support for that interpretation: nxdn_frame.c:166–168,222–227,600–604 clears sync on parity rejection without clearing confirmation; dsd_frame_sync.c:1726–1746 enables the first-canonical shortcut only while unconfirmed, otherwise requiring a matching previous sync polarity. The known confirmed call is therefore outside that shortcut after this reject. An internal silent priming match is plausible, but the frozen recorder does not emit every attempted sync match, so the precise intervening match sequence is not directly proved. The observed wrong-frame span and missed source frames are proved. No source-level hypothesis is promoted to a measured RF mechanism.

Four ERASURE flags occur only on the real retained source word19 in the four bad-parity invocations; none is REPEAT or MUTE. Internal synthesis calls are not speaker output, accepted speech, Android behavior or RF safety. The unavailable-input failure and the separate clean-retention failure remain failures.
