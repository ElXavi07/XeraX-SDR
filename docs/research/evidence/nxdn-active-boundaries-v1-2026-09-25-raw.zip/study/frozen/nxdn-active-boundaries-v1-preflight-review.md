# Active boundaries v1 independent pre-execution review

2026-09-25. Registration: `b3a8cee4608db93ba3bc446281ed1ded954a6270`.

Generator and runner read-only review is complete: **no concrete blocker identified in the reviewed code**. No corpus generation, receiver invocation, native build or historical-file edit was performed by this reviewer. At the initial review, the deliberate `INPUT_SHA = 'PENDING_INPUT_MANIFEST'` prevented execution. Root's subsequent sole generation and manifest-pin-only change are verified in the final addendum below. This review does not waive the pending independent checker/corpus, full-test and committed-harness gates.

## Input recipe and fixed matrix

`prepare.py` pins the prior report, input manifest, binary, publication index/archive and cold waveform before creating output. It verifies all parent report-listed file hashes, refuses an existing output corpus, and preserves historical references/anchors by copying them. It invokes no old generator or native program.

The three prefix payloads are literal first `4*cut` bytes of the pinned already-shaped cold waveform, for cuts 6159, 6160 and 6161. No endpoint is reshaped. The bad-parity payload begins with the nine known cold vectors, flips only `vectors[1][17] ^= 2`, and requires equality with the already verified `r1_bad_lich.dibits`. This is full-frame bit 34, leaving spacer bit 35 unchanged. Full-wave shaping uses 640 samples of alternating +24000/-24000 preamble, the four registered levels at 20 samples/dibit, a 1280-sample +8000 tail and the centered eight-sample mean with full-wave clamped endpoints. Its declared total is 36480 samples.

Each output receives identity `uint32` sample lineage and zero occurrence indices. Each retains a deep copy of all nine parent frame/slot oracles, including unsupplied future entries. Only bad-parity frame 1's vector identity/hash changes; bit/control truth remains in the frozen copied parent metadata. The checker must establish actual finite ownership before crediting any future oracle entry.

The generated manifest is exactly four waveform names, two chunks per waveform and `fast:1` in all eight base cases. Detailed mode is a runner dimension; the registration requires both modes for exactly 16 fresh processes. The four old cold-fast run directories are copied as read-only anchors and are not runnable new cases.

## Preservation handoff to runner

The generator rehashes parent inputs, report, publication and copied anchor sources after preparation. The runner supplies the wider historical check: it unions all five prior preservation groups, every parent report-listed hash, the fixed publication index/archive and the parent report into protected identities. Conflicting historical hashes are rejected. It rechecks the frozen build-audit dependencies and runtime closure, while the prior report binds the previous build audit and before-execution records themselves.

The new manifest intentionally has no top-level vector table: copied prior inputs/metadata reside under `parent/`, and `original_file` is `parent/cold.f32le`. Its new scenario/edit names require independently validated adapter handling, not silently relaxed historical integrity checks. This schema was communicated to the independent checker owner.

## Runner and failure retention

`run.py` creates a fresh output directory and refuses a reused directory. It requires the precise pinned input manifest, eight base cases/four waveforms, fast=1 in every case, a committed/unmodified new harness, and no product-source difference from the publication baseline. Strict case/chunk/waveform identity validation is delegated to `analyze.validate_inputs`; this review covers the runner's use of that validated result, not a substitute audit of the independently owned checker.

The whole old frozen recorder directory, including adjacent DLLs and retained build/link evidence, is copied into `frozen/receiver`. Inputs are copied into the new run. The source skeleton preserves the new checker and all required historical helpers in their repository hierarchy. Source/copy hashes and named completed preflight records enter `before-execution.json`; no broad glob can accidentally freeze a later live result audit or execution log. The prior configured-source inventory is explicitly labeled inherited: this experiment performs no compilation.

Every launch uses `frozen/receiver/engine.exe`, the waveform under the new copied `inputs`, case fast=1, case chunk 37/512, mode 0/1, and that identity's `pops.u32le`. There is one nested traversal of eight new cases and two detail modes, with no retry path and no loop over archived anchors. It strips DSD environment overrides, preserves the exact argument array and timeout, and launches from each fresh identity directory.

`checked_invoke` validates originals, frozen snapshots, copies, configured sources, protected history and imported Python source identities before each invocation. A drift exception stops further launches and the outer handler retains a failed report/traceback. During an attempted process, stdout/stderr files are opened before execution; timeout or launch/checker/JSON failure records its exception and partial output. A normal exit is saved in `process.json` before parsing/checking. Nonzero exit cannot pass measurement. Missing trace, malformed/duplicate/nonfinite JSON or checker failure is retained in `audit.json` and `failure.txt`; the loop continues the next distinct registered identity. `TimeoutExpired` records no invented exit code. No failed receiver result is converted into a successful observation.

Only measured audits enter the comparison grid; missing identities therefore cannot silently pass a complete-grid checker. The report is saved after each attempt. Final measurement requires all 16 attempted identities, no measurement failure, preserved hashes and the checker measurement gate. Progression separately depends on its quality gate; product promotion remains false. The final file inventory excludes `report.json` itself and Python cache files, avoiding the previous self-hash pitfall. An outer failure preserves the partial report and raw folders instead of retrying them.

## Remaining scheduled gates and scope

The registration precedes generation. Corpus generation, actual frozen input validation, the independent checker/counterexample tests, the exact `INPUT_SHA` substitution and the final committed source freeze remain root/checker-owner work. Python AST parsing of the reviewed generator and runner succeeds; this review did not import either module, run their tests, generate even a test corpus, or launch a receiver. After the manifest-pin-only edit, any other substantive runner/generator change requires review before execution.

Reviewed recipe and runner hashes are recorded below. The runner hash intentionally describes its pre-manifest-pin version, not the future frozen execution source.

| Reviewed file | SHA-256 |
|---|---|
| `experiments/nxdn_active_boundaries_v1/prepare.py` | `5f035dd1f8488f4fcfb68fdfd8424969ee472d32c848cafd3a837ccc67612d0f` |
| `experiments/nxdn_active_boundaries_v1/run.py` before manifest pin | `d77eb99c86c39c0348d58313b9178a92eff84d7e27369dfb346bc2bb8c6f3b1b` |

## Final addendum before run snapshot

Root reported exactly one corpus generation and no native receiver invocation. Read-only hashing confirms `build/nxdn-active-boundaries-v1-inputs-20260925/manifest.json` has SHA-256 `899bc2f55403b4b5f465dfbf8939d3dc396e86d197feef86654d3a6529b7a0c6`, matching the concrete `INPUT_SHA` now in `run.py`.

The final reviewed runner SHA-256 is **`6e124966bfb7355c6b8fc6525dc40ee8dee826fb48ef0ad348bfdb56a5cf819b`**. Replacing that one exact assignment in memory with its former placeholder reproduces the initial reviewed runner hash `d77eb99c86c39c0348d58313b9178a92eff84d7e27369dfb346bc2bb8c6f3b1b` byte for byte. No other runner change occurred. `prepare.py` remains `5f035dd1f8488f4fcfb68fdfd8424969ee472d32c848cafd3a837ccc67612d0f`.

This addendum reads the actual manifest identity only; it does not regenerate inputs or substitute for independent validation of their contents. Root reports three analytic shape tests passed before generation. Independent checker/actual-corpus validation, the full test suite and the final committed harness remain separate prerequisites. No native call, regeneration or candidate change was made for this addendum. The review is now final for snapshotting these reviewed identities.
