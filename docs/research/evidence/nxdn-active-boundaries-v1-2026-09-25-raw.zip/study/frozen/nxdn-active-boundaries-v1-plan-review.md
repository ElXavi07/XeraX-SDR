# Independent pre-execution review: acquisition-conditioned NXDN48 boundaries

Reviewed 2026-09-25 at publication HEAD `acb52828842050986ab95e4ab25b270d227561e1`. This is a read-only source/design review of the draft `docs/research/NXDN-ACTIVE-BOUNDARIES-V1-PREREGISTRATION-2026-09-25.md`. No corpus was generated and no encoder, receiver, build, or old matrix was executed for this review. The previous clear-routing study and its failed gates remain unchanged.

## Disposition

No registration blocker found. The four fixed waveforms and 16 once-only identities are a bounded, falsifiable way to expose the previously unexercised voice boundary. The requirements below are important for the new checker. The other-20-word recovery requirement is valid as a newly registered quality gate; its success is not implied by the previous cold-fast anchor.

The public fast option is deliberately selected using the published prior observation. That is an acquisition-conditioned follow-up, not an unbiased repeat of the previous experiment or a new receiver implementation. Each invocation must start fresh; do not inject the archived call state. Reuse the exact audited executable `6682f833c9c9a9ec23b596af2c8fe3f176de28134a90f3f487e8ab996b464704` and its verified runtime closure, with no rebuild.

## Exact input and source geometry

Use exactly `active_prefix_6159`, `active_prefix_6160`, `active_prefix_6161`, and `active_bad_lich`, public fast=1, chunks 37/512, detail 0/1. The three prefixes must be literal byte prefixes of the frozen, already shaped cold parent. Do not reshape their final samples or add a tail. Only the bad-LICH waveform is reconstructed with the registered full-wave eight-tap shaping, after changing V0 bit 34. Bit 35 and every other frame bit remain identical.

At the archived phase-zero cold acquisition, the source geometry is:

| Interval | Delivered sample coordinates, exclusive end |
|---|---|
| Preamble | `[0,640)` |
| Header full frame | `[640,4480)` |
| Header body after sync | `[840,4480)` |
| V0 full frame | `[4480,8320)` |
| V0 sync | `[4480,4680)` |
| V0 LICH, body indices 0..7 | `[4680,4840)` |
| V0 SACCH, body indices 8..37 | `[4840,5440)` |
| V0 slot 0, body indices 38..73 | `[5440,6160)` |
| V0 slot 1, indices 74..109 | `[6160,6880)` |
| V0 slot 2, indices 110..145 | `[6880,7600)` |
| V0 slot 3, indices 146..181 | `[7600,8320)` |

Thus, at that actual phase, cut 6159 leaves the last slot-0 dibit short by one sample; cut 6160 completes slot 0 and leaves slot 1 empty; cut 6161 completes slot 0 and supplies only one sample of slot 1. These are preregistered expectations, not authority to fabricate body positions. Preserve the real body-call intervals, symbol commits and strict source-phase bound. If phase/acquisition changes, retain that result and fail the relevant exposure/retention gate; do not move the cuts after observing it.

Each prefix keeps the entire immutable parent oracle, but future oracle entries never create supplied samples. The waveform is already filtered synthetic discriminator input. This is not a claim about complex-IQ filter delay, RF reception, or causal live-filter implementation.

## Source-backed exposure and ownership requirements

1. Require one actual source-owned complete header: positive NXDN sync, canonical source mapping, correct LICH, source-correct final SACCH/FACCH results, strong current proof, and actual known clear call source 901 / group 1201. CRC observations precede confirmation updates; check the actual later frame/call state rather than demanding confirmation inside the pre-note CRC callback.
2. Require actual source-owned V0 LICH. Prefixes need the normal accepted V0 profile and a genuinely partial or empty body interval before the body ends. Zero voice calls without those conditions fail exposure. The bad-LICH case needs the actual parity rejection at V0, not an unrelated rejection elsewhere.
3. Evaluate each routed word from its own 36 body calls, with complete committed source intervals and exact source/frame/slot identity determined before inspecting decoded bits. A successful decoder status, plausible returned dibits, or nonzero PCM cannot replace missing samples.
4. A complete slot 0 at cut 6160 or 6161 remains eligible even when later body reads reach EOF. `nxdn_frame` reads all 182 body dibits before calling `nxdn_voice`, so the synthesis-time cursor and EOF flag cannot decide whether an earlier slot was supplied. An all-frame abort that discards a complete slot 0 must fail retention, separately from unsafe synthesis.
5. Conversely, a truncated slot must not be credited merely because the finite adapter's later `getDibitSoft` returns a dibit value. `getSymbol` returns zero when live sampling fails, before `symbol_commit_symbol` increments `symbolcnt`; the frozen body-call observer preserves this distinction. The real handler currently has no per-slot availability check before voice processing. Any resulting synthesis over unavailable slots is a legitimate quality failure, not a reason to change the recorder.

The frozen `inspect_evidence` function can supply common structure, finite ownership, source-word routing and detailed matrix checks without invoking the old fixed 18-case grid. New exposure/retention/negative rules and the new eight base-case grid must be explicit. Do not relabel a new scenario as an old one merely to activate an old gate.

## Rejected-LICH return and later recovery

V0 full LICH changes `0xae` to `0xaf` (full-frame byte 4 XOR `0x20`); its seven-bit profile remains `0x57`. The real parity-reject path reads only the eight LICH dibits, marks `lastsynctype` as NONE, and exits before SACCH/FACCH/voice processing.

Important: **do not require rejected V0's frame return to be zero or its sticky confirmation to be cleared**. `nxdn_confirm_begin_frame` clears current evidence; `nxdn_confirm_end_frame` with no evidence clears only the weak streak. Confirmation established by the header can survive. `nxdn_frame` consequently returns 1 for a previously confirmed but currently unproved frame. Require no current evidence/proof (in particular no return 2), actual parity rejection, and no V0 voice/FEC/synthesis. Record all real state and incidental subsequent dispatches.

The newly registered clean-retention requirement is 20 other transmitted occurrences: four pure-voice quartets V1..V4 plus two words in each half-steal frame. Count source occurrences, not distinct word values; F1/F2 repeat prior source words. Require exact FEC/synthesis inputs, no duplicate/stolen occurrence, the same known clear epoch, and the actual terminating trailer. Loss after the rejected frame is an honest failed recovery gate.

Header SACCH runs before strong FACCH, so live RAN can remain -1 at the header and become 1 on the next eligible valid SACCH. A parity-rejected V0 has no eligible SACCH. Do not demand RAN 1 there. Prefix EOF is not a transmitted trailer and should not be required to terminate the call identically to TX_REL.

## New pre-execution negative controls and preservation

The new checker should reject fabricated exposure, stale/repeated source identity, a missing complete early slot, a synthesis assigned to a partial/empty slot, wrong FEC/synthesis bits, rejected-V0 voice, loss of a later clean occurrence, duplicate/missing identities, and detail/chunk drift. Include a positive control where slot 0 is complete but later EOF is already true at synthesis. Separately test sticky confirmation plus rejected-LICH return 1 as permissible current-no-proof behavior.

Use the pinned actual mbelib masks ERASURE=`0x20` (32), REPEAT=`0x40` (64), MUTE=`0x80` (128). New controls should exercise them individually and combined; preserve the old incorrect 4/8/16 tests and their disclosed limitation. Flags and exact synthesis input are observations, not accepted/intelligible speech metrics.

Freeze registration, new input recipe, checker and runner before any new receiver execution. Recheck the old source/build/runtime identity, archived cold-fast input and four raw anchors, and prior preservation groups. The archived anchors are read-only references, not newly invoked identities. Retain all raw outputs, exits and partial failures for each of the 16 fixed invocations; no retries or source changes after receiver observations. Drift should prevent further launches. Distinguish measurement failure from faithfully measured exposure, routing, parity or finite-safety failure. No outcome in this study alone promotes a product change.

## Primary implementation inspected

- `upstream/dsd-neo/src/protocol/nxdn/nxdn_frame.c`: LICH collection/parity rejection (166-229), complete body collection and dispatch/end-frame return (608-680), confirmed voice gate (554 onward).
- `upstream/dsd-neo/src/protocol/nxdn/nxdn_confirm.c`: strong/weak evidence, sticky confirmation, current-frame proof.
- `upstream/dsd-neo/src/protocol/nxdn/nxdn_voice.c`: actual 36-dibit slot indexing and hard/soft vocoder dispatch.
- `upstream/dsd-neo/src/dsp/dsd_symbol.c`: failed sample path versus `symbol_commit_symbol` (2142 onward).
- `experiments/nxdn_observation_v2/observer_extra.inc`: frozen actual sample-frontier and body-call telemetry.
- `experiments/nxdn_clear_routing_v1/analyze.py`: frozen `inspect_evidence`, actual source ownership and synthesis input checks.
- Installed pinned `mbelib-neo/mbelib.h`, SHA-256 `800093e90ee74abb9564dc66f63a5c3334689deeb947f5a0b2aa80384c49612c`: named processing flags.
- Published `docs/research/NXDN-CLEAR-ROUTING-V1-2026-09-25.md`: previous failed primary gates and descriptive cold-fast anchor.

No external protocol generalization or playback/PCM quality inference is needed for this bounded review.
