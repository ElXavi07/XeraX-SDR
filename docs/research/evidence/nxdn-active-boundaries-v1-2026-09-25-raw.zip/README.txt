XeraX NXDN active-boundary evidence, 25 September 2026
Registration b3a8cee; frozen harness 2a5af570a71d03a7753c4d73ba11c0c379e2b165.
Exactly 16 new Windows receiver processes, all exit zero. No rebuild.
Measurement, exposure and parity restriction PASS; finite voice safety and
subsequent clean retention FAIL. No app or product promotion.
There are 96 real synthesis calls, 40 with unavailable slot input; 56
completely source-owned occurrences preserve exact known FEC/synthesis bits.
The exposed bad-LICH sequence retains only 12 of 20 subsequent clean words.
Complete early slots survive later EOF, which a future fix must preserve.

study/ contains every attempt, raw events and actual sample-pop traces, inputs,
pre-execution identities, reviews, frozen observer/checker sources, the unchanged
research executable and runtime DLLs. No historical receiver case was rerun.
The four input anchors are copied previous observations, not new invocations.
The receiver source baseline is
https://github.com/ElXavi07/XeraX-SDR/tree/289a82f8fd9c0495b64bf948fd45413bc63261c4
The included executable is not a phone APK or Windows application installer.
publication/ includes separate post-execution audits, CI and a next-candidate
design proposal; these do not constitute pre-execution evidence or a fix.

Offline review without native execution: import analyze from
study/frozen/source_repository/experiments/nxdn_active_boundaries_v1; retain
that hierarchy and sibling frozen helpers. Call validate_inputs(study/inputs),
inspect(rows,trace_path,case,manifest,inputs,detail) for each of the 16 saved
events.jsonl/pops.u32le pairs, then compare the complete grid. The result must
reproduce measurement=true and progression=false, with failed safety/retention.
Absolute identities refer to the original machine and are not rewritten.
No speech, playback, complex-I/Q, RF, privacy, GPU or performance claim.
