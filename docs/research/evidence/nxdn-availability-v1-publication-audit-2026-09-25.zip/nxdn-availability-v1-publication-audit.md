# External availability publication audit

PASS: 7389 checks; 0 discrepancies. This is a post-execution external audit, not pre-execution evidence and not part of its own archive.

No native receiver, encoder, build, new input generation or historical matrix execution occurred. The ZIP was extracted only to a new scratch directory; frozen studies and sources were not edited.

Verified the complete ZIP inventory and payload hashes, native report, original preservation groups, registered source Git blobs, isolated candidate executable, independent audit and CI identities. All 20 raw attempts were reanalyzed with the extracted frozen Python checker; each saved audit and final comparison were compared as exact canonical JSON.

Publication prose retains the separate later-retention failure and blocked product promotion. It distinguishes complete early-slot retention from unavailable later slots suppressed by the private candidate, and does not claim speech, playback, RF quality or a released app fix.

Reproduced gates: `{"availability_guard_pass": true, "exposure_pass": true, "finite_voice_safety_pass": true, "measurement_pass": true, "negative_pass": true, "progression_pass": false, "retention_pass": false, "routing_pass": true, "targeted_guard_pass": true}`.

Details and hashes are in the adjacent machine-readable audit.
