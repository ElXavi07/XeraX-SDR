"""External publication verification; Python-only, never invokes a receiver."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tarfile
import tempfile
import zipfile
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
STEM="nxdn-availability-v1-2026-09-25"
ARCHIVE=ROOT/"docs/research/evidence"/(STEM+"-raw.zip")
INDEX=ROOT/"docs/research/evidence"/(STEM+".json")
STUDY=ROOT/"build/nxdn-availability-v1-run-20260925"
OUTPUT=Path(__file__).with_suffix(".json")
NOTE=Path(__file__).with_suffix(".md")
HARNESS="0551423572dc056b6e8d6f10f114e7a77bece193"
REPORT="dc6e7ad0f363db329108d29b02c990fbbdd774bd5e26b339f31b8d85c7c8a14c"
BINARY="788c655cf616ea53804f8bd70d174e42b7038a173f8a0aaf514fc2ccb47f599d"
sha=lambda raw:hashlib.sha256(raw).hexdigest()
result={"schema":1,"kind":"nxdn_availability_v1_external_publication_audit","audit_pass":False,
        "native_execution":False,"input_generation":False,"checks":0,"failures":[],"case_replays":[]}

def check(ok,message):
    result["checks"]+=1
    if not ok:
        result["failures"].append(message)
        raise ValueError(message)

def parse(raw):
    def pairs(items):
        out={}
        for key,value in items:
            if key in out: raise ValueError("Duplicate JSON key: "+key)
            out[key]=value
        return out
    def nonfinite(value): raise ValueError("Nonfinite JSON: "+value)
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=nonfinite)

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode("utf-8")

def safe_name(name):
    p=PurePosixPath(name)
    return bool(name) and not p.is_absolute() and ".." not in p.parts and "\\" not in name and ":" not in name

def main():
    check(ARCHIVE.is_file() and INDEX.is_file(),"Publication is not complete")
    raw_archive=ARCHIVE.read_bytes(); index=parse(INDEX.read_bytes())
    check(index["archive"]["file"]==ARCHIVE.name,"Wrong published archive filename")
    check(index["archive"]["bytes"]==len(raw_archive) and index["archive"]["sha256"]==sha(raw_archive),"Published archive identity differs")
    check(index["harness_commit"]==HARNESS and index["report_sha256"]==REPORT,"Published source/report identity differs")
    check(index["measurement_pass"] is True and index["preservation_pass"] is True and index["progression_pass"] is False
          and index["targeted_guard_pass"] is True and index["product_promotion"] is False,
          "Published split gates were altered")
    check(index["comparison"]["finite_voice_safety_pass"] is True and index["comparison"]["retention_pass"] is False,
          "Separate guard success and later-retention failure were altered")
    result["archive"]={"sha256":sha(raw_archive),"bytes":len(raw_archive)}
    with zipfile.ZipFile(io.BytesIO(raw_archive)) as archive:
        names=archive.namelist()
        check(len(names)==len(set(names)) and all(safe_name(name) for name in names),"Duplicate/unsafe archive path")
        check(archive.testzip() is None,"ZIP CRC failure")
        check(len(names)==index["archive"]["entries"],"Published entry count differs")
        inventory=parse(archive.read("archive-manifest.json"))
        check(set(names)==set(inventory["files"])|{"archive-manifest.json"},"Inventory does not cover every payload")
        for name,meta in inventory["files"].items():
            raw=archive.read(name)
            check(len(raw)==meta["bytes"] and sha(raw)==meta["sha256"],"Archived payload identity differs: "+name)
        result["archive"].update(entries=len(names),payloads_verified=len(inventory["files"]),uncompressed_bytes=sum(i.file_size for i in archive.infolist()))
        # Extract only into a new scratch directory; original studies remain untouched.
        scratch=Path(tempfile.mkdtemp(prefix="nxdn-availability-publication-offline-",dir=ROOT/"build"))
        for name in names:
            target=scratch.joinpath(*PurePosixPath(name).parts)
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(archive.read(name))
        result["scratch_directory"]=str(scratch)
    study=scratch/"study"; report_raw=(study/"report.json").read_bytes(); report=parse(report_raw)
    check(sha(report_raw)==REPORT and report_raw==(STUDY/"report.json").read_bytes(),"Archived report differs from native original")
    check(len(report["attempts"])==20 and all(a["exit_code"]==0 and a["measurement_pass"] is True for a in report["attempts"]),"Attempt inventory/outcomes differ")
    identities={(a["id"],a["observed"]) for a in report["attempts"]}
    check(len(identities)==20,"Repeated recorded native identity")
    for name,digest in report["files"].items():
        rel=name.replace("\\","/"); check(safe_name(rel),"Unsafe report-relative path")
        check(sha((study/rel).read_bytes())==digest,"Report-listed archive file differs: "+rel)
    result["report_sha256"]=REPORT; result["report_files_verified"]=len(report["files"])
    before=parse((study/"before-execution.json").read_bytes())
    check(before["commit"]==HARNESS and before["baseline_receiver_rerun"] is False and before["binary_sha256"]==BINARY,"Frozen executable provenance differs")
    engines=[p for p in (study/"frozen").rglob("engine.exe")]
    check(len(engines)==1 and sha(engines[0].read_bytes())==BINARY,"Actual archived executable differs")
    groups=("frozen_files","original_files","copied_identities","configured_sources","protected")
    result["preservation_group_counts"]={g:len(before[g]) for g in groups}
    check(result["preservation_group_counts"]==index["preservation_group_counts"],"Publication group counts differ")
    for group in groups:
        for name,digest in before[group].items():
            p=Path(name)
            check(p.is_file() and sha(p.read_bytes())==digest,"Original identity drift: "+group+": "+name)
    # Compare every archived source_repository file with the registered Git blobs.
    source=study/"frozen/source_repository"
    paths=sorted(p.relative_to(source).as_posix() for p in source.rglob("*") if p.is_file())
    git=subprocess.run(["git","archive","--format=tar",HARNESS,*paths],cwd=ROOT,capture_output=True,check=False)
    check(git.returncode==0,"Cannot read frozen Git source blobs: "+git.stderr.decode(errors="replace"))
    with tarfile.open(fileobj=io.BytesIO(git.stdout)) as tar:
        blobs={m.name:tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
    check(set(blobs)==set(paths),"Registered Git source file set differs")
    for name in paths: check((source/name).read_bytes()==blobs[name],"Frozen source differs from Git: "+name)
    result["frozen_git_blobs_verified"]=len(paths)
    # Verify separate audit/source/CI publication material matches external originals.
    for suffix in ("results-audit.py","results-audit.json","results-audit.md","summary.py","summary.json",
                   "ci-push.log","ci-pr.log","ci-push-status.json","ci-pr-status.json","execution.log"):
        name="nxdn-availability-v1-"+suffix
        check((scratch/"publication"/name).read_bytes()==(ROOT/"build"/name).read_bytes(),"External publication material changed: "+suffix)
    audit_raw=(scratch/"publication/nxdn-availability-v1-results-audit.json").read_bytes()
    check(parse(audit_raw)["audit_pass"] is True and sha(audit_raw)==index["independent_results_audit_sha256"],"Independent result-audit identity differs")
    workflow=(scratch/'publication/nxdn-availability-candidate.yml').read_bytes()
    git_workflow=subprocess.check_output(['git','show',HARNESS+':.github/workflows/nxdn-availability-candidate.yml'],cwd=ROOT)
    check(workflow==git_workflow,'Archived workflow differs from frozen Git source')
    result["ci"]={}
    native_names={'NXDN_AVAILABILITY_FRAME','NXDN_AVAILABILITY_VOICE','xerax_availability_symbol_replay',
        'xerax_availability_symbol_replay_no_radio','xerax_availability_symbol_wav',
        'xerax_availability_symbol_wav_no_radio','xerax_availability_symbol_live','xerax_availability_dibit'}
    for event,number in (("push",36203868209),("pr",36203871241)):
        status=parse((scratch/f"publication/nxdn-availability-v1-ci-{event}-status.json").read_bytes())
        check(status["databaseId"]==number and status["headSha"]==HARNESS and status["status"]=="completed"
              and status["conclusion"]=="success" and len(status["jobs"])==4 and all(j["conclusion"]=="success" for j in status["jobs"]),"Wrong CI identity/result")
        raw=(scratch/f"publication/nxdn-availability-v1-ci-{event}.log").read_bytes()
        text=raw.decode("utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8-sig")
        counts={platform:sum("Ran 44 tests" in line and platform in line for line in text.splitlines()) for platform in ("windows-latest","ubuntu-latest")}
        check(counts=={"windows-latest":2,"ubuntu-latest":2},"CI logs do not show both 44-test modes per platform")
        check("python -O -m unittest" in text and "python -m unittest" in text,"CI modes missing")
        native={}
        for mode in ('release','address-undefined'):
            folder=scratch/f'publication/ci-{event}/availability-contracts-{mode}'
            xml=ET.fromstring((folder/'availability-units.xml').read_bytes())
            cases=list(xml.iter('testcase')); names=[c.get('name') for c in cases]
            check(xml.tag=='testsuite' and xml.get('tests')=='8' and len(cases)==8 and set(names)==native_names,
                  'Wrong native contract set: '+event+'/'+mode)
            check(all(xml.get(k,'0')=='0' for k in ('errors','failures','skipped','disabled'))
                  and all(c.get('status')=='run' for c in cases)
                  and not any(e.tag in ('failure','error','skipped') for e in xml.iter()),
                  'Native unit not executed successfully: '+event+'/'+mode)
            commands=parse((folder/'availability/compile_commands.json').read_bytes())
            private=[c for c in commands if '/candidate/' in c['file'].replace('\\','/')]
            check(private,'Candidate unit compile identities absent')
            sanitized=mode=='address-undefined'
            check(all(('-fsanitize=address,undefined' in c['command'])==sanitized for c in private),
                  'Declared sanitizer compilation differs')
            native[mode]={'tests':len(cases),'names':sorted(names),'candidate_compile_records':len(private),
                          'junit_sha256':sha((folder/'availability-units.xml').read_bytes())}
            for local in folder.rglob('*'):
                if local.is_file():
                    original=ROOT/f'build/nxdn-availability-v1-ci-{event}-artifacts'/local.relative_to(scratch/f'publication/ci-{event}')
                    check(local.read_bytes()==original.read_bytes(),'CI artifact differs from downloaded original: '+str(local))
        result["ci"][event]={"run_id":number,"head":HARNESS,"test_summaries":counts,"native_units":native}
    # Execute only frozen Python checker source in the preserved relative hierarchy.
    checker=source/"experiments/nxdn_availability_v1/analyze.py"
    spec=importlib.util.spec_from_file_location("archived_availability_checker",checker)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    inputs=study/"inputs"; manifest=module.validate_inputs(inputs)
    check(sha((inputs/"manifest.json").read_bytes())=="d42a311b1367b0a200dd3c52ab0aaa3bfd292a429785a9ac534ee54348dad98c","Archived input manifest differs")
    pairs={}
    for case in manifest["cases"]:
        pairs[case["id"]]={}
        for detail in (0,1):
            location=study/f"runs/{case['id']}/{detail}"
            for name in ("events.jsonl","pops.u32le","invocation.json","process.json","stderr.txt","audit.json"):
                check((location/name).is_file(),"Missing raw attempt file: "+str(location/name))
            check((case["id"],detail) in identities,"Unregistered archived attempt")
            rows=[parse(line) for line in (location/"events.jsonl").read_bytes().splitlines()]
            expected=parse((location/"audit.json").read_bytes())
            check(expected["exit_code"]==0 and expected["measurement_pass"] is True,"Saved audit wrapper differs")
            actual=module.inspect(rows,location/"pops.u32le",case,manifest,inputs,detail)
            check(canonical(actual)==canonical(expected["audit"]),"Offline case audit semantic mismatch: "+case["id"]+f"/{detail}")
            pairs[case["id"]][detail]=actual
            result["case_replays"].append({"id":case["id"],"observed":detail,"audit_exact":True,
                "canonical_audit_sha256":sha(canonical(actual)),"source_occurrences":len(actual["source_occurrences"]),
                "unsafe_synthesis":len(actual["unsafe_synthesis"]),"exposure_pass":actual["exposure_pass"],
                "retention_pass":actual["retention_pass"],"finite_voice_safety_pass":actual["finite_voice_safety_pass"]})
    comparison=module.compare(pairs,manifest)
    check(canonical(comparison)==canonical(report["comparison"]),"Offline final comparison semantic mismatch")
    result["offline_comparison_exact"]=True
    result["reproduced_gates"]={k:v for k,v in comparison.items() if k.endswith("_pass")}
    # Derive output totals from the independently reanalyzed cases; no receiver
    # execution, encoder import or source-ID inference from decoded words.
    all_audits=[a for group in pairs.values() for a in group.values()]
    totals={key:sum(a['summary'][key] for a in all_audits)
            for key in ('fec_hard_calls','fec_soft_calls','synthesis_calls')}
    totals['exact_source_occurrences']=sum(sum(v['exact'] for v in a['source_occurrences']) for a in all_audits)
    check(totals==index['totals'],'Published totals differ from offline audited raw records')
    check(totals=={'fec_hard_calls':0,'fec_soft_calls':152,'synthesis_calls':152,'exact_source_occurrences':152},
          'Registered aggregate raw output totals differ')
    result["native_totals"]=totals
    check(result["reproduced_gates"]=={k:report["comparison"][k] for k in result["reproduced_gates"]},"Reproduced gates differ")
    result["source_doc_sha256"]=sha((ROOT/"docs/research/NXDN-AVAILABILITY-V1-2026-09-25.md").read_bytes())
    result["audit_pass"]=True

try:
    main()
except Exception as error:
    result["exception"]=type(error).__name__+": "+str(error)
    if not result["failures"]: result["failures"].append(result["exception"])
result["auditor_sha256"]=sha(Path(__file__).read_bytes())
OUTPUT.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n",encoding="utf-8")
NOTE.write_text("# External availability publication audit\n\n"+
    ("PASS" if result["audit_pass"] else "FAIL")+f": {result['checks']} checks; {len(result['failures'])} discrepancies. "
    "This is a post-execution external audit, not pre-execution evidence and not part of its own archive.\n\n"+
    "No native receiver, encoder, build, new input generation or historical matrix execution occurred. "
    "The ZIP was extracted only to a new scratch directory; frozen studies and sources were not edited.\n\n"+
    "Verified the complete ZIP inventory and payload hashes, native report, original preservation groups, registered source Git blobs, "
    "isolated candidate executable, independent audit and CI identities. All 20 raw attempts were reanalyzed with the extracted frozen Python checker; "
    "each saved audit and final comparison were compared as exact canonical JSON.\n\n"+
    "Publication prose retains the separate later-retention failure and blocked product promotion. It distinguishes complete early-slot retention from unavailable "
    "later slots suppressed by the private candidate, and does not claim speech, playback, RF quality or a released app fix.\n\n"+
    "Reproduced gates: `"+json.dumps(result.get("reproduced_gates",{}),sort_keys=True)+"`.\n\n"+
    "Details and hashes are in the adjacent machine-readable audit.\n"+
    ("\nFailures: "+json.dumps(result["failures"])+"\n" if result["failures"] else ""),encoding="utf-8")
print(json.dumps({k:result.get(k) for k in ("audit_pass","checks","failures","offline_comparison_exact","reproduced_gates")}))
raise SystemExit(0 if result["audit_pass"] else 1)
