# Receiver sample-lineage audit — 2026-09-25

Audited base: `4b0dd222c3bb6abb80c50729058471313bbcb5ce` in `build/github-public/XeraX-SDR`. Read-only pipeline audit; no builds or timing runs were performed by this agent. The separately authorized small test-only observer described below was subsequently implemented in three DSP files. This file is an ignored work artifact, not a claim of receiver-speed improvement or APK/EXE integration.

## Decision and first useful experiment

Start with the **real NXDN48 decoder-side synchronization chain driven by independently generated discriminator samples**. Observe a successful cache delivery immediately after both stream-generation checks in `src/dsp/dsd_symbol.c:908` (`rtl_symbol_cache_pop`, line numbers here reflect the new observer insertion). The provider records the absolute start of each fill; the callback reports that fill's actual returned index. Thus the harness reconstructs the supplied discriminator index without treating the rest of the fill as consumed. Record the high-water index immediately after a real `getFrameSync()` return. Then compare all subsequent `getDibitSoft()` results with the independent dibit sequence.

This is an actual decoder component experiment, but its domain is **discriminator samples at 48 kHz**, not original complex IQ samples, wall-clock processing time, first CRC-valid NXDN frame, voice intelligibility, or decryption. It must not be submitted to the existing source-complex-sample timeline contract with relabeled units. An explicitly distinct schema/domain is appropriate. The initial profile should disable cosine/matched-filter switching, use fixed 2400 baud/four levels, fixed generation, and no resampling. Later filter/generation tests must establish their own mapping before expanding that profile.

Existing test precedent: `upstream/dsd-neo/tests/dsp/test_frame_sync_nxdn_fsk_phase.c` invokes real `getFrameSync()/getSymbol()/getDibitSoft()` with 32 preamble dibits followed by sixteen 192-dibit pseudo-frames and mixed known payload symbols. These are synchronization/payload-symbol vectors, **not channel-FEC-valid NXDN frames**. Its provider advances `g_waveform_pos` by an entire read batch; its existing helper that infers a frame index from that provider position is not suitable as an exact consumption oracle. Parent's new harness should retain independent expected absolute boundaries rather than reuse that helper.

The immediate hook does not recover lost callback evidence, prove a filter history mapping, or provide thread-safe instrumentation. A callback must not mutate decoder state, call the setter/decoder, or outlive its user storage. The harness must check all reported indices and generations and clear the callback at teardown.

### Implemented scope and build guards

Only these three tracked files were edited by this agent, after explicit parent assignment:

- `upstream/dsd-neo/src/dsp/dsd_symbol.c`: research-only callback/user globals, setter, callback after successful final generation check, and direct cache-pop test wrapper. The wrapper returns the existing values empty=0, ready=1, retry=2. No protocol or DSP arithmetic was changed.
- `upstream/dsd-neo/src/dsp/symbol_test_support.h`: typed callback API with const state, generation, current-cache index, and returned float; lifecycle limitations documented.
- `upstream/dsd-neo/src/dsp/CMakeLists.txt`: research macro on `dsd-neo_dsp_private_test_support` only, inside `BUILD_TESTING` and `if(XERAX_ACQUISITION_RESEARCH)`.

All new C observer branches/helpers require **both** `DSD_NEO_TEST_HOOKS` and `XERAX_ACQUISITION_RESEARCH`; they reside within the radio block. The ordinary `dsd-neo_dsp` target does not receive these definitions. This adds no observer branch to the normal shipped DSP archive. Parent owns the new test target and observer tests. Direct negative controls should include callback cleared, exhausted cache, generation mismatch at the first check, and a generation change between first and second checks. A rejected sample must emit zero callbacks and leave no apparent accepted source advance.

Useful existing build facts: `upstream/dsd-neo/CMakeLists.txt` includes CTest (line 6), creates `USE_RADIO` through `dsd-neo_feature_radio` when `DSD_HAS_RADIO` (1158), and can force the pipeline with `DSD_FORCE_RADIO_PIPELINE` (131,799–806), without requiring physical RTL hardware. `DSD_ENABLE_RTLSDR` is a backend option, not the sole way to compile radio-pipeline tests. Existing target `dsd-neo_test_frame_sync_nxdn_fsk_phase` and CTest `FRAME_SYNC_NXDN_FSK_PHASE` are defined at `tests/CMakeLists.txt:7475–7492`; the helper dsd_neo_link_dsp_test links the normal production dsd-neo_dsp archive, alongside the real dibit source. The new xerax_nxdn_acquisition_observer target instead links dsd-neo_dsp_private_test_support explicitly. The host replay runner is `dsd-neo_test_receiver_lab` at line 11063. New research tests additionally need the research definition visible when including the guarded header.

Observer source SHA-256 when handed to parent (before parent testing):

- dsd_symbol.c: `40DA0A486400ED7F827EDF601A8DAB7B80F1F1EBB984EE2FCEF9B365881CF4AF`
- symbol_test_support.h: `730E04CAFB09C74DC5ABE1161839127446C0E29FAB2E64CB11E883AD0C1E9E94`
- DSP CMakeLists.txt: `145CAEDE5579CFBC662337E6E5CDE790101DA63EFF40550FE4CEE7B1725962C6`

`git diff --check` passed. No compile/test result is claimed in this audit; parent performs those checks.

## Actual replay lineage

Unless marked otherwise, paths in the following table are relative to `upstream/dsd-neo/` and line references identify the audited source at the base commit. The added observer moves later `dsd_symbol.c` lines by 24.

| Stage | Actual source location | What the value means and why it is not an end-to-end consumed-IQ timestamp |
|---|---|---|
| CLI | `src/runtime/cli/args.c:742,1345,1393–1454` | The tracked native option is `--iq-replay` with metadata, `--iq-replay-rate fast/realtime`, and optional loop. No tracked native `--iq-file` option was found. |
| Lab wrapper | `tests/engine/receiver_lab_replay.c:12–26` | Strips the three lab DSP arguments and enters ordinary runtime bootstrap/engine. It does not bypass the pipeline. |
| File read | `src/io/iq/iq_replay.c:2031–2050` | `fread` decreases remaining bytes. This is a file read cursor, not demodulator/decoder consumption. Rewind at 2053 restores it to the start. |
| Replay input | `src/io/radio/rtl_device.cpp:1679–1764` | `data_offset` advances on read; CU8/CF32 conversion and no-drop enqueue follow. An enqueue/pacing counter can run ahead of decoding. |
| Conversion | same file, `replay_convert_cu8_to_f32`, `replay_convert_cf32_to_f32` | CU8 uses carry handling for incomplete pairs; CF32 requires alignment and the proper capture stage. A complex source sample is an I/Q pair, not a scalar float or byte. |
| Input-ring reservation | `src/io/radio/rtl_sdr_fm.cpp:2302–2334` | `span.got` counts interleaved scalar floats; divide by two only for a valid aligned IQ block. Wrapped input is copied and ring reservation committed **before** DSP. Direct input is released later. Ring tail alone cannot signify DSP completion. |
| DSP | same file, `demod_thread_fn:3460–3522`; `src/dsp/demod_pipeline.cpp:1349` | Profile/reset requests are consumed, then full demodulation runs, metrics are published, input released, output emitted. The block can be suppressed during a retune. |
| Output | `rtl_sdr_fm.cpp:3267–3343` | Output is optionally rationally resampled and copied in interruptible chunks to the scalar output ring. It currently carries floats but no original-source position tags. Partial output on shutdown/retune needs exact tag parity. |
| Decoder read | same file, `rtl_stream_read_replay:7194`, `dsd_rtl_stream_read:7240` | Batch read and EOF-drain semantics. A batch returned to the decoder cache is not the set of samples already used to decide a symbol. |
| Decoder cache | `src/dsp/dsd_symbol.c:897–1060` at base; current pop908/refill1017 | Cache capacity is 512 floats (`include/dsd-neo/core/state.h:50`). Refill is read-ahead. Successful pop is one actual cache delivery after two generation checks. |
| Symbol formation | base `dsd_symbol.c:1670–2175` | Timing nudges, variable spans, optional matched-filter seam replay/catchup, clipping, sample-window accumulation, then symbol commit. `symbolcnt` is not source sample count. |
| Sync | `src/dsp/dsd_frame_sync.c:3683–3694` | A real getSymbol result enters the sync history; match evaluation may return a protocol sync. Capturing the last successful sample watermark immediately on that return is sufficient for the bounded component experiment. |
| Dibit/payload | `src/core/frames/dsd_dibit.c:1009–1080` | `getDibitSoft` and companion entry points use `getSymbol` then slicer and soft-metric logic. Protocol handlers subsequently collect and validate units. |

### Filters, rate changes and block dependence

`full_demod_apply_halfband_decimation` (`demod_pipeline.cpp:1000`) processes a history-bearing cascade and changes the active buffer length. `full_demod_update_channel_state` (1020) applies channel filtering and block-level power/squelch decisions. The CQPSK path (1118) has AGC/equalization/FLL/Gardner/differential/Costas operations; it emits symbol-rate output. CQPSK therefore needs its own interpolation/consumption lineage, not the FSK 1:1 assumption.

`full_demod_apply_iq_balance` (1150) computes statistics over the **whole block**, updates state, and may apply the resulting correction to every sample. Even with base decimation=1, output sample n can therefore depend on later IQ in the block if this feature is enabled. A simplistic output-index-equals-IQ-index availability claim would be wrong. Channel squelch is another block-dependent decision.

The direct FSK branch (`full_demod_handle_fsk_output:1192`) calls `dsd_fsk_modem_discriminator_process` (`src/dsp/fsk_modem.c:136`). That routine iterates IQ pairs, uses current and previous complex values, applies causal running center/scale estimates, and emits one scalar per pair; the first output after state reset is zero. This local 1:1 count does not undo upstream decimation, whole-block decisions, or later resampling.

`src/dsp/resampler.cpp:318–353` maintains filter history and rational phase while emitting zero or multiple outputs for each pushed scalar. `resamp_process_block` (405) adapts the demod state and has an error fallback. Exact output lineage must follow these actual phase/history operations; average rate alone is insufficient. CQPSK bypasses this output resampler (`rtl_sdr_fm.cpp:3330`).

`MAXIMUM_BUF_LENGTH` is 16×16,384=262,144 **floats** (`include/dsd-neo/dsp/demod_state.h:29–31`), up to 131,072 complex inputs per demod reservation. At 48,000 complex samples/s that upper capacity covers about 2.731 seconds. This is a capacity bound, not an observed typical block size. Assigning only a block-wide availability interval would be honest but potentially far too coarse for rapid-sync comparison. A new fixed-small-block mode would itself alter block-adaptive behavior and must not be slipped in as supposedly passive measurement.

### Decoder seam and reset rules

At current `dsd_symbol.c:1694`, handed-back matched-filter raw history is returned before fresh cache samples. At 1974, a filter change with less delay can replay older raw samples; a longer delay can consume extra fresh samples to realign content. At 2035, generation/profile restart clears the current accumulation and timing trace. Availability high-water must never move backward merely because an old sample is processed again. Subtracting filter group delay gives a content alignment estimate, not the instant at which the decoder had sufficient inputs.

The proposed cache observer counts successful **fresh cache delivery**, not each reprocessed old history value. That is enough for the initial fixed/filter-disabled component test. General filter-dependent event support needs original tags in each raw-history entry and an explicit dependency/availability model; a plain sample counter is insufficient to attribute individual old symbols after restart.

Output generation changes are not optional diagnostics: `rtl_stream_clear_output_ring` (`rtl_sdr_fm.cpp:10094`) bumps generation before clearing and resets pending-cache accounting. Cache-pop checks generation before and after selecting a float; a failed check clears pending cache and requests retry. Production mapping must invalidate stale tags through the same checks. A profile change without a new file may invalidate an earlier rate/filter interpretation even if the source bytes are continuous.

Replay RESET waits for an ordered boundary drain (`rtl_device.cpp:2155`); replay MUTE advances omitted timing (`1893–1989`), so pacing `complex_written` may include samples absent from stored payload. Loop rewind drains, restores the initial capture state and restarts offsets (`2188–2220`; callback `rtl_sdr_fm.cpp:4210`). The existing submit/consume generation counters coordinate drain; they do not encode exact complex-source positions.

For a future first original-IQ instrumentation slice, restrict to one non-looped, fixed-rate, event-free FSK capture and invalidate mapping on any purge, retune, output-generation/profile change, output loss or unsupported DSP branch. Then carry tagged source intervals alongside the existing output ring and the 512-sample cache, using exactly the same head/tail publication and generation rules. Proven input reservation boundaries should be captured by the demod owner, not read asynchronously from a global enqueue counter. Establish bounded conservative intervals first; refine only where filter, decimator and resampler dependencies are proved. No original-IQ mapping has been implemented here.

## Where validation actually occurs

A sync pattern is not a valid payload or an intelligible voice call. The dispatcher verdict is often a tuning policy signal that includes history, not current-frame proof.

- **NXDN:** `src/protocol/nxdn/nxdn_frame.c:613–652` initializes current-frame proof to false, reads eight LICH then 174 remaining dibits, and processes control channels between `nxdn_confirm_begin_frame`/`end_frame`. `frame_proved` is collected at 652 **before** voice processing at 663. This is the smallest future aggregation hook for this frame's actual CRC evidence. Return value2 means current proof; return1 may reflect previous confirmation. `dispatch_nxdn.c:46–52` deliberately preserves that distinction. Individual valid subchannel events should name SACCH CRC6 / FACCH or other CRC checks and the exact unit; LICH parity alone is not strong frame proof. `nxdn_deperm.c:262` and 512 show explicit CRC branches. A returned productive verdict after voice would be too late to establish the timeline's valid-frame→PCM ordering.
- **DMR:** `dispatch_dmr.c:148–185` explicitly describes productive as burst processing, not per-burst validation. In `dmr_dburst.c:280–298`, unconfirmed half-rate data sets `crc_correct=1` without a per-block CRC comparison. `dmr_dburst_handle_bptc:342–354` saves `crc_original_validity` then may force accepted CRC state for the RAS heuristic. Therefore hook a specifically CRC-bearing subtype and the original CRC verdict, before acceptance overrides, and report the check strength. The mere flag or productive dispatch cannot be a generic valid-frame event. Slot-Type Golay and voice-embedded checks are different evidence scopes.
- **P25 Phase1:** `dispatch_p25p1.c:214–225` reads and BCH-decodes the current NID; label that event NID/header validation, not complete voice payload. Its later PROFILE_PROVEN return at 459–482 can also be inherited from a recent valid NID despite a current failure. A control-unit CRC hook is `p25p1_tsbk.c:153–172`: `tsbk_decode_block` returns the actual CRC16 result, and success counters update only when err==0. Candidate selection itself falls back to a candidate when no CRC passes, so selection does not imply success.
- **P25 Phase2:** `dispatch_p25p2.c:20–27` always returns productive after `processP2`. `p25p2_frame.c:355–361` fills a dibit buffer before processing its several subframes (`processP2:1772`). `p25p2_xcch.c:447–498` contains explicit SACCH/LCCH CRC12/CRC16 and FACCH CRC12 results. Hook actual err==0, not merely permission to continue processing after a permissive error path. An ISCH codeword identifies framing and is not a voice-payload CRC. A block-buffered validation event needs the stored provenance of its unit or a clearly conservative availability high-water; do not invent a per-subframe original position from loop iteration alone.

PCM requires a separate handoff event at actual accepted player/queue submission, plus validated-unit association. No audio hook was audited or implemented in this bounded slice. Returning decoder PCM is not proof of acoustic speaker playback.

## Independent truth and measurable gates

Colleague's independent corpus inventory is `build/acquisition-corpus-audit-20260925.json`. The 76 existing replay cases have useful decoded metadata and negative controls, but lack independent complete transmitted payload/onset annotations. Some IQ comes from off-air material and some from remodulated discriminator audio. Counts, first output logs, and previous decoder output are insufficient independent truth for acquisition latency.

For the first component experiment, require exact known dibits, exact generated sample offsets/rate, explicit smoothing construction and initial phase, separate delivered-provider and consumed-cache positions, and all matching output bytes. Declare the generated sync boundary rather than presenting its arbitrary non-silent preamble as an independently known RF onset. Exercise multiple read chunks so read-ahead changes without being credited as decoder progress. Keep duplicate/false-sync and payload-error results, not just successful matches. Record exact case outcomes and bounds; do not tune production parameters on this first measurement set.

A future original-IQ experiment additionally needs: independently encoded CRC-valid frames and known onset; conversion and resampling tag oracles; ring wrap and partial-write controls; reset/retune/gap/loop stale-tag rejection; counter overflow controls; matched-filter handback/catchup; variable rate/CQPSK cases; and evidence that enabling observation preserves output. Missing mapping or onset must remain unavailable. This is not a request to build another storage subsystem before measuring the decoder component.

## Primary-source cross-check

The checked-out decoder source is the primary source for all concrete path claims above. External design cross-checks, accessed 2026-09-25:

- GNU Radio's [stream-tag documentation](https://wiki.gnuradio.org/index.php/Stream_Tags) distinguishes item offsets through rate-changing blocks and explicit delay handling. This supports retaining original-domain identity rather than using downstream counts. Its content-delay convention must not be confused with this project's causal availability contract.
- GNU Radio's [symbol_sync_ff implementation](https://github.com/gnuradio/gnuradio/blob/main/gr-digital/lib/symbol_sync_ff_impl.cc) explicitly tracks interpolation phase, changes consumption with timing state, and controls tag propagation. The comparison supports auditing variable-rate stage state, not assuming a nominal samples-per-symbol multiplier gives an exact original position.
- GNU Radio's [symbol_sync_ff API](https://www.gnuradio.org/doc/doxygen/classgr_1_1digital_1_1symbol__sync__ff.html) describes samples-per-symbol as nominal and identifies TED gain as dependent on the anticipated waveform. No performance or interoperability inference about XeraX is drawn from those documents.

These external pages are current reference context, not pinned dependencies or benchmarked competitors. No external code was copied.
