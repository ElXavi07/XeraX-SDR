from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[1]
entries = {}

def add(path, name):
    if name in entries:
        raise ValueError('duplicate archive entry ' + name)
    entries[name] = Path(path).read_bytes()

for folder in ('nxdn-acquisition-20260925', 'nxdn-acquisition-runner-20260925'):
    for path in sorted((root / 'build' / folder).iterdir()):
        if path.is_file():
            add(path, folder + '/' + path.name)
for path in sorted((root / 'build').glob('acquisition-*')):
    if path.is_file():
        add(path, 'audit-and-build/' + path.name)
for path in sorted((root / 'build/acquisition-ci').rglob('*')):
    if path.is_file():
        add(path, 'ci/' + path.relative_to(root / 'build/acquisition-ci').as_posix())
proposal = root / 'build/nxdn-valid-frame-next-proposal-20260925.md'
if proposal.exists():
    add(proposal, 'next-proposal/' + proposal.name)
for name in ('experiments/nxdn_acquisition',):
    for path in sorted((root / name).iterdir()):
        if path.is_file() and path.suffix in ('.py', '.c', '.md'):
            add(path, 'source/' + path.relative_to(root).as_posix())
for name in ('upstream/dsd-neo/CMakeLists.txt', 'upstream/dsd-neo/tests/CMakeLists.txt',
             'upstream/dsd-neo/src/dsp/CMakeLists.txt', 'upstream/dsd-neo/src/dsp/dsd_symbol.c',
             'upstream/dsd-neo/src/dsp/symbol_test_support.h', '.github/workflows/acquisition-research.yml',
             'docs/research/NXDN-ACQUISITION-PREREGISTRATION-2026-09-25.md'):
    add(root / name, 'source/' + name)
binary = Path.home() / 'AppData/Local/XeraXSDR-build/acquisition-research/tests/xerax_nxdn_acquisition_observer.exe'
add(binary, 'research-binary/xerax_nxdn_acquisition_observer.exe')
add(Path(__file__), 'packaging/package_acquisition_evidence.py')
manifest = {name: {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
            for name, raw in entries.items()}
entries['archive-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = root / 'docs/research/evidence/nxdn-acquisition-2026-09-25-raw.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for name, raw in entries.items():
        handle.writestr(name, raw)
with zipfile.ZipFile(archive) as handle:
    if set(handle.namelist()) != set(entries):
        raise RuntimeError('archive membership mismatch')
    for name, raw in entries.items():
        if handle.read(name) != raw:
            raise RuntimeError('archive entry mismatch ' + name)
print(json.dumps({'file': archive.name, 'entries': len(entries), 'bytes': archive.stat().st_size,
                  'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'all_entries_verified': True}))
