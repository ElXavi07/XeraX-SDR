XeraX independent NXDN clear voice-word study
Frozen harness: 3ae30bccc713af7a82ccd4310bda31e21d4c0d4a
Registration: 784843e; receiver baseline: e8498d2.

study/ preserves the complete one-attempt record, sources, inputs, raw rows,
native command-line research probes and runtime files, link maps and hashes.
These EXEs are research tools, not the Windows application or installers.
publication/ adds the independent read-only results audit and CI logs.
The empty frozen execution.log is the pre-execution snapshot; its final
outer-runner summary is retained under publication/.

Original primary licenses remain alongside sources. The codec metadata
contains its copyright/license; the pinned complete codec source tarball
and source portfile are under study/frozen/codec/. Compiler tools are
identified by hashes and were not redistributed. Platform runtimes retain
their own upstream terms. Absolute paths in the original evidence describe
the study machine; report file names using backslashes are Windows paths.

Offline content review requires no native execution: use Python to import
analyze from study/frozen/harness, then inspect_primary(study/inputs,
study/primary/channels9.bin, study/primary/stdout.json) and inspect_probe(
study/inputs, study/primary/channels9.bin, study/probe/rows.jsonl).
Keep the frozen harness together: input validation binds generator hashes.
All paths passed to those functions should be actual extracted Paths.

27,044 registered expectations passed; this is finite bit-level evidence.
Unprotected C errors remain changed. No speech, RF, speed, encryption,
mobile acceptance or new APK/Windows capability is established here.
