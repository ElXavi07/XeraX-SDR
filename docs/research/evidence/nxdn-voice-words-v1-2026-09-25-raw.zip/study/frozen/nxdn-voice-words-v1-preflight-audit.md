# NXDN clear voice words: independent pre-execution audit

Source/linkage and corpus gates pass. No encoder or decoder executable was invoked; the only binary utility used was llvm-nm to read stored archive symbols. Channel-output agreement and the 27,044 production decode results remain future gates. The earlier static-only checkpoint is preserved beside this report as preflight-audit.static.md.

## Source and actual linkage

Five translation units in the final compile database are exactly the wrapper, pinned countBits support, untouched NXDNAudio.cpp, untouched Golay24128.cpp, and probe.c. Strict warnings remain enabled and the redundant USE_NXDN definition is gone. The first macro-redefinition build failures, intervening pthread link failure, and successful final build log remain preserved. The explicit pthread linkage serves the installed mbelib's emulated thread-local storage; it is not a substituted decoder.

The primary link map attributes CNXDNAudio::encode to its pinned object, both Golay encoders to the pinned Golay object, and countBits to the exact utility-support object. The probe map attributes both actual mbe_decodeAmbe3600x2450Frame and mbe_decodeAmbe3600x2450SoftFrame to ambe3600x2450.c.obj. The real installed static archive contains exactly one text definition of each, confirmed with llvm-nm; the link recipe names that archive. Neither API is supplied by probe.c or a test stub. Production dsd_mbe.c calls these same API names; this is component coverage, not execution of the whole production receiver path.

Primary executable SHA-256: b3276e18500dcad95cac8b347f032a14daecc35018859fac74c41d8daf302c4a.
Probe executable SHA-256: 4500157876aead15d956301dfd8fae56b1d9ba7e4893e6426a7274f4cdd3ab50.

The machine audit includes exact source/header, compiler, link-map, compile-database, actual static-library and installed provenance hashes. The retained mbelib source archive's SHA-512 is 9675428bd2d7d87cc77a4b3feed65312622ffa15618ff87399f264e8feca288552aae0bbaa16c79cde97fcef57d4fbb89928df0eca3830668afa8a5871748446, matching both the source portfile and installed SPDX resource. That metadata pins upstream be5992dab7589aec6f3a45fa1881139c0caa2a97. This does not claim a fresh rebuild of the installed library; its historical extracted source directory is absent.

## Frozen source words and packing

The corpus manifest is exactly 4d31e3d17c56162b706f9187f8f000bfbb0fce0f1e353f9ee2519bd66e355a84. Every listed corpus file, frozen primary manifest, all 36 original primary-file blobs and generation-source hash match.

Without importing the generator, arithmetic encoder, checker or decoder, the audit reconstructs every ordered source-word row from the pinned announcement and declared silence bytes, followed by zero/ones, all 49 one-hot words, both 4,096-value sweeps and the pairing zero. All 8,266 IDs, kinds, source indices and 49-bit values match. Every one of the 4,133 input records independently repacks to the exact 53,729 bytes. Original linked padding is ten instances of 62; original silence padding is zero. All normalized input padding is zero. The expected channel file's frozen identity and 74,394-byte size are checked, but its actual primary-encoder agreement is not claimed before execution.

The probe starts each single-bit mutation from its frozen clean word, maps all 72 transmitted bits through the real production dibit schedule, supplies reliability 255 and retains actual hard/soft outputs and input-array immutability. There is no expected-output feedback, synthesis, playback, receiver synchronization or privacy path in this probe.

## Runtime dependency closure

PE32+ AMD64 import tables were read as bytes, including checking that this profile has no delay imports. Recursive non-system imports resolve to three runtime DLLs; absolute paths and SHA-256 are in runtime_files for the outer runner to copy next to the frozen executables:

- libwinpthread-1.dll: b402f9148638752d71f10bfe01177cd351221e7a8366904461573e974a0bc077
- libgcc_s_seh-1.dll: 39f324ab25723005829f72adb1c8058cc35d2f5efe0318a0734a26abbd70a094
- libstdc++-6.dll: 1dca1dda727d80e6c4c218577adfb2b7379ce032766a7ecee1ab73ead9fecfc7

Windows system DLLs remain OS prerequisites, explicitly listed in the JSON rather than recursively copied. No runtime-loader smoke test was performed. The audit does not assume those non-system DLLs are adjacent to the original build outputs or on the future runner's PATH.

No material blocker remains in this bounded source, linkage, corpus and stored-import audit. Freeze checker/runner and copied executable/runtime inputs before the registered single execution. A later failure remains a result; these preflight passes do not predict a favorable encoder or FEC outcome.
