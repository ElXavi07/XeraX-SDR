# Independent NXDN clear voice-word results audit

Pass. This audit read the retained artifacts from the single registered study at build/nxdn-voice-words-v1-run-20260925. It imported neither the experiment checker nor its arithmetic encoder and did not execute either native program. The retained primary and probe attempts each report exit zero. Measurement and study progression pass; product promotion remains false.

## Exact source and content checks

All 8,266 source words and ordered metadata rows were independently reconstructed from the pinned original announcement slice, the primary silence declaration, zero/ones, one-hot words, both complete 12-bit sweeps and the registered padding word. The 4,133 packed input records match exact source ordering and zero-normalized six-bit padding. The primary encoder's entire 74,394-byte output exactly matches the frozen independent expected bytes, including the pairing word. Channel SHA-256 is 05ed6f2d7c548e6b6e94e81bb12534afde0c2e13301791a8f1d4d2778dd6eed3.

Every raw decoder row was independently checked for sequence, source ID, mutation position, hard/soft mode, actual nine-byte transmitted input, exact 49 returned bits and unchanged input arrays. Field classifications come from the preserved primary encoder's A/B/C placement arrays, not from the production decoder or experiment encoder. There are zero wrong inputs, wrong returned words, changed input buffers or negative statuses.

| Case class | Both modes | Per mode | Exact required result |
|---|---:|---:|---|
| Clean | 16,532 | 8,266 | Original source word |
| Single protected A bit | 3,504 | 1,752 | Original source word |
| Single protected B bit | 3,358 | 1,679 | Original source word |
| Single unprotected C bit | 3,650 | 1,825 | Exactly the corresponding source bit changed |
| Total | 27,044 | 13,522 | All matched |

Each source C bit 24–48 was tested 146 times across 73 base words and two modes. All 3,650 unprotected-error cases correctly expose the changed source bit; they are not original-content recovery successes. Single-error coverage is limited to the 73 registered base words. The complete A/B value sweeps add clean-word coverage, not an exhaustive cross-product or multiple-error guarantee.

## Observed counters, separately from content truth

Both modes have the same observed status/error distributions. Clean and C-mutated cases return status zero with all error counters zero. Every A mutation returns status one, c0_errors one, total_errors one and other counters zero. Among the 1,679 B mutations per mode, 803 return status/protected_errors/total_errors zero and 876 return one; all return c0_errors and c4_errors zero. Both groups still preserve exact original source content. The audit records these distributions without imposing a new universal counter rule or guessing the cause of the split.

Flags are two for all hard rows and three for all soft rows. These flags and nonnegative statuses do not prove original content: C-mutated rows retain their ordinary flags and status zero while their required decoded source bit changes. Exact independent bit comparison supplies the correctness evidence.

## Preservation and scope

All 139 report-listed files match, with no missing/unlisted files in the retained run directory. The before-execution groups remain intact: 128 frozen-file identities, 84 original-file identities, five configured source identities and 41 protected identities. These groups overlap in purpose; their counts are not a claim of that many distinct historical artifacts. Every frozen harness source also matches its Git blob at 3ae30bccc713af7a82ccd4310bda31e21d4c0d4a. The primary-source bytes/Git blobs, stage-two channel freeze and both frozen executable identities match.

Native report SHA-256: 22e466257755e88281fc84987eb1a44687b9a51d2ac4af66a96fd9ae04df2c8b.

This establishes finite clear channel-word encoder agreement and actual production mapping/hard-soft FEC content behavior. It does not establish frame acquisition, complete call/control retention, synthesis or intelligibility, played audio, RF sensitivity, decoding speed, mobile behavior or encryption recovery. The previously rejected boundary candidate remains rejected. No raw source, input, output or previous study was changed by this audit.
