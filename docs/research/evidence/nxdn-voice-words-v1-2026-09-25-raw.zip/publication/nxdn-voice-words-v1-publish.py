"""Package already-completed study evidence without any native execution."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
study = root / "build/nxdn-voice-words-v1-run-20260925"
destination = root / "docs/research/evidence"
stem = "nxdn-voice-words-v1-2026-09-25"
archive = destination / (stem + "-raw.zip")
index = destination / (stem + ".json")
if archive.exists() or index.exists(): raise ValueError("Do not overwrite publication")
sha = lambda b: hashlib.sha256(b).hexdigest()
report_bytes = (study / "report.json").read_bytes()
if sha(report_bytes) != "22e466257755e88281fc84987eb1a44687b9a51d2ac4af66a96fd9ae04df2c8b":
    raise ValueError("Native report changed")
report = json.loads(report_bytes)
audit_path = root / "build/nxdn-voice-words-v1-results-audit.json"
if sha(audit_path.read_bytes()) != "c5b11e5af69b80948d64660d8b42f6c52681be31806d86d596a679c764055f0f":
    raise ValueError("Independent audit changed")
audit = json.loads(audit_path.read_bytes())
if not audit["audit_pass"] or not report["progression_pass"] or report["product_promotion"]:
    raise ValueError("Publication outcome differs from audited result")
for name, digest in report["files"].items():
    p = study.joinpath(*name.replace("\\", "/").split("/"))
    if sha(p.read_bytes()) != digest: raise ValueError("Raw evidence changed: " + name)

payload = {}
for p in sorted(study.rglob("*")):
    if p.is_file(): payload["study/" + p.relative_to(study).as_posix()] = p.read_bytes()
extras = [root / "build" / ("nxdn-voice-words-v1-results-audit." + ext) for ext in ("py", "json", "md")]
extras += [root / "build" / ("nxdn-voice-words-v1-" + name) for name in ("ci-push.log", "ci-pr.log", "execution.log")]
extras += [Path(__file__)]
for p in extras: payload["publication/" + p.name] = p.read_bytes()
payload["README.txt"] = (
    "XeraX independent NXDN clear voice-word study\n"
    "Frozen harness: 3ae30bccc713af7a82ccd4310bda31e21d4c0d4a\n"
    "Registration: 784843e; receiver baseline: e8498d2.\n\n"
    "study/ preserves the complete one-attempt record, sources, inputs, raw rows,\n"
    "native command-line research probes and runtime files, link maps and hashes.\n"
    "These EXEs are research tools, not the Windows application or installers.\n"
    "publication/ adds the independent read-only results audit and CI logs.\n"
    "The empty frozen execution.log is the pre-execution snapshot; its final\n"
    "outer-runner summary is retained under publication/.\n\n"
    "Original primary licenses remain alongside sources. The codec metadata\n"
    "contains its copyright/license; the pinned complete codec source tarball\n"
    "and source portfile are under study/frozen/codec/. Compiler tools are\n"
    "identified by hashes and were not redistributed. Platform runtimes retain\n"
    "their own upstream terms. Absolute paths in the original evidence describe\n"
    "the study machine; report file names using backslashes are Windows paths.\n\n"
    "Offline content review requires no native execution: use Python to import\n"
    "analyze from study/frozen/harness, then inspect_primary(study/inputs,\n"
    "study/primary/channels9.bin, study/primary/stdout.json) and inspect_probe(\n"
    "study/inputs, study/primary/channels9.bin, study/probe/rows.jsonl).\n"
    "Keep the frozen harness together: input validation binds generator hashes.\n"
    "All paths passed to those functions should be actual extracted Paths.\n\n"
    "27,044 registered expectations passed; this is finite bit-level evidence.\n"
    "Unprotected C errors remain changed. No speech, RF, speed, encryption,\n"
    "mobile acceptance or new APK/Windows capability is established here.\n"
).encode("utf-8")
manifest = {"schema": 1, "kind": "nxdn_voice_words_v1_archive", "native_execution": False,
            "files": {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in sorted(payload.items())}}
payload["archive-manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(payload.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 9, 25, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as z:
    if set(z.namelist()) != set(payload) or len(z.namelist()) != len(payload): raise ValueError("Archive inventory mismatch")
    for name, raw in payload.items():
        if z.read(name) != raw: raise ValueError("Archive bytes differ: " + name)
    if z.testzip() is not None: raise ValueError("Archive CRC error")
publication = {"schema": 1, "kind": "nxdn_voice_words_v1", "registration_commit": "784843e",
    "harness_commit": "3ae30bccc713af7a82ccd4310bda31e21d4c0d4a",
    "receiver_baseline": "e8498d298ad1a6f85da93a8b07730ec99f7c1416",
    "measurement_pass": report["measurement_pass"], "progression_pass": report["progression_pass"],
    "product_promotion": False, "native_attempts": report["attempts"],
    "primary": report["primary"]["counts"], "probe": report["probe"]["counts"],
    "report_sha256": sha(report_bytes), "independent_audit_sha256": sha(audit_path.read_bytes()),
    "ci": {"harness_tests": 52, "modes": ["normal", "optimized"], "platforms": ["Windows", "Linux"],
           "push_run": 36182669076, "pr_run": 36182675273, "native_matrix_in_ci": False},
    "archive": {"file": archive.name, "bytes": archive.stat().st_size, "entries": len(payload),
                "sha256": sha(archive.read_bytes()), "every_entry_verified": True},
    "limits": ["clear finite channel words only", "no complete calls, speech synthesis or playback",
               "single errors tested in 73 base words only", "no I/Q, RF, timing or phone acceptance",
               "no privacy keys or encryption recovery", "release packages and defaults unchanged"]}
index.write_text(json.dumps(publication, indent=2) + "\n", encoding="utf-8")
print(json.dumps(publication["archive"]))
