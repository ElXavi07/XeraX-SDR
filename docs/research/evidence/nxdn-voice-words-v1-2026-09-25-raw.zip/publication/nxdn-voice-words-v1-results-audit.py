"""Independent retained-output audit. Imports no experiment encoder/checker."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'build/nxdn-voice-words-v1-run-20260925'
OUT = ROOT / 'build/nxdn-voice-words-v1-results-audit'
COMMIT = '3ae30bccc713af7a82ccd4310bda31e21d4c0d4a'


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((RUN / name).read_bytes())


def verify_group(group):
    for name, digest in group.items():
        p = Path(name)
        need(p.is_file() and sha(p) == digest, 'identity changed: ' + name)
    return len(group)


def main():
    report = read('report.json')
    before = read('before-execution.json')
    preprobe = read('before-probe.json')
    need(before['commit'] == COMMIT, 'unexpected frozen commit')
    need(report['attempts'] == [{'stage': 'primary', 'exit_code': 0}, {'stage': 'probe', 'exit_code': 0}], 'native attempt identity')
    need(report['measurement_pass'] is True and report['progression_pass'] is True and report['product_promotion'] is False, 'declared result differs')
    actual_files = {str(p.relative_to(RUN)) for p in RUN.rglob('*') if p.is_file() and p.name != 'report.json'}
    need(actual_files == set(report['files']), 'unlisted or missing study files')
    for name, digest in report['files'].items():
        need(sha(RUN / name) == digest, 'report-listed file changed: ' + name)
    groups = {name: verify_group(before[name]) for name in ('frozen_files', 'original_files', 'configured_sources', 'protected')}
    need(report['preservation_pass'] is True, 'report did not preserve inputs')
    for name in ('primary', 'probe'):
        process = read(name + '/process.json')
        need(process == {'exit_code': 0}, 'process failure')
        inv = read(name + '/invocation.json')
        need(inv['timeout_seconds'] == 120 and inv['dsd_environment_removed'] is True, 'invocation contract')
        need(Path(inv['arguments'][0]).resolve() == (RUN / 'frozen' / ('xerax_voice_' + name + '.exe')).resolve(), 'wrong native binary path')
        need(sha(inv['arguments'][0]) == before['binaries'][name], 'binary changed')
    need(read('primary/invocation.json')['arguments'][1:] == [str((RUN / 'inputs/input.pairs13').resolve()), str((RUN / 'primary/channels9.bin').resolve())], 'primary input/output path')
    need(read('probe/invocation.json')['arguments'][1:] == [str((RUN / 'primary/channels9.bin').resolve())], 'probe did not use agreed channel file')

    inputs = RUN / 'inputs'
    primary = RUN / 'frozen/primary-sources'
    manifest = read('inputs/manifest.json')
    need(sha(inputs / 'manifest.json') == '4d31e3d17c56162b706f9187f8f000bfbb0fce0f1e353f9ee2519bd66e355a84', 'registered corpus changed')
    for name, item in manifest['files'].items():
        need((inputs / name).stat().st_size == item['bytes'] and sha(inputs / name) == item['sha256'], 'frozen corpus identity')
    need((inputs / 'primary-manifest.json').read_bytes() == (primary / 'manifest.json').read_bytes(), 'primary manifest changed')
    pm = json.loads((primary / 'manifest.json').read_bytes())
    for item in pm['files']:
        data = (primary / item['path']).read_bytes()
        need(len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], 'primary bytes changed')
        need(hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == item['git_blob_sha1'], 'primary Git blob differs')
    source_git_matches = {}
    for p in (RUN / 'frozen/harness').iterdir():
        if p.is_file():
            rel = 'experiments/nxdn_voice_words_v1/' + p.name
            blob = subprocess.check_output(['git', 'show', COMMIT + ':' + rel], cwd=ROOT)
            need(p.read_bytes() == blob, 'frozen harness differs from declared Git source')
            source_git_matches[rel] = hashlib.sha256(blob).hexdigest()

    asset = (primary / 'NXDNClients/NXDNGateway/Audio/en_GB.nxdn').read_bytes()
    linked = asset[8476:8606]
    need(hashlib.sha256(linked).hexdigest() == '8f4116e67a4c950a524c8568caf17d550e9b0b0bbdac3f9e3761ce76c0056e41', 'linked source differs')
    silence = bytes.fromhex('f0000000000078000000000000')
    voice_source = (primary / 'NXDNClients/NXDNGateway/Voice.cpp').read_text()
    declaration = re.search(r'const unsigned char SILENCE\[\]\s*=\s*\{([^}]+)\}', voice_source).group(1)
    need(bytes(int(x, 16) for x in re.findall(r'0x([0-9a-fA-F]+)U', declaration)) == silence, 'silence source differs')
    words = []

    def add(kind, index, bits):
        words.append({'id': len(words), 'kind': kind, 'source_index': index, 'bits': bits})

    for kind, raw in (('announcement', linked), ('upstream_silence', silence)):
        for unit in range(len(raw) // 13):
            bits = ''.join(f'{byte:08b}' for byte in raw[unit * 13:(unit + 1) * 13])
            add(kind, unit * 2, bits[0:49])
            add(kind, unit * 2 + 1, bits[49:98])
    add('zero', 0, '0' * 49)
    add('ones', 0, '1' * 49)
    for bit in range(49):
        add('onehot', bit, ''.join('1' if j == bit else '0' for j in range(49)))
    for value in range(4096):
        add('sweep_a', value, f'{value:012b}' + '0' * 37)
    for value in range(4096):
        add('sweep_b', value, '0' * 12 + f'{value:012b}' + '0' * 25)
    add('pair_padding', 0, '0' * 49)
    need(words == read('inputs/words.json') and len(words) == 8266, 'source-word/ID reconstruction')
    packed = (inputs / 'input.pairs13').read_bytes()
    need(len(packed) == 53729, 'packed size')
    for pair in range(4133):
        bits = words[2 * pair]['bits'] + words[2 * pair + 1]['bits'] + '000000'
        expected = bytes(int(bits[j:j + 8], 2) for j in range(0, 104, 8))
        need(packed[13 * pair:13 * (pair + 1)] == expected, 'paired bits or padding mismatch')

    channels = (RUN / 'primary/channels9.bin').read_bytes()
    expected_channels = (inputs / 'expected.channels9').read_bytes()
    need(channels == expected_channels and len(channels) == 74394, 'primary channel mismatch')
    need(read('primary/stdout.json') == {'schema': 1, 'kind': 'primary_voice_encoder', 'records': 4133, 'words': 8266, 'input_bytes': 53729, 'output_bytes': 74394, 'encode_calls': 4133}, 'primary declared count mismatch')
    need(preprobe['channel_sha256'] == hashlib.sha256(channels).hexdigest() and preprobe['channel_bytes'] == 74394 and preprobe['expected_calls'] == 27044, 'probe-stage freeze mismatch')
    need(preprobe['binary_sha256'] == before['binaries']['probe'], 'probe-stage binary mismatch')

    # Derive field classes directly from the pinned primary encoder placement
    # arrays; neither the production map nor experimental encoder/checker feeds
    # the expected returned bits. C bits have no error-correction promise.
    encoder = (primary / 'MMDVM-Host/NXDNAudio.cpp').read_text()
    layout = {}
    for field in ('A', 'B', 'C'):
        content = re.search(field + r'_TABLE\[\]\s*=\s*\{([^}]+)\}', encoder).group(1)
        positions = [int(x) for x in re.findall(r'(\d+)U', content)]
        need(len(positions) == {'A': 24, 'B': 23, 'C': 25}[field], 'primary field width')
        for index, position in enumerate(positions):
            need(position not in layout, 'duplicate transmitted index')
            layout[position] = (field, index)
    need(sorted(layout) == list(range(72)), 'incomplete transmitted map')
    schedule = [(word, -1, mode) for word in range(8266) for mode in ('hard', 'soft')]
    schedule += [(word, bit, mode) for word in range(73) for bit in range(72) for mode in ('hard', 'soft')]
    need(len(schedule) == 27044, 'independent call schedule')
    rows = (RUN / 'probe/rows.jsonl').read_text().splitlines()
    need(len(rows) == len(schedule), 'raw row count')
    counts = Counter()
    histograms = defaultdict(lambda: defaultdict(Counter))
    c_change_positions = Counter()
    fields = ('status', 'c0_errors', 'protected_errors', 'c4_errors', 'total_errors', 'flags')
    for sequence, (line, (word, mutation, mode)) in enumerate(zip(rows, schedule)):
        row = json.loads(line)
        need((row['seq'], row['word'], row['mutation'], row['mode']) == (sequence, word, mutation, mode), 'raw schedule identity mismatch')
        sent = bytearray(channels[word * 9:(word + 1) * 9])
        expected = [int(bit) for bit in words[word]['bits']]
        if mutation < 0:
            category = 'clean'
        else:
            sent[mutation // 8] ^= 1 << (7 - mutation % 8)
            field, index = layout[mutation]
            category = {'A': 'protected_a', 'B': 'protected_b', 'C': 'unprotected_c'}[field]
            if field == 'C':
                expected[24 + index] ^= 1
                c_change_positions[24 + index] += 1
        need(row['input'] == bytes(sent).hex(), 'mutated input mismatch')
        need(type(row['bits']) is list and all(type(bit) is int and bit in (0, 1) for bit in row['bits']), 'nonbinary returned word')
        need(row['bits'] == expected, 'wrong exact returned source word')
        need(type(row['input_unchanged']) is int and row['input_unchanged'] == 1, 'const input was changed')
        need(type(row['status']) is int and row['status'] >= 0, 'negative or malformed decoder status')
        counts[category] += 1
        counts[mode] += 1
        for field in fields:
            need(type(row[field]) is int, 'malformed counter/flag')
            # Record observed distributions; no post-hoc universal error-count
            # rule or success flag substitutes for exact content checks.
            histograms[mode + '/' + category][field][str(row[field])] += 1
    expected_counts = {'clean': 16532, 'protected_a': 3504, 'protected_b': 3358, 'unprotected_c': 3650, 'hard': 13522, 'soft': 13522}
    need(dict(counts) == expected_counts, 'classified totals mismatch')
    need(dict(c_change_positions) == {bit: 146 for bit in range(24, 49)}, 'unprotected source-bit coverage mismatch')
    for key, value in expected_counts.items():
        need(report['probe']['counts'][key] == value, 'reported category count differs')
    need(report['probe']['counts']['checked_calls'] == 27044 and report['probe']['counts']['wrong_output'] == 0, 'reported validation differs')

    outcome = {'audit_pass': True, 'native_execution_by_audit': False, 'study_commit': COMMIT, 'audit_source_sha256': sha(Path(__file__)), 'report_sha256': sha(RUN / 'report.json'), 'report_files_verified': len(report['files']), 'preservation_groups_verified': groups, 'frozen_harness_git_blobs': source_git_matches, 'measurement_pass': True, 'progression_pass': True, 'product_promotion': False, 'retained_native_attempts': [{'stage': 'primary', 'exit_code': 0}, {'stage': 'probe', 'exit_code': 0}], 'source_words_independently_reconstructed': 8266, 'input_pairs_independently_reconstructed': 4133, 'channel_bytes_exactly_equal': 74394, 'channel_sha256': hashlib.sha256(channels).hexdigest(), 'probe_rows_independently_checked': 27044, 'counts': expected_counts, 'wrong_input_or_output': 0, 'changed_const_input': 0, 'negative_status': 0, 'unprotected_source_bits': dict(sorted(c_change_positions.items())), 'observed_counter_histograms': {key: {field: dict(sorted(counter.items(), key=lambda p: int(p[0]))) for field, counter in value.items()} for key, value in sorted(histograms.items())}, 'independence': ['No experiment analyze.py or encoding.py import; no native replay.', 'Source words reconstructed from original pinned asset/silence declaration and registered arithmetic ID recipe.', 'Protected/unprotected positions read from preserved primary encoder arrays; exact C-bit mutation expected rather than original-word success.', 'Error/flag distributions are observations, not substitute correctness gates.'], 'limits': ['Finite channel-word mapping/FEC evidence only; not acquisition, complete air-frame/control processing, speech synthesis/intelligibility, playback, RF, throughput, mobile behavior or cryptography.', 'A/B single-error correction and C-bit transparency are checked only for registered 73 base words; clean exhaustive A/B sweeps are separate coverage.', 'Audit establishes retained invocation records, not absence of unrecorded external processes.']}
    OUT.with_suffix('.json').write_text(json.dumps(outcome, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'audit_pass': True, 'report_sha256': outcome['report_sha256'], 'report_files': len(report['files']), 'preservation_groups': groups, 'counts': expected_counts, 'histograms': outcome['observed_counter_histograms'], 'json_sha256': sha(OUT.with_suffix('.json'))}, indent=2))


if __name__ == '__main__':
    main()
