# Frozen IQ-history screening evidence, 25 September 2026

These are storage copies on one Windows host, not RF, decoder or phone timings.
All 25 raw CSV/stdout/stderr trials are preserved. Reports omit local absolute
paths, retain workload arguments, and record their original local report hash.
No binaries are included. Baseline library is frozen from Git commit 274677a;
candidate library and C++ harness source hashes are in the accompanying JSON.
The orchestration script here is the exact original version used by the screen.
The repository's newer validator was also applied afterwards, without re-running
or changing these measurements. Its robustness tests are separate from timings.

The baseline and candidate C++ harness are identical. Compile in this directory
with GNU C++ 16.1.0, as used on the measured Windows 10 i5-1038NG7 host:

g++ -O3 -DNDEBUG -std=c++17 -Wall -Wextra -Wpedantic -Werror -pthread baseline/latency.cpp baseline/iq_history.cpp baseline/credit_history.cpp -o baseline/latency.exe
cmake -S candidate -B candidate/build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build candidate/build --parallel 2
python candidate/run_latency.py --baseline baseline/latency.exe --candidate candidate/build/xerax_iq_history_latency.exe --out new-cf32 --seconds 30 --rounds 3 --formats cf32 --holds 0

Secondary runs used --seconds 15
--rounds 1, CU8 hold0 then CF32 hold500. Output directories must be new.
Never run performance trials concurrently with builds or other speed tests.

Important first-harness limits: hold500 is a requested minimum released only at
100ms request ticks; actual held duration was not measured. Snapshot wake zeros
are placeholders. Producer scheduling was uncontrolled. Byte verification adds
consumer CPU load, and fewer successful requests reduce that work. Three rounds
are a short, incompletely order-balanced screen. On verification failure this
first C++ harness may not preserve the partial CSV. Accepted bytes, epoch, range
and size are checked; other stream fields are covered by separate contract tests.
Both chunk sizes failed the predeclared completion and latency gates. No live
application integration, production promotion or whole-decoder speedup resulted.
