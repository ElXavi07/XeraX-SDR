"""Sequential, rotated-order storage trials with raw trace verification.

No SDK, hardware, credentials, network or application configuration is used.
Never run this concurrently with another performance experiment or build.
"""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import statistics
import subprocess
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked_trace(path, result):
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    append = [r for r in rows if r["kind"] == "append"]
    snapshots = [r for r in rows if r["kind"] == "snapshot"]
    assert len(append) == result["appends"] == result["seconds"] * 100
    assert len(snapshots) == result["snapshot_attempts"]
    assert [int(r["index"]) for r in append] == list(range(len(append)))
    assert [int(r["index"]) for r in snapshots] == list(range(len(snapshots)))
    successful = [r for r in snapshots if int(r["status"]) == 0]
    assert len(successful) == result["snapshot_ok"]
    assert result["snapshot_ok"] + result["snapshot_busy"] + result["snapshot_deadline"] + result["snapshot_not_retained"] == len(snapshots)
    assert sum(int(r["missed_deadline"]) for r in append) == result["finish_after_next_scheduled_block"]
    assert sum(float(r["call_us"]) > 10000 for r in append) == result["append_call_over_10ms"]
    for name, values in (
        ("append_us", [float(r["call_us"]) for r in append]),
        ("wake_lateness_us", [float(r["wake_late_us"]) for r in append]),
        ("snapshot_success_us", [float(r["call_us"]) for r in successful]),
        ("verification_us", [float(r["verify_us"]) for r in successful]),
        ("snapshot_rejected_us", [float(r["call_us"]) for r in snapshots if int(r["status"]) != 0]),
    ):
        assert all(math.isfinite(x) and x >= 0 for x in values), name
        if not values:
            assert result[name] is None
            continue
        values.sort()
        expected = {"n": len(values), "max": values[-1]}
        expected.update({f"p{p}": values[math.ceil(len(values) * p / 100) - 1] for p in (50, 95, 99)})
        for key, value in expected.items():
            assert abs(result[name][key] - value) < 0.00001, (name, key, result[name], expected)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seconds", type=int, default=60)
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--formats", nargs="+", choices=["cu8", "cf32"], default=["cu8", "cf32"])
    parser.add_argument("--holds", nargs="+", type=int, default=[0, 500])
    args = parser.parse_args()
    if not 1 <= args.seconds <= 600 or not 1 <= args.rounds <= 20 or any(not 0 <= h <= 10000 for h in args.holds):
        parser.error("Workload outside documented bounds")
    args.out.mkdir(parents=True, exist_ok=False)
    baseline, candidate = args.baseline.resolve(), args.candidate.resolve()
    variants = [("none", baseline, "none"), ("baseline", baseline, "whole"),
                ("credit_whole", candidate, "whole"), ("chunk64", candidate, "chunk64"),
                ("chunk256", candidate, "chunk256")]
    report = {"schema": 1, "scope": "paced IQ-storage latency screening; not live RF or decoder performance",
              "host": {"platform": platform.platform(), "processor": platform.processor(), "logical_cpus": os.cpu_count()},
              "binary_sha256": {"baseline": digest(baseline), "candidate": digest(candidate)},
              "harness_sha256": digest(Path(__file__).with_name("latency.cpp")),
              "candidate_library_sha256": {n: digest(Path(__file__).with_name(n)) for n in
                  ("iq_history.h", "iq_history.cpp", "credit_history.h", "credit_history.cpp")},
              "baseline_library_sha256": {n: digest(baseline.parent / n) for n in
                  ("iq_history.h", "iq_history.cpp", "credit_history.h", "credit_history.cpp")},
              "seconds_per_trial": args.seconds, "rounds": args.rounds,
              "order": "rotate variants by round; formats and holds in argument order",
              "clock": "std::chrono::steady_clock; per-call timer, separate wake lateness",
              "scheduler_affinity_priority_or_timer_resolution_changed": False,
              "trials": [], "summary": [], "production_promotion": False}
    target = args.out / "report.json"

    def save():
        target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    save()
    for fmt in args.formats:
        for hold in args.holds:
            for round_index in range(args.rounds):
                offset = round_index % len(variants)
                for label, exe, variant in variants[offset:] + variants[:offset]:
                    name = f"{fmt}-hold{hold}-r{round_index}-{label}"
                    csv_path = (args.out / (name + ".csv")).resolve()
                    command = [str(exe), "--variant", variant, "--format", fmt, "--seconds", str(args.seconds),
                               "--snapshot-hz", "10", "--hold-ms", str(hold), "--csv", str(csv_path)]
                    begin = time.monotonic()
                    try:
                        run = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=args.seconds + 30)
                    except subprocess.TimeoutExpired as exc:
                        (args.out / (name + ".stdout")).write_bytes(exc.stdout or b"")
                        (args.out / (name + ".stderr")).write_bytes(exc.stderr or b"")
                        report["trials"].append({"name": name, "variant": label, "format": fmt,
                            "hold_ms": hold, "round": round_index, "command": command, "status": "timeout"})
                        save()
                        raise
                    (args.out / (name + ".stdout")).write_bytes(run.stdout)
                    (args.out / (name + ".stderr")).write_bytes(run.stderr)
                    trial = {"name": name, "variant": label, "format": fmt, "hold_ms": hold,
                             "round": round_index, "command": command, "exit_code": run.returncode,
                             "wall_seconds_including_startup": time.monotonic() - begin}
                    report["trials"].append(trial)
                    if run.returncode:
                        trial["status"] = "failed"; save()
                        raise RuntimeError(f"Trial failed; retained outputs for {name}")
                    try:
                        trial["measurements"] = json.loads(run.stdout)
                        checked_trace(csv_path, trial["measurements"])
                    except Exception as exc:
                        trial.update(status="invalid_measurement", error=str(exc)); save()
                        raise
                    trial.update(status="passed", trace_sha256=digest(csv_path))
                    save()
                    m = trial["measurements"]
                    print(f"{name}: append p99 {m['append_us']['p99']:.3f} us; snapshots {m['snapshot_ok']}/{m['snapshot_attempts']}", flush=True)
    for fmt in args.formats:
        for hold in args.holds:
            for label, _, _ in variants:
                trials = [t["measurements"] for t in report["trials"] if t["format"] == fmt and t["hold_ms"] == hold and t["variant"] == label]
                report["summary"].append({"format": fmt, "hold_ms": hold, "variant": label, "trials": len(trials),
                    "median_run_append_p99_us": statistics.median(t["append_us"]["p99"] for t in trials),
                    "median_run_append_max_us": statistics.median(t["append_us"]["max"] for t in trials),
                    "snapshot_ok": sum(t["snapshot_ok"] for t in trials),
                    "snapshot_attempts": sum(t["snapshot_attempts"] for t in trials),
                    "append_calls_over_10ms": sum(t["append_call_over_10ms"] for t in trials),
                    "scheduled_deadlines_missed": sum(t["finish_after_next_scheduled_block"] for t in trials)})
    report["complete"] = True
    save()
    print(f"Completed {len(report['trials'])} trials; no production-promotion verdict.", flush=True)


if __name__ == "__main__":
    main()
