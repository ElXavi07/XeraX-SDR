XeraX independent NXDN complete-frame reference, AIR v1
Registration fdb90ec; frozen harness d9121a93c44e0cdf6533497b056490614a8fa4fc.
One primary native process, nine frames, 864 bytes, 24 known voice intervals.
This archive is research evidence, not a new app build or receiver result.

study/ preserves the whole registered attempt and its before-execution identities.
frozen/primary retains originals, licenses, minimal private source diffs and metadata.
frozen/source_repository preserves the hierarchy needed by independent checkers.
The research EXE and runtime DLLs are frozen tools, not an installer. Compiler tools
are hashed but not redistributed; Windows system libraries remain prerequisites.
publication/ contains separate raw-result audits, CI logs and the final outer-runner
summary. That final log is outside the recorded pre-execution inventory.
The older preflight audit source is included because the new build audit extracts
its read-only PE/map parser functions (with an explicitly retained symbol fix).

Offline content check, without native execution: import analyze from
study/frozen/source_repository/experiments/nxdn_air_v1 and call inspect_output with
Path arguments for study/inputs, study/primary/frames.records96 and
study/primary/stdout.json. Keep the entire frozen source hierarchy intact.
Original absolute identities describe the study machine; relocations do not
rewrite them. Windows-relative file names in JSON use backslashes.

No acquisition, receiver routing, synthesis, listening, RF, I/Q, speed, privacy-key,
GPU or APK/Windows improvement is claimed. Downstream work requires registration.
