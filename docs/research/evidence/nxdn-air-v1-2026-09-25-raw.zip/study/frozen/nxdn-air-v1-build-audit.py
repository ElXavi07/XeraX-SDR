"""Read-only primary AIR build audit; never executes the registered encoder."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BUILD = Path(os.environ['LOCALAPPDATA']) / 'XeraXSDR-build/nxdn-air-v1-20260925'
PRIVATE = ROOT / 'build/nxdn-air-v1-primary-20260925'
OUT = ROOT / 'build/nxdn-air-v1-build-audit'

def need(value, message):
    if not value:
        raise ValueError(message)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

# Reuse audited read-only PE/map parsers, retaining their exact parent script.
# AST selection cannot invoke that prior study's main or any encoder.
parser_source = ROOT / 'build/nxdn-voice-words-v1-preflight-audit.py'
parser_tree = ast.parse(parser_source.read_text(encoding='utf-8'))
for node in parser_tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in ('pe_imports', 'map_owners'):
        source = ast.get_source_segment(parser_source.read_text(encoding='utf-8'), node)
        source = source.replace('line.strip().endswith(symbol)', '(len(line.split(maxsplit=3)) == 4 and line.split(maxsplit=3)[3] == symbol)')
        exec(compile(source, str(parser_source), 'exec'))

def main():
    path = ROOT / 'experiments/nxdn_air_v1/prepare_build.py'
    spec = importlib.util.spec_from_file_location('air_private_verify', path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    metadata = module.verify(PRIVATE)
    module.read_originals(ROOT / 'build/nxdn-voice-v1-primary')
    need(metadata['total_replacements'] == 5, 'wrong private corrections')
    commands = json.loads((BUILD / 'compile_commands.json').read_bytes())
    originals = PRIVATE / 'originals/MMDVM-Host'
    expected = [ROOT / 'experiments/nxdn_air_v1/primary_encoder.cpp', PRIVATE / 'support/primary_support.cpp']
    expected += [originals / (name + '.cpp') for name in ('NXDNLICH', 'NXDNConvolution', 'NXDNCRC', 'NXDNAudio', 'Golay24128', 'Sync')]
    expected += [PRIVATE / 'generated' / (name + '.cpp') for name in ('NXDNSACCH', 'NXDNFACCH1')]
    need(len(commands) == 10 and {Path(c['file']).resolve() for c in commands} == {p.resolve() for p in expected}, 'configured closure differs')
    need(all(all(flag in c['command'] for flag in ('-Werror', '-Wall', '-Wextra', '-Wpedantic')) for c in commands), 'strict flags missing')
    owners = {Path(c['file']).name: Path(c['output']).relative_to(BUILD).as_posix() + ':(.text)' for c in commands}
    symbols = {
        'main': 'primary_encoder.cpp',
        'CNXDNLICH::encode(unsigned char*)': 'NXDNLICH.cpp',
        'CNXDNSACCH::encode(unsigned char*) const': 'NXDNSACCH.cpp',
        'CNXDNFACCH1::encode(unsigned char*, unsigned int) const': 'NXDNFACCH1.cpp',
        'CNXDNConvolution::encode(unsigned char const*, unsigned char*, unsigned int) const': 'NXDNConvolution.cpp',
        'CNXDNCRC::encodeCRC6(unsigned char*, unsigned int)': 'NXDNCRC.cpp',
        'CNXDNCRC::encodeCRC12(unsigned char*, unsigned int)': 'NXDNCRC.cpp',
        'CNXDNAudio::encode(unsigned char const*, unsigned char*) const': 'NXDNAudio.cpp',
        'CGolay24128::encode23127(unsigned int)': 'Golay24128.cpp',
        'CGolay24128::encode24128(unsigned int)': 'Golay24128.cpp',
        'CSync::addNXDNSync(unsigned char*)': 'Sync.cpp',
        'CUtils::countBits(unsigned int)': 'primary_support.cpp'}
    mapped = map_owners(BUILD / 'xerax_air_primary.map', symbols)
    for symbol, source in symbols.items():
        need(mapped[symbol] == [owners[source]], 'wrong symbol owner: ' + symbol)
    old = json.loads((ROOT / 'build/nxdn-voice-words-v1-preflight-audit.json').read_bytes())
    available = {Path(p).name.lower(): Path(p) for p in old['runtime_files']}
    binary = BUILD / 'xerax_air_primary.exe'
    pending = [binary]; graph = {}; runtime = {}; os_names = set()
    while pending:
        p = pending.pop()
        if str(p) in graph: continue
        imports = pe_imports(p); graph[str(p)] = imports
        for name in imports:
            if name.lower() in ('kernel32.dll', 'msvcrt.dll'):
                os_names.add(name); continue
            need(name.lower() in available, 'unresolved non-system import: ' + name)
            actual = available[name.lower()]
            need(digest(actual) == old['runtime_files'][str(actual)], 'runtime changed')
            runtime[str(actual)] = digest(actual); pending.append(actual)
    need(set(runtime) == set(old['runtime_files']), 'expected runtime closure differs')
    compiler = Path(re.search(r'^"?(.+?clang\+\+\.exe)', commands[0]['command']).group(1))
    dependencies = [Path(__file__), parser_source, path, compiler, compiler.parent / 'ld.lld.exe',
        ROOT / 'experiments/nxdn_air_v1/CMakeLists.txt',
        ROOT / 'experiments/nxdn_voice_words_v1/primary_support.cpp',
        ROOT / 'docs/research/NXDN-AIR-V1-PREREGISTRATION-2026-09-25.md']
    dependencies += [BUILD / name for name in ('compile_commands.json', 'CMakeCache.txt', 'build.ninja', 'toolchain.cmake', 'xerax_air_primary.map', 'primary-source-verification.json')]
    dependencies += [p for p in PRIVATE.rglob('*') if p.is_file()] + expected
    deps = {str(p.resolve()): digest(p) for p in dependencies}
    text = (ROOT / 'experiments/nxdn_air_v1/primary_encoder.cpp').read_text()
    need('lich.setRaw(0)' in text, 'registered LICH initialization absent')
    result = {'schema': 1, 'source_and_linkage_pass': True, 'native_execution': False,
        'configured_translation_units': len(commands), 'dependencies': deps, 'runtime_files': runtime,
        'binary_sha256': digest(binary), 'symbol_owners': mapped, 'binary_import_graph': graph,
        'system_prerequisites': sorted(os_names), 'registered_corrections': metadata['corrections'],
        'preflight_changes': ['Before first build, wrapper LICH initialization was made literal setRaw(0) followed by all field setters, as registered.',
            'Runner target names aligned with CMake xerax_air_primary before any execution.',
            'Audit first falsely required an explicit -std=c++17 flag although CMake uses the compiler default; retained strict warnings check instead.',
            'Audit second matched __main as a suffix of main; changed map parser to exact symbol-field equality. No target executions occurred.'],
        'scope': 'Encoding source/linkage and dependency identity only; target has not executed.'}
    OUT.with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    OUT.with_suffix('.md').write_text('# AIR v1 pre-execution build audit\n\nPASS: ten configured translation units match their intended source files. Twelve required mapped symbols belong to their declared objects; original primary closure is unchanged. The private copies contain only the five registered encoder corrections. Three non-system DLLs are pinned through the complete PE import closure; Windows system DLLs remain prerequisites. No target executable or DLL was loaded by this audit.\n\nThe wrapper was aligned with literal registered LICH initialization before the first successful build. No native results existed when this adjustment was made.\n\nBinary SHA-256: `' + result['binary_sha256'] + '`.\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('source_and_linkage_pass', 'native_execution', 'configured_translation_units', 'binary_sha256')}))

if __name__ == '__main__': main()
