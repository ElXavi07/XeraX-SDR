# Independent complete clear NXDN air-frame reference plan

2026-09-25. Planning only: no new corpus, source modification, native encoder invocation, receiver replay, or input generation. The proposed claim is exact agreement on finite complete air-frame bytes, with known control information and voice-word placement. It is not a receiver call, acquisition, audio, radio, timing, or false-acceptance experiment.

## Fixed scope and reusable independent code

Use conventional RDCH outbound only: RFCT=2, direction=1, RAN=1, clear group VCALL source 901 (`0x0385`) and group 1201 (`0x04B1`). This deliberately avoids treating the primary LICH parity implementation as a general oracle for other RFCT values.

The historical `experiments/nxdn_frames/generate_vectors.py` already supplies table-free CRC, convolution, puncturing, interleaving, MSB dibit packing, and PN9 whitening. Its current SHA-256 is `3e2c63b57dba137bbb35cdb9457a17deb9d0363fff8b8117e5d530e5990be9bd`. Reuse those pure functions through a hash-guarded snapshot/import; do not call or generalize its hardcoded `build_frame`, and do not edit the historical file. Its existing CRC-negative flag changes a check bit before convolution; that convention must not be confused with an arbitrary air-bit error. Functions are at lines 48–145.

Likewise, preserve and hash-bind the completed voice-word encoder `experiments/nxdn_voice_words_v1/encoding.py`, SHA-256 `00c8adcc76302e13319e506ee6570d337e5975fca42c11ac32dd5e0eb69354df`. It contains arithmetic Golay/mask/permutation rather than copied primary/receiver tables. Use it to encode only the separately frozen source words; corroborate those 9-byte words against the already published primary channel artifact before assembling frames. A new frame assembler may call these independent arithmetic modules. Its checker must import neither generator.

Primary sources remain the untouched closure under `build/nxdn-voice-v1-primary`, pinned to [MMDVM-Host 590c531391dfd3146073afbc3956f70d42c62a46](https://github.com/g4klx/MMDVM-Host/tree/590c531391dfd3146073afbc3956f70d42c62a46) and [NXDNClients 8950677e9876e577fb87b955cfa93bacd059209d](https://github.com/g4klx/NXDNClients/tree/8950677e9876e577fb87b955cfa93bacd059209d). The native reference must use separately preserved private copies with only preregistered deterministic/bounds corrections below.

## Exact bit and byte construction

All bits are MSB-first. A complete frame is **384 bits = 48 packed bytes = 192 numeric dibits**. The packed-byte and one-dibit-per-byte representations must have distinct file names and dimensions. A dibit is `(first_bit << 1) | second_bit`; no additional Gray conversion is applied. `3131331131` is only the sync sign projection, not the original ten numeric dibits.

| Region | Absolute bit interval, end excluded | Packed bytes |
|---|---|---|
| FSW | 0–20 | first 2.5 bytes |
| LICH | 20–36 | next 2 bytes, crossing byte boundaries |
| SACCH | 36–96 | through byte 11 |
| Traffic half 1 | 96–240 | 12–29 |
| Traffic half 2 | 240–384 | 30–47 |

The FSW is exactly the 20 bits of `0xCDF59`, not all 24 bits of its storage bytes. A full no-steal traffic region contains voice words starting at bits 96, 168, 240, 312 (packed bytes 12, 21, 30, 39). [NXDNDefines.h, lines 24–43](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNDefines.h#L24), [NXDNControl.cpp, lines 959–984](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNControl.cpp#L959).

LICH's logical byte is `(RFCT<<6)|(FCT<<4)|(option<<2)|(direction<<1)|parity`. Emit each of its eight bits followed by a fixed one. For this restricted RDCH family, parity is XOR of the high-nibble bits. The primary's actual rule is parity one for high nibble `0x8` or `0xB`, zero otherwise; the two agree in the chosen family, but not for every possible RFCT/FCT. Non-superframe control uses FCT=0/option=0 and LICH `0x83`; superframe pure voice FCT=2/option=3 gives `0xAE`; first-half FACCH option=1 gives `0xA6`; second-half FACCH option=2 gives `0xAA`. [NXDNLICH.cpp, lines 67–87 and 155–164](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNLICH.cpp#L67), [option constants](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNDefines.h#L45).

For each CRC of width w, start `r=(1<<w)-1`; for each information bit b compute `f=b XOR ((r>>(w-1))&1)`, shift left with a w-bit mask, XOR the polynomial if f=1. Use `(w,poly)=(6,0x27)` or `(12,0x80F)`. Append the w-bit result MSB-first, then four zero termination bits. There are no appended CRC-calculation zeros, reflected bit order, or final XOR. [NXDNCRC.cpp, lines 138–169](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNCRC.cpp#L138).

Convolution starts with four zero history bits for every channel. For each input d, output `d XOR d3 XOR d4`, then `d XOR d1 XOR d2 XOR d4`, before shifting history. SACCH: information `structure[2] || RAN[6] || fragment[18]` gives 26+6+4=36 input bits, 72 convolution bits; delete indices congruent to 5 mod 6 to retain 60; retained bit i is written at `5*(i%12)+i//12`. FACCH1: 80+12+4=96 input bits, 192 convolution bits; delete indices congruent to 1 mod 4 to retain 144; retained bit i is written at `9*(i%16)+i//16`. These writer formulas are inverses of the historical helper's output-index reader formulas. [Convolution lines 128–153](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNConvolution.cpp#L128), [SACCH lines 109–150](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNSACCH.cpp#L109), [FACCH1 lines 116–153](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNFACCH1.cpp#L116).

Finally apply channel whitening once, after assembly: reset nine-bit r=`0xE4` per frame; for numeric dibits 10 through 191 XOR `(r&1)<<1`, then update `r=(r>>1)|(((r^(r>>4))&1)<<8)`. Sync is untouched; LICH is included; only the high bit of each affected dibit changes. Compare the arithmetic mask across the full 48-byte frame with the primary `SCRAMBLER`, and verify whitening twice restores the exact unwhitened frame. This PN9 channel whitening is distinct from the A-seeded voice B mask and from privacy encryption. [NXDNControl.cpp, lines 31–36 and 1071–1077](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNControl.cpp#L31).

## Agreed minimum nine-frame positive grid

Use clear 80-bit VCALL information bytes `01 00 20 03 85 04 B1 00 00 00` and trailer information `08 00 20 03 85 04 B1 00 00 00`, following the pinned conventional header/trailer construction. Header/trailer SACCH is structure0, RAN1, and the first 18 bits of `10 00 00` (IDLE). The 72-bit superframe message is the first nine bytes of that VCALL information; fragment n is exactly bits `[18*n:18*(n+1)]`, while structure is `3-n`. Keep every reserved/cipher/key field explicitly zero. [Voice.cpp header/trailer constants and builders](https://github.com/g4klx/NXDNClients/blob/8950677e9876e577fb87b955cfa93bacd059209d/NXDNGateway/Voice.cpp#L30), [SACCH fragment construction, lines 210–248](https://github.com/g4klx/NXDNClients/blob/8950677e9876e577fb87b955cfa93bacd059209d/NXDNGateway/Voice.cpp#L210).

| ID | LICH | SACCH structure/fragment | Half 1 | Half 2 |
|---|---|---|---|---|
| header | 83 | 0 / IDLE | VCALL FACCH | identical VCALL FACCH |
| voice0 | AE | 3 / 0 | source words 0,1 | source words 2,3 |
| voice1 | AE | 2 / 1 | source words 4,5 | source words 6,7 |
| voice2 | AE | 1 / 2 | source words 8,9 | source words 10,11 |
| voice3 | AE | 0 / 3 | source words 12,13 | source words 14,15 |
| voice4 | AE | 3 / 0 | source words 16,17 | source words 18,19 |
| facch_first | A6 | 2 / 1 | VCALL FACCH | source words 2,3 |
| facch_second | AA | 1 / 2 | source words 4,5 | VCALL FACCH |
| trailer | 83 | 0 / IDLE | TX_REL FACCH | identical TX_REL FACCH |

Totals: 432 packed air bytes, 1,728 numeric dibits, 9 SACCH channels, 6 FACCH1 channels, and 24 transmitted voice words. Source IDs 0–19 are the previously frozen twenty announcement words; the last four transmitted words deliberately repeat source identities 2,3,4,5. Record source ID plus frame/slot separately so repeated words cannot erase lineage. FACCH stealing removes the corresponding two voice slots entirely; no voice bytes from the stolen half remain in the frame.

There is no semantic blocker for this finite frame-byte gate. The second SACCH cycle is intentionally partial: structures3,2,1 are followed by trailer before structure0. That is not evidence for a complete reconstructed second superframe or receiver call lifecycle. No extra waveform, acquisition attempt or voice synthesis belongs in this stage.

## Minimal native-reference corrections to register first

Keep original sources and a mechanically guarded private patch/diff. In FACCH1 encoding, guard `index < 48` before accessing its 48-entry puncture list (or preregister an equivalent terminal192 sentinel, but choose one exact patch). After the last removal at 189, positions190/191 must be retained; the original loop otherwise reads past the array.

Zero-initialize SACCH encode temporaries `temp2[9]`, `temp3[8]` and FACCH1 `temp2[24]`, `temp3[18]`. Each `WRITE_BIT` is read-modify-write, so eventual complete assignment does not justify reading an uninitialized byte. Initialize the complete 48-byte output frame before sync/channel calls. Initialize LICH storage with `setRaw(0)` before field setters and SACCH with an explicit zero raw four-byte buffer before setters, or register equivalent constructor zero-initialization. FACCH setters must receive fully defined payload bytes. No algorithm, CRC, interleaver, field placement or result-dependent adjustment should accompany those fixes. Root's preregistration must settle the exact private patch before any frame/reference generation.

## Construction-level falsifiers

Freeze independent unwhitened/whitened bytes, numeric dibits, channel stage metadata, selected original voice-source IDs and all source/compiler/checker hashes before the one registered reference batch. Compare every one of 384 bits per frame and exact frame order/count; also compare unwhitened regions, not only final hashes. Bind every primary-used control buffer to its intended 26/80 information bits. Verify retained voice bytes independently against the published agreed channel artifact.

Checker counterexamples should independently corrupt a sync bit, LICH parity bit, LICH fixed spacer bit, a SACCH channel bit, each FACCH region, one voice bit, an option label, source ID/slot, and whitening domain/seed; swap first/second traffic halves, reorder/drop/duplicate a frame, and truncate/append a byte. Each must fail the relevant exact-reference or identity gate. Same-length corruption and rehashed metadata must not defeat source reconstruction. Reversing the puncture residue or writer/reader permutation, dropping a tail bit, reversing CRC bit order, or packing the two 49-bit words on byte boundaries are meaningful arithmetic counterexamples.

These are byte-agreement/checker negatives, not signal false-acceptance controls. A single changed encoded bit can be corrected by a receiver and must not be labeled a guaranteed CRC failure. Likewise an intentionally wrong pre-FEC check bit is a different construction from a random air-bit change. The primary channel encoders recompute CRC/parity, so supplying a wrong raw check field alone does not make a negative reference frame. No decoder rejection, speaker output, or future receiver threshold should enter this gate.
