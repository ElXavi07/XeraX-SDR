# Clear conventional NXDN air-frame reference: independent primary-source plan

2026-09-25. Static preparation only. No encoder/receiver was built or invoked, no frame vectors were generated, and no primary or production source was edited in this review. The nine-frame contract below follows the draft `docs/research/NXDN-AIR-V1-PREREGISTRATION-2026-09-25.md`; it is a proposed reference-byte study, not a receiver or audio result.

## Source identity and scope

The cache is `build/nxdn-voice-v1-primary`. Its manifest SHA-256 is `e5dda2c6b072ca4eda65d2c75c3f16550a6cafb52c8fd8e04f34c47363a24ca1`. I independently rechecked all 36 original cached files (335,052 bytes) against the manifest SHA-256 values and Git blob identities. This is additional static verification of the earlier `build/nxdn-voice-v1-primary-review.md`, not reliance on its conclusions alone.

* MMDVM-Host commit `590c531391dfd3146073afbc3956f70d42c62a46`, tree `a120f8d418303fba97e75a8e1e07da4092a121a0`.
* NXDNClients commit `8950677e9876e577fb87b955cfa93bacd059209d`, tree `83951101b5aff8e16d67a28fd1d1ac0528515d69`.
* The prior 130-byte linked announcement slice supplies twenty ordered 49-bit words. It is network voice-word material, not complex I/Q, an air capture, or independent proof of intelligible synthesized speech.

Primary references are the pinned [host assembly and whitening](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNControl.cpp), [definitions](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNDefines.h), [LICH encoder](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNLICH.cpp), [SACCH encoder](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNSACCH.cpp), [FACCH1 encoder](https://github.com/g4klx/MMDVM-Host/blob/590c531391dfd3146073afbc3956f70d42c62a46/NXDNFACCH1.cpp), and [gateway control/voice source](https://github.com/g4klx/NXDNClients/blob/8950677e9876e577fb87b955cfa93bacd059209d/NXDNGateway/Voice.cpp). Agreement with these implementations would not establish compliance with every NXDN variant or an independently licensed standard specification.

## Minimal standalone dependency closure

Compile eight separate primary translation units: `NXDNLICH.cpp`, `NXDNSACCH.cpp`, `NXDNFACCH1.cpp`, `NXDNConvolution.cpp`, `NXDNCRC.cpp`, `NXDNAudio.cpp`, `Golay24128.cpp`, and `Sync.cpp`. Compile corrected audit copies of only SACCH/FACCH1 as described below; retain all originals.

Required cached headers are `NXDNLICH.h`, `NXDNSACCH.h`, `NXDNFACCH1.h`, `NXDNConvolution.h`, `NXDNCRC.h`, `NXDNAudio.h`, `Golay24128.h`, `Sync.h`, `NXDNDefines.h`, `Defines.h`, `Utils.h`, `DStarDefines.h`, `DMRDefines.h`, `YSFDefines.h`, and `P25Defines.h`. `Sync.cpp` includes the other-mode definition headers even though the wrapper calls only `addNXDNSync`. Preserve the exact, attributed `CUtils::countBits` body from `Utils.cpp` using the support file already frozen in the voice-word stage. No mbelib, host application, network service, primary decoder, or fake codec is required. `NXDNControl.cpp` is a reference for layout and the whitening constant, not a translation unit in this target. `NXDNLayer3` is unnecessary when the exact control bytes are supplied. Keep separate translation units rather than amalgamating repeated file-local table identifiers. Do not add a conflicting command-line `USE_NXDN` definition over the original `Defines.h` definition.

The final build should retain actual compile commands, linkage maps, original/audit-copy hashes and their exact diff, compiler identity and runtime dependency closure. This plan does not assert a build has succeeded.

## Five narrowly required oracle-copy corrections

1. `CNXDNFACCH1::encode` has 48 puncture entries ending at 189 but loops through coded indices 190 and 191 after `index` becomes 48. A static index walk confirms the two out-of-bounds accesses. Replace its single encoding-path condition with `index >= 48U || i != PUNCTURE_LIST[index]`. The remaining two coded bits are transmitted. Do not patch similarly named decoder code or unrelated primary files.
2. Zero-initialize SACCH encoding `temp2[9U]`.
3. Zero-initialize SACCH encoding `temp3[8U]`.
4. Zero-initialize FACCH1 encoding `temp2[24U]`.
5. Zero-initialize FACCH1 encoding `temp3[18U]`.

The last four changes avoid indeterminate-byte reads in the `WRITE_BIT1` read/modify/write macro. Eventual assignment of each consumed bit does not justify the preceding byte reads. Existing `temp1` arrays are already cleared. The SACCH puncture list ends at 71 and its loop ends at 72, so it does not have FACCH's final-list-access defect. Require exact declaration/condition replacement counts and preserve the five-edit diff before execution. General background on indeterminate values is in the [current C++ working draft](https://eel.is/c++draft/basic.indet); this link is not presented as the historical C++17 normative text.

Wrapper frame, pair, and scratch arrays must also start at zero. `CNXDNLICH` constructor allocates an uninitialized byte; call `setRaw` before encoding. `setRaw` assigns the byte, while `encode`/`getRaw` computes the parity bit. `CNXDNSACCH::setRaw` supplies its four used bytes; encode reads its first 26 information bits and creates its own CRC. Do not copy or inspect the unused fifth storage byte. `setRAN` does not mask its argument, so reject any out-of-range RAN. `CNXDNFACCH1::setData` supplies exactly 80 information bits; encode builds its own CRC and zero tail. Avoid a precomputed network CRC as oracle input.

## Frame layout and exact information

A frame is 48 bytes: 20 FSW bits, 16 transmitted LICH bits, 60 SACCH bits, then two 144-bit halves. FSW is `0xCDF59`; the primary sync function masks the first three bytes with `FF FF F0`. LICH starts at bit 20 and emits each of eight stored bits as `[bit, 1]`. SACCH starts at bit 36. The two payload halves start at bits 96 and 240, or bytes 12 and 30. A pure-voice half carries two 72-bit channel words, at bytes 12/21 or 30/39.

Primary outbound RDCH full LICH values are `83` for non-superframe repeated FACCH control, `AE` for pure superframe voice, `A6` for first-half FACCH, and `AA` for second-half FACCH. The corresponding inbound values are `81`, `AC`, `A4`, and `A8`, but inbound is outside this proposed nine-frame test. The primary parity function is a limited high-nibble rule (`80`/`B0` set parity), not generic parity across all eight bits; test only the registered profiles.

Use source 901 (`0385`), destination group 1201 (`04B1`), RAN 1. The gateway's initialized header/trailer templates and identifier assignments give VCALL information `01 00 20 03 85 04 B1 00 00 00`; TX_REL changes the first byte to `08`. Each full-control frame repeats that same 80-bit information in both separately encoded FACCH channels. These bytes explicitly contain no privacy/key material.

The first 72 VCALL information bits divide into four MSB-first 18-bit SACCH fragments. Structures descend `3,2,1,0`; a fifth pure-voice frame begins the next cycle with structure 3. Header/trailer use single structure 0 and the first 18 bits of `SACCH_IDLE` (`10 00 00`). The four raw SACCH input bytes contain structure 2 bits, RAN 6 bits, information 18 bits, and six zero padding bits; those last six are not an externally supplied CRC.

SACCH encodes 26 information bits, CRC6 initialized `3F` with polynomial `27`, and four zero tail bits through the K=5 encoder. Of 72 coded bits, remove indices `5+6k`, producing 60; interleave position is `(i % 12)*5 + floor(i/12)`. FACCH encodes 80 information bits, CRC12 initialized `FFF` with polynomial `80F`, and four zero tail bits; remove indices `1+4k` from 192 coded bits to obtain 144, interleaving at `(i % 16)*9 + floor(i/16)`. The primary convolution output generators are `d+d3+d4`, then `d+d1+d2+d4`, with zero initial delay elements. The independent arithmetic side must establish these values independently of receiver tables/output.

The primary gateway's 33-byte network record is not an air frame. Its two voice-pair payloads begin at offsets 5 and 19. Each 13-byte pair contains two MSB-first 49-bit words followed by six unused bits; normalize these padding bits to zero as in the previous registered voice-word study.

## Fixed nine-frame contract

`primary_encoder input41stream output96stream` should admit only nine complete records, with input size 369 bytes. Record index is positional; preserve names and source IDs separately in immutable metadata.

| Input byte offsets | Content |
|---|---|
| 0 | Registered full LICH byte |
| 1–4 | Four raw SACCH bytes, 26 information bits plus six zero padding bits |
| 5–14 | Ten FACCH information bytes |
| 15–27 | First normalized 13-byte voice pair |
| 28–40 | Second normalized 13-byte voice pair |

| Record | LICH | Structure / fragment | Source quartet | Actually transmitted voice |
|---:|---|---|---|---|
| 0 | 83 | 0 / IDLE | zero placeholders | none; duplicated VCALL FACCH |
| 1 | AE | 3 / 0 | 0,1,2,3 | 0,1,2,3 |
| 2 | AE | 2 / 1 | 4,5,6,7 | 4,5,6,7 |
| 3 | AE | 1 / 2 | 8,9,10,11 | 8,9,10,11 |
| 4 | AE | 0 / 3 | 12,13,14,15 | 12,13,14,15 |
| 5 | AE | 3 / 0 | 16,17,18,19 | 16,17,18,19 |
| 6 | A6 | 2 / 1 | 0,1,2,3 | 2,3; VCALL FACCH in first half |
| 7 | AA | 1 / 2 | 4,5,6,7 | 4,5; VCALL FACCH in second half |
| 8 | 83 | 0 / IDLE | zero placeholders | none; duplicated TX_REL FACCH |

All numbers in the LICH column are hexadecimal. Pure-voice FACCH fields are zero placeholders; header/trailer voice pairs are zero placeholders. Half-steal records still carry their specified complete source quartet in the input, but only the correct unstolen pair is encoded/transmitted. Thus the body reference contains 24 transmitted words, with deliberate reuse after the twenty-word run. It is not an unmodified complete announcement. The second SACCH cycle is deliberately incomplete at the trailer. Neither semantic call acceptance nor complete second-message reconstruction is claimed.

Validate exact length, per-record LICH, RAN/structure and fragment, control information and placeholders, normalized pair padding, and source-pair identity against frozen metadata before any output. Emit exactly raw48 then whitened48 for each frame, 864 bytes total. Refuse existing output, retain any partial failed output, and check open/read/write/flush/close results. Compact JSON must report 9 frames, 369 input bytes, 864 output bytes, 9 SACCH calls, 6 FACCH calls, and 12 actual voice-pair calls. This is one fixed native batch after registration, input/source/binary/checker freeze, and independent preflight.

## Whitening and falsification

Use the original 48-byte XOR constant from the pinned host `NXDNControl.cpp`, copied into an attributed generated header, reset for every frame. Preserve and hash that extraction. The independent arithmetic builder must use its registered recurrence rather than read this host table. The first 20 mask bits are zero, preserving sync. Do not infer a starting symbol merely from the first three zero mask bytes. Whitening is a channel operation, not traffic encryption.

The reference gate requires all 864 raw/air bytes to agree and every known voice word to occupy its declared interval. Existing voice-word channel reference SHA-256 `05ed6f2d7c548e6b6e94e81bb12534afde0c2e13301791a8f1d4d2778dd6eed3` remains unchanged. Check missing/extra/reordered records, altered raw/air bytes, missing/double/misplaced whitening, swapped half-steal payloads, corrupted source identity metadata, and malformed summaries using checker counterexamples. These are evidence-integrity controls, not native malformed-frame or RF false-acceptance results. No alternative corpus or favorable subset after observing results.

## Licensing, preservation, and limits

Retain both original `LICENCE` files (SHA-256 `e6d6a009505e345fe949e1310334fcb0747f28dae2856759de102ab66b722cb4`) and all file notices alongside corresponding originals, five-edit source copies, support body, whitening extraction, wrapper/build code, and manifests. Most primary file headers are GPL-2.0-or-later; `Utils.cpp`/`Utils.h` use GPL version 2 text, and the Golay source includes its original Robert H. Morelos-Zaragoza attribution. Do not erase or replace these with a blanket new license. Repository license evidence alone does not independently establish recording rights, codec patent status, or standards certification.

No material inconsistency was found in the draft nine-frame registration. The five oracle-copy corrections and initialized wrapper state are prerequisites. Success would provide independent whole-frame construction agreement for these exact clear outbound cases. Inbound, other RANs/profiles, trunking, impaired RF, acquisition, full-engine routing, vocoder synthesis, PCM/playback, intelligibility, and speed remain outside scope. Prior rejected recovery results and existing release artifacts must remain untouched.
