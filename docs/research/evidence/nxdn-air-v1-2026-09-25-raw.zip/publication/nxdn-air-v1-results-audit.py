"""Read-only independent AIR v1 result audit; no encoder/checker imports or native replay."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent.parent
RUN = ROOT / "build/nxdn-air-v1-run-20260925"
COMMIT = "d9121a93c44e0cdf6533497b056490614a8fa4fc"
INPUT_MANIFEST = "17061018477b6451207758d6e0390b3ef623e88099f565bfc3416f1168127067"
PRIMARY_MANIFEST = "e5dda2c6b072ca4eda65d2c75c3f16550a6cafb52c8fd8e04f34c47363a24ca1"
CHANNEL_SHA = "05ed6f2d7c548e6b6e94e81bb12534afde0c2e13301791a8f1d4d2778dd6eed3"
SOURCE_SHA = "8f4116e67a4c950a524c8568caf17d550e9b0b0bbdac3f9e3761ce76c0056e41"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def bits(raw):
    return "".join(f"{value:08b}" for value in raw)


def read_json(path):
    return json.loads(Path(path).read_bytes())


def main():
    errors = []
    checks = 0

    def check(ok, message):
        nonlocal checks
        checks += 1
        if not ok:
            errors.append(message)

    before_raw = (RUN / "before-execution.json").read_bytes()
    report_raw = (RUN / "report.json").read_bytes()
    before = json.loads(before_raw)
    report = json.loads(report_raw)
    check(before["commit"] == COMMIT, "registered harness commit")
    check(report["attempts"] == [{"stage": "primary", "exit_code": 0}], "one recorded successful attempt")
    check(read_json(RUN / "primary/process.json") == {"exit_code": 0}, "native exit evidence")
    invocation = read_json(RUN / "primary/invocation.json")
    expected_arguments = [str(RUN / "frozen/xerax_air_primary.exe"),
                          str(RUN / "inputs/input.records41"), str(RUN / "primary/frames.records96")]
    check([str(Path(p).resolve()) for p in invocation["arguments"]] == expected_arguments,
          "recorded command uses frozen binary and inputs")
    check(invocation["timeout_seconds"] == 60 and invocation["dsd_environment_removed"] is True,
          "invocation bounds/environment declaration")
    check(len(list(RUN.rglob("invocation.json"))) == 1 and len(list(RUN.rglob("process.json"))) == 1,
          "recorded process inventory")
    check((RUN / "primary/stderr.txt").read_bytes() == b"", "unexpected primary stderr")
    summary = read_json(RUN / "primary/stdout.json")
    expected_summary = {"schema": 1, "kind": "nxdn_air_primary", "frames": 9,
                        "input_bytes": 369, "output_bytes": 864, "sacch_calls": 9,
                        "facch_calls": 6, "voice_pair_calls": 12}
    check(summary == expected_summary and all(type(summary[k]) is type(v) for k, v in expected_summary.items()),
          "actual native summary/counts")

    inputdir = RUN / "inputs"
    manifest_bytes = (inputdir / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    check(digest(manifest_bytes) == INPUT_MANIFEST, "registered input manifest identity")
    for name, entry in manifest["files"].items():
        raw = (inputdir / name).read_bytes()
        check(len(raw) == entry["bytes"] and digest(raw) == entry["sha256"], "input identity " + name)

    original = RUN / "frozen/primary/originals"
    primary_bytes = (original / "manifest.json").read_bytes()
    primary = json.loads(primary_bytes)
    check(digest(primary_bytes) == PRIMARY_MANIFEST, "pinned primary manifest")
    for entry in primary["files"]:
        raw = (original / entry["path"]).read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()
        check(digest(raw) == entry["sha256"] and len(raw) == entry["bytes"] and blob == entry["git_blob_sha1"],
              "original primary identity " + entry["path"])
    asset = (original / "NXDNClients/NXDNGateway/Audio/en_GB.nxdn").read_bytes()
    source = asset[8476:8606]
    check(digest(source) == SOURCE_SHA and source == (inputdir / "linked-source.bin").read_bytes(),
          "original announcement interval")
    source_words = [bits(source[i:i + 13])[offset:offset + 49]
                    for i in range(0, 130, 13) for offset in (0, 49)]
    check(len(source_words) == 20 and all(len(word) == 49 for word in source_words), "source word dimensions")

    control = (original / "MMDVM-Host/NXDNControl.cpp").read_bytes()
    declarations = re.findall(rb"const unsigned char SCRAMBLER\[\] = \{([^}]+)\};", control)
    check(len(declarations) == 1, "unique pinned whitening declaration")
    mask = bytes(int(value, 16) for value in re.findall(rb"0x([0-9A-Fa-f]{2})U", declarations[0]))
    check(len(mask) == 48 and bits(mask)[:20] == "0" * 20, "whitening mask dimensions/sync")
    channels = (inputdir / "voice-reference.channels9").read_bytes()
    check(len(channels) == 74394 and digest(channels) == CHANNEL_SHA, "earlier agreed voice-channel reference")

    actual = (RUN / "primary/frames.records96").read_bytes()
    expected = (inputdir / "expected.records96").read_bytes()
    inputbytes = (inputdir / "input.records41").read_bytes()
    check(len(actual) == 864 and actual == expected, "all 864 raw/air bytes agree")
    check(len(inputbytes) == 369, "input record dimensions")
    check(b"".join(actual[i:i + 48] for i in range(0, 864, 96)) == (inputdir / "expected.raw48").read_bytes(),
          "all nine raw frames agree")
    check(b"".join(actual[i + 48:i + 96] for i in range(0, 864, 96)) == (inputdir / "expected.air48").read_bytes(),
          "all nine air frames agree")

    vcall = bytes.fromhex("01 00 20 03 85 04 b1 00 00 00")
    trailer = bytes.fromhex("08 00 20 03 85 04 b1 00 00 00")
    grid = [("header", 0x83, 0, None, [], vcall)]
    grid += [("voice" + str(i), 0xAE, 3 - i % 4, i % 4, list(range(i * 4, i * 4 + 4)), bytes(10))
             for i in range(5)]
    grid += [("facch_first", 0xA6, 2, 1, [0, 1, 2, 3], vcall),
             ("facch_second", 0xAA, 1, 2, [4, 5, 6, 7], vcall),
             ("trailer", 0x83, 0, None, [], trailer)]
    metadata = read_json(inputdir / "frames.json")
    frames = []
    word_intervals = 0
    facch_intervals = []
    for i, (name, lich, structure, fragment, quartet, facch) in enumerate(grid):
        fragment_bits = ("00010000" + "0" * 10 if fragment is None
                         else bits(vcall[:9])[fragment * 18:(fragment + 1) * 18])
        information = f"{structure:02b}" + "000001" + fragment_bits
        sacch = int(information + "000000", 2).to_bytes(4, "big")
        voice = bytes(26)
        if quartet:
            voice = b"".join(int(source_words[quartet[j]] + source_words[quartet[j + 1]] + "000000", 2)
                             .to_bytes(13, "big") for j in (0, 2))
        record = bytes([lich]) + sacch + facch + voice
        check(inputbytes[i * 41:(i + 1) * 41] == record, f"source/LICH/control/packing frame {i}")
        raw = actual[i * 96:i * 96 + 48]
        air = actual[i * 96 + 48:(i + 1) * 96]
        raw_bits = bits(raw)
        check(raw_bits[:20] == f"{0xCDF59:020b}", f"primary FSW frame {i}")
        check(raw_bits[20:36:2] == f"{lich:08b}" and raw_bits[21:36:2] == "1" * 8,
              f"primary LICH/spacers frame {i}")
        check(bytes(a ^ b for a, b in zip(raw, air)) == mask, f"exact raw/air mask frame {i}")
        slots = [] if not quartet else [2, 3] if lich == 0xA6 else [0, 1] if lich == 0xAA else [0, 1, 2, 3]
        transmitted = [{"slot": slot, "source_id": quartet[slot]} for slot in slots]
        for item in transmitted:
            slot, word = item["slot"], item["source_id"]
            check(raw[12 + slot * 9:21 + slot * 9] == channels[word * 9:(word + 1) * 9],
                  f"known voice frame {i}, slot {slot}, source word {word}")
            word_intervals += 1
        if not quartet or lich == 0xA6:
            facch_intervals.append({"frame": i, "half": 0, "sha256": digest(raw[12:30])})
        if not quartet or lich == 0xAA:
            facch_intervals.append({"frame": i, "half": 1, "sha256": digest(raw[30:48])})
        expected_meta = {"id": i, "name": name, "lich": lich, "structure": structure,
                         "fragment": fragment, "source_quartet": quartet, "transmitted_voice": transmitted,
                         "sacch_information": information, "facch_information": facch.hex(),
                         "record_sha256": digest(record), "raw_sha256": digest(raw), "air_sha256": digest(air)}
        check(metadata[i] == expected_meta, f"independent frame metadata {i}")
        frames.append(expected_meta)
    check(word_intervals == 24 and len(facch_intervals) == 6, "transmitted interval totals")
    check(len({v["sha256"] for v in facch_intervals if v["frame"] != 8}) == 1,
          "four repeated VCALL FACCH intervals")
    check(len({v["sha256"] for v in facch_intervals if v["frame"] == 8}) == 1,
          "two repeated trailer FACCH intervals")

    content_errors = list(errors)
    groups = {}
    for group in ("original_files", "frozen_files", "copied_identities", "configured_sources", "protected"):
        mismatches = []
        for name, wanted in before[group].items():
            path = Path(name)
            got = file_digest(path) if path.is_file() else None
            if got != wanted:
                mismatches.append({"path": name, "expected": wanted, "actual": got})
        groups[group] = {"entries": len(before[group]), "mismatches": mismatches, "pass": not mismatches}
        check(not mismatches, "preservation group " + group)
    report_files = {name.replace("\\", "/"): value for name, value in report["files"].items()}
    actual_inventory = {p.relative_to(RUN).as_posix() for p in RUN.rglob("*")
                        if p.is_file() and p != RUN / "report.json"}
    check(set(report_files) == actual_inventory, "exact final report file inventory")
    for name, wanted in report_files.items():
        check(file_digest(RUN / name) == wanted, "final report artifact " + name)

    frozen_repo = RUN / "frozen/source_repository"
    git_sources = {}
    for p in sorted(frozen_repo.rglob("*")):
        if p.is_file():
            name = p.relative_to(frozen_repo).as_posix()
            recorded = subprocess.check_output(["git", "show", COMMIT + ":" + name], cwd=ROOT)
            actual_source = p.read_bytes()
            check(recorded == actual_source, "committed frozen source " + name)
            git_sources[name] = digest(actual_source)
    registration = "docs/research/NXDN-AIR-V1-PREREGISTRATION-2026-09-25.md"
    committed_registration = subprocess.check_output(["git", "show", COMMIT + ":" + registration], cwd=ROOT)
    check(committed_registration == (RUN / "frozen" / Path(registration).name).read_bytes(),
          "committed frozen preregistration")
    for flag in ("measurement_pass", "progression_pass", "preservation_pass"):
        check(report.get(flag) is True, "reported aggregate " + flag)
    check(report.get("product_promotion") is False, "no product promotion")
    check(report["content"]["counts"]["different_bytes"] == 0
          and report["content"]["counts"]["known_voice_intervals"] == word_intervals,
          "report content counts agree with independent observation")

    # The final outer shell log is not an input to the native/reference gate.
    # Inspect its actual inventory membership; do not invent or excuse a drift.
    outer_log = ROOT / "build/nxdn-air-v1-execution.log"
    outer_membership = {group: [name for name in before[group] if Path(name) == outer_log]
                        for group in groups}
    outer = {"path": str(outer_log), "bytes": outer_log.stat().st_size if outer_log.exists() else None,
             "sha256": file_digest(outer_log) if outer_log.exists() else None,
             "before_group_membership": outer_membership,
             "frozen_copy_exists": (RUN / "frozen/nxdn-air-v1-execution.log").exists(),
             "scope": "Final outer stdout log is outside the recorded freeze inventories; its creation timing was not independently observed. No preservation exception is granted."}
    final = {
        "schema": 1, "kind": "independent_nxdn_air_v1_results_audit", "date": "2026-09-25",
        "audit_pass": not errors, "independent_audit_pass": not errors,
        "independent_content_pass": not content_errors,
        "declared_preservation_groups_pass": all(value["pass"] for value in groups.values()),
        "errors": errors, "checks": checks,
        "scope": "Exact clear conventional outbound air-frame reference construction only",
        "native_rerun": False, "encoder_generator_checker_imports": False,
        "audit_script_sha256": file_digest(Path(__file__)), "harness_commit": COMMIT,
        "report_sha256": digest(report_raw), "before_execution_sha256": digest(before_raw),
        "input_manifest_sha256": digest(manifest_bytes), "primary_output_sha256": digest(actual),
        "expected_output_sha256": digest(expected), "byte_exact_agreement": actual == expected,
        "raw_bytes": 432, "air_bytes": 432, "total_output_bytes": len(actual),
        "whitening_frames": 9, "whitening_mask_sha256": digest(mask),
        "known_source_words": 20, "transmitted_voice_intervals": word_intervals,
        "actual_summary": summary, "recorded_attempts": report["attempts"],
        "frames": frames, "facch_intervals": facch_intervals,
        "preservation_groups": groups, "report_artifact_count": len(report_files),
        "committed_source_files": git_sources, "original_primary_git_blobs_checked": len(primary["files"]),
        "outer_log_inventory_observation": outer,
        "limits": ["The supplied six FACCH and nine SACCH channel outputs agree with the frozen independent reference; this audit does not decode them through a receiver.",
                   "Only these registered nine frames, four outbound LICH profiles, one RAN and fixed IDs were measured.",
                   "The sequence carries 24 transmitted word intervals from 20 known source words; the second SACCH cycle is incomplete.",
                   "No synthesis, intelligibility, PCM/playback, I/Q, RF, synchronization, speed, encryption or product improvement is established.",
                   "One native attempt is evidenced in the run inventory; this audit does not claim global process surveillance.",
                   "Hash groups overlap and their entry counts must not be summed as distinct files."]}
    output = Path(__file__).with_suffix(".json")
    with output.open("x", encoding="utf-8") as stream:
        json.dump(final, stream, indent=2)
        stream.write("\n")
    md = Path(__file__).with_suffix(".md")
    lines = ["# Independent NXDN AIR v1 result audit", "",
             "The independent audit " + ("passes" if not errors else "fails") + ". No native process was rerun, no generator/checker module imported, and no frozen input, source or result was modified.", "",
             f"The recorded single native attempt exited zero. All {len(actual)} output bytes agree with the frozen independent reference: nine raw48/air48 records, 432 bytes in each domain. Output SHA-256 is `{digest(actual)}`.", "",
             "Information records were reconstructed directly from the original pinned announcement interval and fixed registered fields. All twenty original words, both repeated half-steal quartets, source/group IDs, RAN, SACCH fragments, zero placeholders and padding agree. All nine FSW/LICH layouts and exact whitening masks agree; all 24 transmitted voice-word intervals match the previously agreed channel words. Native summary counters are 9 SACCH, 6 FACCH and 12 voice-pair calls. The four VCALL FACCH intervals match each other, as do both trailer intervals.", "",
             "Every declared preservation group matches without exception: " + ", ".join(f"{name} {value['entries']}" for name, value in groups.items()) + f". All {len(report_files)} final report artifacts match their hashes and the exact inventory. {len(git_sources)} frozen source files and the preregistration match Git commit `{COMMIT}`; all 36 original primary Git blobs also match. These categories overlap.", "",
             "The final outer `nxdn-air-v1-execution.log` is absent from every before-execution hash group and has no frozen copy. It is outside the declared freeze inventory; its creation timing was not independently observed. There is no actual hash mismatch to waive, and no gate was relaxed.", "",
             f"The immutable within-run report SHA-256 is `{digest(report_raw)}`. Its measurement, progression and preservation flags agree with this audit; product promotion remains false.", "",
             "This is reference construction for nine fixed clear outbound frames. The 24 transmitted word intervals reuse 20 source words, and the second SACCH cycle is incomplete. It establishes no receiver acquisition, semantic call acceptance, speech synthesis, playback, RF robustness, decoding speed, privacy capability or APK/EXE improvement.", ""]
    if errors:
        lines += ["## Failures", ""] + ["- " + error for error in errors]
    with md.open("x", encoding="utf-8") as stream:
        stream.write("\n".join(lines) + "\n")
    print(json.dumps({"independent_audit_pass": not errors, "checks": checks, "errors": errors,
                      "summary": summary, "preservation_counts": {k: v["entries"] for k, v in groups.items()},
                      "report_files": len(report_files), "source_files": len(git_sources),
                      "report_sha256": digest(report_raw), "output_sha256": digest(actual)}))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
