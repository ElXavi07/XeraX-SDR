"""Archive the one completed reference execution; never run native code."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
study = root / 'build/nxdn-air-v1-run-20260925'
destination = root / 'docs/research/evidence'
stem = 'nxdn-air-v1-2026-09-25'
archive = destination / (stem + '-raw.zip')
index = destination / (stem + '.json')
sha = lambda b: hashlib.sha256(b).hexdigest()
def need(value, message):
    if not value: raise ValueError(message)

need(not archive.exists() and not index.exists(), 'Publication already exists')
report_raw = (study / 'report.json').read_bytes()
need(sha(report_raw) == '867264df1b1f05eaa5db49d30e7287def90c3a32ebb3d9dcd47a0e2feb296f6f', 'Native report changed')
report = json.loads(report_raw)
audit_path = root / 'build/nxdn-air-v1-results-audit.json'
audit_raw = audit_path.read_bytes(); audit = json.loads(audit_raw)
need(sha(audit_raw) == 'aec496ed707511b740810d4ba3281d48ef81eea3993582866e778decd040efd5', 'Independent audit identity changed')
need(audit['audit_pass'] and report['progression_pass'] and report['preservation_pass'] and not report['product_promotion'], 'Audit/result gate failed')
for name, digest in report['files'].items():
    need(sha(study.joinpath(*name.replace('\\', '/').split('/')).read_bytes()) == digest, 'Changed raw file: ' + name)
ci = {}
for event, number in (('push', 36186286076), ('pr', 36186294530)):
    data = json.loads((root / f'build/nxdn-air-v1-ci-{event}-status.json').read_bytes())
    need(data['databaseId'] == number and data['headSha'] == 'd9121a93c44e0cdf6533497b056490614a8fa4fc', 'CI identity differs')
    need(data['status'] == 'completed' and data['conclusion'] == 'success', 'CI not passed')
    need(len(data['jobs']) == 2 and all(j['conclusion'] == 'success' for j in data['jobs']), 'CI matrix incomplete')
    ci[event] = number

payload = {'study/' + p.relative_to(study).as_posix(): p.read_bytes() for p in sorted(study.rglob('*')) if p.is_file()}
extras = [root / 'build' / ('nxdn-air-v1-results-audit.' + ext) for ext in ('py', 'json', 'md')]
extras += [root / 'build' / ('nxdn-air-v1-' + name) for name in ('ci-push.log', 'ci-pr.log', 'ci-push-status.json', 'ci-pr-status.json', 'execution.log')]
extras += [root / 'build/nxdn-voice-words-v1-preflight-audit.py', Path(__file__)]
extras += [root / '.github/workflows/nxdn-air-framework.yml']
for p in extras: payload['publication/' + p.name] = p.read_bytes()
payload['README.txt'] = (
    'XeraX independent NXDN complete-frame reference, AIR v1\n'
    'Registration fdb90ec; frozen harness d9121a93c44e0cdf6533497b056490614a8fa4fc.\n'
    'One primary native process, nine frames, 864 bytes, 24 known voice intervals.\n'
    'This archive is research evidence, not a new app build or receiver result.\n\n'
    'study/ preserves the whole registered attempt and its before-execution identities.\n'
    'frozen/primary retains originals, licenses, minimal private source diffs and metadata.\n'
    'frozen/source_repository preserves the hierarchy needed by independent checkers.\n'
    'The research EXE and runtime DLLs are frozen tools, not an installer. Compiler tools\n'
    'are hashed but not redistributed; Windows system libraries remain prerequisites.\n'
    'publication/ contains separate raw-result audits, CI logs and the final outer-runner\n'
    'summary. That final log is outside the recorded pre-execution inventory.\n'
    'The older preflight audit source is included because the new build audit extracts\n'
    'its read-only PE/map parser functions (with an explicitly retained symbol fix).\n\n'
    'Offline content check, without native execution: import analyze from\n'
    'study/frozen/source_repository/experiments/nxdn_air_v1 and call inspect_output with\n'
    'Path arguments for study/inputs, study/primary/frames.records96 and\n'
    'study/primary/stdout.json. Keep the entire frozen source hierarchy intact.\n'
    'Original absolute identities describe the study machine; relocations do not\n'
    'rewrite them. Windows-relative file names in JSON use backslashes.\n\n'
    'No acquisition, receiver routing, synthesis, listening, RF, I/Q, speed, privacy-key,\n'
    'GPU or APK/Windows improvement is claimed. Downstream work requires registration.\n'
).encode('utf-8')
manifest = {'schema': 1, 'kind': 'nxdn_air_v1_archive', 'native_execution': False,
            'files': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(payload.items())}}
payload['archive-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(payload.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 9, 25, 0, 0, 0))
        z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as z:
    need(len(z.namelist()) == len(payload) and set(z.namelist()) == set(payload), 'Archive inventory changed')
    need(z.testzip() is None and all(z.read(name) == raw for name, raw in payload.items()), 'Archive content mismatch')
publication = {'schema': 1, 'kind': 'nxdn_air_v1', 'registration_commit': 'fdb90ec529c0fbe1fbfae0dba4cb5084d9d53e3b',
    'harness_commit': 'd9121a93c44e0cdf6533497b056490614a8fa4fc', 'receiver_baseline': '85bec0a62bb21f5f1bec75d6da9c65820462b39c',
    'measurement_pass': True, 'progression_pass': True, 'product_promotion': False,
    'native_attempts': report['attempts'], 'content': report['content']['counts'],
    'report_sha256': sha(report_raw), 'independent_audit_sha256': sha(audit_raw),
    'ci': {'tests': 53, 'modes': ['normal', 'optimized'], 'platforms': ['Windows', 'Linux'], **ci, 'native_matrix_in_ci': False},
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size, 'entries': len(payload), 'sha256': sha(archive.read_bytes()), 'every_entry_verified': True},
    'limits': ['finite nine-frame construction reference only', 'no receiver or semantic call acceptance',
               'no synthesis, playback, I/Q, RF or timing measurements', 'no privacy or key recovery',
               'released Android/Windows packages and defaults unchanged']}
index.write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
print(json.dumps(publication['archive']))
