# Independent NXDN AIR v1 result audit

The independent audit passes. No native process was rerun, no generator/checker module imported, and no frozen input, source or result was modified.

The recorded single native attempt exited zero. All 864 output bytes agree with the frozen independent reference: nine raw48/air48 records, 432 bytes in each domain. Output SHA-256 is `bedb3ae824c357e68e8d2883b808b357e228e74c7ce253acf0a41cf257234c0b`.

Information records were reconstructed directly from the original pinned announcement interval and fixed registered fields. All twenty original words, both repeated half-steal quartets, source/group IDs, RAN, SACCH fragments, zero placeholders and padding agree. All nine FSW/LICH layouts and exact whitening masks agree; all 24 transmitted voice-word intervals match the previously agreed channel words. Native summary counters are 9 SACCH, 6 FACCH and 12 voice-pair calls. The four VCALL FACCH intervals match each other, as do both trailer intervals.

Every declared preservation group matches without exception: original_files 108, frozen_files 104, copied_identities 99, configured_sources 10, protected 44. All 110 final report artifacts match their hashes and the exact inventory. 14 frozen source files and the preregistration match Git commit `d9121a93c44e0cdf6533497b056490614a8fa4fc`; all 36 original primary Git blobs also match. These categories overlap.

The final outer `nxdn-air-v1-execution.log` is absent from every before-execution hash group and has no frozen copy. It is outside the declared freeze inventory; its creation timing was not independently observed. There is no actual hash mismatch to waive, and no gate was relaxed.

The immutable within-run report SHA-256 is `867264df1b1f05eaa5db49d30e7287def90c3a32ebb3d9dcd47a0e2feb296f6f`. Its measurement, progression and preservation flags agree with this audit; product promotion remains false.

This is reference construction for nine fixed clear outbound frames. The 24 transmitted word intervals reuse 20 source words, and the second SACCH cycle is incomplete. It establishes no receiver acquisition, semantic call acceptance, speech synthesis, playback, RF robustness, decoding speed, privacy capability or APK/EXE improvement.

