"""Publish preserved clear-routing evidence, including failed quality gates."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
STUDY = ROOT / 'build/nxdn-clear-routing-v1-run-20260925'
STEM = 'nxdn-clear-routing-v1-2026-09-25'
DEST = ROOT / 'docs/research/evidence'
ARCHIVE, INDEX = DEST / (STEM + '-raw.zip'), DEST / (STEM + '.json')
HARNESS = '9fd7e2c859b356b3e697ce95b800ca60e9c60bbc'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def need(value, message):
    if not value: raise ValueError(message)

need(not ARCHIVE.exists() and not INDEX.exists(), 'Existing publication is immutable')
report_raw = (STUDY / 'report.json').read_bytes()
need(sha(report_raw) == '50a7dbb4b33200e203e102f58195110abedf6159ce02b66b551ebb2c65b74ab0', 'Report identity changed')
report = json.loads(report_raw)
need(report['measurement_pass'] and report['preservation_pass'], 'Measurement/preservation gate failed')
need(report['progression_pass'] is False and report['product_promotion'] is False, 'Failed progression was changed')
need(len(report['attempts']) == 36 and all(a['exit_code'] == 0 for a in report['attempts']), 'Native attempt inventory changed')
for name, digest in report['files'].items():
    need(sha(STUDY.joinpath(*name.replace('\\', '/').split('/')).read_bytes()) == digest, 'Raw file changed: ' + name)
before = json.loads((STUDY / 'before-execution.json').read_bytes())
need(before['commit'] == HARNESS, 'Wrong frozen harness')
for group in ('frozen_files', 'original_files', 'copied_identities', 'configured_sources', 'protected'):
    need(all(Path(p).is_file() and sha(Path(p).read_bytes()) == digest for p, digest in before[group].items()), 'Preservation failure: ' + group)

audits = {}
for name in ('results-audit', 'results-audit-supplement'):
    raw = (ROOT / ('build/nxdn-clear-routing-v1-' + name + '.json')).read_bytes()
    value = json.loads(raw)
    need(value['audit_pass'], 'Independent audit failed: ' + name)
    audits[name] = {'sha256': sha(raw), 'checks': value.get('checks', value.get('assertions'))}
supplement = json.loads((ROOT / 'build/nxdn-clear-routing-v1-results-audit-supplement.json').read_bytes())
need(supplement['prefix_voice_exposure'] is False, 'Do not erase the missing EOF exposure limitation')
ci = {}
for event, number in (('push', 36189961365), ('pr', 36189968629)):
    value = json.loads((ROOT / f'build/nxdn-clear-routing-v1-ci-{event}-status.json').read_bytes())
    need(value['databaseId'] == number and value['headSha'] == HARNESS and value['status'] == 'completed'
         and value['conclusion'] == 'success' and len(value['jobs']) == 2
         and all(j['conclusion'] == 'success' for j in value['jobs']), 'CI identity/outcome changed')
    ci[event] = number

payload = {'study/' + p.relative_to(STUDY).as_posix(): p.read_bytes()
           for p in sorted(STUDY.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
extras = [ROOT / 'build' / ('nxdn-clear-routing-v1-' + name + '.' + ext)
          for name in ('results-audit', 'results-audit-supplement') for ext in ('py', 'json')]
extras += [ROOT / 'build/nxdn-clear-routing-v1-results-audit.md']
extras += [ROOT / 'build' / ('nxdn-clear-routing-v1-' + name) for name in
           ('ci-push.log', 'ci-pr.log', 'ci-push-status.json', 'ci-pr-status.json', 'execution.log', 'configure.ps1')]
extras += [Path(__file__), ROOT / '.github/workflows/nxdn-clear-routing-framework.yml',
           ROOT / 'build/nxdn-voice-words-v1-preflight-audit.py']
for p in extras: payload['publication/' + p.name] = p.read_bytes()
payload['licenses/XeraX-LICENSE.txt'] = (ROOT / 'LICENSE').read_bytes()
payload['licenses/dsd-neo-LICENSE.txt'] = (ROOT / 'upstream/dsd-neo/LICENSE').read_bytes()
build_audit = json.loads((ROOT / 'build/nxdn-clear-routing-v1-build-audit.json').read_bytes())
headers = [Path(p) for p in build_audit['dependencies'] if p.endswith('include\\mbelib-neo\\mbelib.h')]
need(len(headers) == 1, 'Installed codec header identity missing')
installed = headers[0].parents[2]
for p in sorted((installed / 'share').glob('*/copyright')):
    payload['licenses/installed/' + p.parent.name + '.txt'] = p.read_bytes()
payload['publication/mbelib.h'] = headers[0].read_bytes()
payload['publication/mbelib-source.tar.gz'] = (ROOT / 'build/mbelib-voice-words-v1-source.tar.gz').read_bytes()
payload['README.txt'] = (
    'XeraX clear NXDN48 routing evidence, 25 September 2026\n'
    'Registration d98ccd3; frozen harness ' + HARNESS + '.\n'
    'Exactly 36 Windows receiver processes; all exited zero. Measurement passes,\n'
    'routing and negative exposure gates FAIL. No product promotion or new app build.\n'
    'Existing public fast option routed 24 known words versus default 8 on one cold\n'
    'fixture; 320 ms earlier in source-stream time, not measured CPU/RF/app speed.\n'
    'EOF prefixes contain no voice calls: active-voice EOF safety was not exercised.\n'
    'Source word 19 has an ERASURE synthesis flag. Exact bits are not accepted speech.\n'
    'The frozen flag counterexample used wrong constants; the explicitly post-execution\n'
    'supplement checks actual 32/64/128 masks without changing any frozen outcome.\n\n'
    'study/ contains every native attempt, immutable input, raw events and pop trace,\n'
    'frozen observer/checker sources, research executable/runtime DLLs and identities.\n'
    'These tools are not a phone APK or Windows app installer. The source baseline is\n'
    'https://github.com/ElXavi07/XeraX-SDR/tree/289a82f8fd9c0495b64bf948fd45413bc63261c4\n'
    'Toolchain/system libraries are identified; Windows system DLLs are prerequisites.\n'
    'publication/ includes independent audits, the supplemental coverage limitation,\n'
    'CI and outer execution logs. These post-execution items were not pre-execution evidence.\n\n'
    'Offline review without running native code: import analyze from\n'
    'study/frozen/source_repository/experiments/nxdn_clear_routing_v1; keep this hierarchy.\n'
    'Call validate_inputs(study/inputs), then inspect(rows, trace_path, case, manifest,\n'
    'inputs, detail) for every saved events.jsonl and pops.u32le; compare the full grid.\n'
    'The archive checker should reproduce measurement=true, progression=false.\n'
    'Absolute identities refer to the study machine and are not rewritten on extraction.\n'
    'Windows-relative report paths use backslashes. Archive names use forward slashes.\n'
    'No speech, playback, I/Q, RF, privacy, GPU or whole-app performance claim.\n'
).encode('utf-8')
inventory = {'schema': 1, 'kind': 'nxdn_clear_routing_v1_archive', 'native_execution_by_publication': False,
             'files': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(payload.items())}}
payload['archive-manifest.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(payload.items()):
        z.writestr(zipfile.ZipInfo(name, date_time=(2026, 9, 25, 0, 0, 0)), raw,
                   compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(ARCHIVE) as z:
    need(len(z.namelist()) == len(payload) and set(z.namelist()) == set(payload) and z.testzip() is None
         and all(z.read(name) == raw for name, raw in payload.items()), 'Archive inventory/content mismatch')
publication = {'schema': 1, 'kind': 'nxdn_clear_routing_v1', 'registration_commit': 'd98ccd32ddc6cb4fa15bae07a91cf33e144df445',
    'harness_commit': HARNESS, 'receiver_baseline': before['product_baseline'], 'measurement_pass': True,
    'routing_pass': False, 'negative_pass': False, 'finite_voice_safety_pass': True, 'prefix_voice_exposure': False,
    'progression_pass': False, 'product_promotion': False, 'native_invocations': 36, 'native_exit_zero': 36,
    'native_totals': {'frames': 160, 'soft_fec_calls': 224, 'synthesis_calls': 224, 'source_exact_routes': 224,
                      'erasure_flag_calls': 16, 'repeat_flag_calls': 0, 'mute_flag_calls': 0},
    'cold_comparison': {'default_words': 8, 'public_fast_words': 24, 'default_first_fec_sample': 23680,
        'public_fast_first_fec_sample': 8320, 'source_time_difference_ms': 320, 'wallclock_speed_measured': False},
    'report_sha256': sha(report_raw), 'independent_audits': audits,
    'ci': {'tests': 43, 'modes': ['normal', 'optimized'], 'platforms': ['Windows', 'Linux'], **ci, 'native_matrix_in_ci': False},
    'archive': {'file': ARCHIVE.name, 'bytes': ARCHIVE.stat().st_size, 'entries': len(payload),
                'sha256': sha(ARCHIVE.read_bytes()), 'every_entry_verified': True},
    'limits': ['finite synthetic discriminator samples, not complex I/Q or RF', 'primary primed call gate failed',
        'bad-LICH exposure control failed', 'EOF safety not exercised with active voice',
        'frozen substitution-flag test constants incorrect; supplement is post-execution',
        'known-bit routing and synthesis calls do not certify speech or playback',
        'no privacy/key operation, GPU or CPU/whole-app speed measurement', 'released APK/Windows packages unchanged']}
INDEX.write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
print(json.dumps(publication['archive']))
