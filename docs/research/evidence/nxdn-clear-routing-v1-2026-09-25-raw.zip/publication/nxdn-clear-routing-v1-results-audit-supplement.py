"""Post-execution read-only clarification: real flags and exposure limitations.

Does not import the study checker, regenerate inputs, or invoke a native tool.
The first independent audit and all registered files remain untouched.
"""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parent.parent
STUDY=ROOT/"build/nxdn-clear-routing-v1-run-20260925"
BASE=ROOT/"build/nxdn-clear-routing-v1-results-audit.py"
spec=importlib.util.spec_from_file_location("independent_raw_audit",BASE)
base=importlib.util.module_from_spec(spec); spec.loader.exec_module(base)
AUDIT=ROOT/"build/nxdn-clear-routing-v1-results-audit.json"


def main():
    first=base.parse(AUDIT.read_bytes()); before=base.parse((STUDY/"before-execution.json").read_bytes())
    checks=[]
    def check(ok,what): checks.append({"pass":bool(ok),"check":what})
    pins=[]
    for group in ("frozen_files","original_files","copied_identities","configured_sources","protected"):
        for path,digest in before[group].items():
            check(Path(path).is_file() and base.sha(Path(path).read_bytes())==digest,"unchanged:"+path)
            if Path(path).name==BASE.name: pins.append({"group":group,"path":path})
    check(first["audit_pass"],"initial_independent_audit_pass")
    header_paths=[Path(p) for p in before["original_files"] if p.replace("\\","/").endswith("mbelib-neo/mbelib.h")]
    check(bool(header_paths),"audited_mbelib_header_retained")
    header=header_paths[0].read_text(encoding="utf-8")
    masks={name:int(re.search(r"#define\s+MBE_PROCESS_FLAG_"+name+r"\s+(0x[0-9A-Fa-f]+)",header).group(1),16)
           for name in ("ERASURE","REPEAT","MUTE")}
    check(masks=={"ERASURE":32,"REPEAT":64,"MUTE":128},"primary_flag_constants")
    flag_cases=[]
    for flags,expected in ((3,[]),(35,["ERASURE"]),(67,["REPEAT"]),(131,["MUTE"]),(227,["ERASURE","REPEAT","MUTE"]),
                           (4,[]),(8,[]),(16,[])):
        names=[name for name,mask in masks.items() if flags & mask]
        check(names==expected,"post_execution_flag_counterexample:"+str(flags))
        flag_cases.append({"flags":flags,"substitution_names":names,"speech_acceptance":None})
    flags_total=collections.Counter(); status=collections.Counter(); special=[]; cases=[]; matrix_count=0
    truth,words,channels=base.oracle(STUDY/"inputs")
    for prior in first["attempts"]:
        cid=prior["id"]; detail=prior["observed"]; scenario=cid.rsplit("-c",1)[0]
        rows=[base.parse(line) for line in (STUDY/"runs"/cid/str(detail)/"events.jsonl").read_bytes().splitlines()]
        frames=[]; active=None; route_sources={}; transitions=[]; sources=base.source_frames(scenario)
        for row in rows:
            if row["kind"]=="frame_begin": active={"begin":row,"events":[]}
            elif row["kind"]=="frame_end":
                active["end"]=row; frames.append(active); active=None
            elif active is not None: active["events"].append(row)
        for frame in frames:
            source=base.coordinate(frame,sources,list(range(8)))
            if source:
                transitions.append({"ordinal":source["ordinal"],"source_frame":source["source_frame"],"scored":source["scored"],
                    "begin_frontier":frame["end"]["body_calls"][0]["before"],"end_frontier":frame["end"]["body_calls"][-1]["after"],
                    "call":frame["end"].get("call"),"ran":frame["end"]["ran"],"confirmed":frame["end"]["confirmed"],
                    "streak":frame["end"]["streak"],"result":frame["end"]["value"]})
            for event in frame["events"]:
                if event["kind"]=="route_begin":
                    slot=event["slot"]; indices=list(range(38+slot*36,74+slot*36))
                    owned=base.coordinate(frame,sources,list(range(8))+indices)
                    if owned and slot in truth[owned["source_frame"]]["slots"]:
                        route_sources[event["route_id"]]={**owned,"slot":slot,"source_id":truth[owned["source_frame"]]["slots"][slot]}
                if event["kind"]=="fec_input" and event["outer"]:
                    matrix=["0"]*96; reliability=[0]*96
                    for position,bit in enumerate(event["channel72"]):
                        k=(position%4)*18+position//4
                        r,c=(0,23-k) if k<24 else (1,46-k) if k<47 else (2,57-k) if k<58 else (3,71-k)
                        matrix[24*r+c]=bit
                        reliability[24*r+c]=event["channel_reliability"][position//2]
                    check("".join(matrix)==event["matrix96"],"all96_matrix:"+cid+":"+str(event["call_id"]))
                    check(reliability==event["reliability"],"all96_reliabilities:"+cid+":"+str(event["call_id"]))
                    matrix_count+=1
        for row in rows:
            if row["kind"]=="synthesis":
                status[str(row["status"])]+=1
                if row["result_after"] is not None:
                    flags=row["result_after"]["flags"]; flags_total[str(flags)]+=1
                    meanings=[name for name,mask in masks.items() if flags & mask]
                    if meanings:
                        special.append({"id":cid,"observed":detail,"route_id":row["route_id"],"call_id":row["call_id"],
                            "flags":flags,"meanings":meanings,"source":route_sources.get(row["route_id"]),
                            "input49_matches_known_word":row["input49"]==words[route_sources[row["route_id"]]["source_id"]] if row["route_id"] in route_sources else None})
        first_fec=next((r for r in rows if r["kind"]=="fec" and r["outer"]),None)
        detail_frames=[]
        if detail:
            for frame in frames:
                lich=next((r for r in frame["events"] if r["kind"]=="lich"),None)
                if lich:
                    detail_frames.append({"frame":frame["begin"]["frame"],"body_begin":frame["end"]["body_calls"][0]["before"],
                        "body_end":frame["end"]["body_calls"][-1]["after"],"full_lich":lich["full_lich"],"lich":lich["lich"],
                        "reason":lich["reason"],"body_count":frame["end"]["body_count"],"frame_result":frame["end"]["value"],
                        "confirmed":frame["end"]["confirmed"],"streak":frame["end"]["streak"]})
        cases.append({"id":cid,"observed":detail,"transitions":transitions,"detail_frames":detail_frames,
            "first_FEC_delivered_frontier":(first_fec["read_start"]+first_fec["cache_pos"]) if first_fec else None,
            "route_count":rows[-1]["route_words"],"synthesis_count":rows[-1]["synthesis_calls"],
            "body_partial_or_empty_count":sum(not base.complete(c) for f in frames for c in f["end"]["body_calls"])})
    check(flags_total=={"3":208,"35":16},"actual_synthesis_flags")
    check(len(special)==16 and all(r["source"] and r["source"]["source_frame"]==5 and r["source"]["slot"]==3
          and r["source"]["source_id"]==19 and r["input49_matches_known_word"] for r in special),"erasure_is_known_source_word19")
    prefix=[r for r in cases if r["id"].startswith("prefix_")]
    check(len(prefix)==12 and all(r["route_count"]==r["synthesis_count"]==0 for r in prefix),"EOF_prefixes_do_not_expose_active_voice")
    contrasts=[]
    for chunk in (37,512):
        for detail in (0,1):
            a=next(r for r in cases if r["id"]==f"cold_default-c{chunk}" and r["observed"]==detail)
            b=next(r for r in cases if r["id"]==f"cold_fast-c{chunk}" and r["observed"]==detail)
            delta=a["first_FEC_delivered_frontier"]-b["first_FEC_delivered_frontier"]
            check((a["first_FEC_delivered_frontier"],b["first_FEC_delivered_frontier"],delta)==(23680,8320,15360),"first_FEC_sample_frontier_contrast")
            contrasts.append({"chunk":chunk,"observed":detail,"default":23680,"public_fast":8320,"sample_difference":delta,
                              "discriminator_duration_ms":delta/48,"not_cpu_wallclock_or_RF_latency":True})
    out={"schema":1,"post_execution_supplement":True,"audit_pass":all(r["pass"] for r in checks),
         "checks":len(checks),"failures":[r for r in checks if not r["pass"]],
         "initial_audit_sha256":base.sha(AUDIT.read_bytes()),"initial_script_sha256":base.sha(BASE.read_bytes()),
         "initial_script_in_before_groups":pins,"header_sha256":base.sha(header_paths[0].read_bytes()),"flag_masks":masks,
         "coverage_limitation":"Frozen test_substitution_flags used4/8/16, not actual ERASURE32/REPEAT64/MUTE128. The correct-bit counterexamples here are supplemental post-execution checks, not preregistered coverage.",
         "flag_counterexamples":flag_cases,"synthesis_flags_all36":dict(flags_total),"synthesis_status_all36":dict(status),
         "flagged_occurrences":special,"detailed_outer_matrices_verified":matrix_count,
         "prefix_voice_exposure":False,"H4_observed_no_violation_but_not_exercised_with_active_voice":True,
         "first_FEC_sample_frontier_contrasts":contrasts,"cases":cases,"native_invocations":0,
         "scope":"Read-only supplemental evidence; known bits and source duration do not certify speech, playback, CPU performance, RF or product readiness."}
    path=ROOT/"build/nxdn-clear-routing-v1-results-audit-supplement.json"
    path.write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:out[k] for k in ("audit_pass","checks","failures","synthesis_flags_all36","synthesis_status_all36","prefix_voice_exposure","detailed_outer_matrices_verified")}))


if __name__=="__main__": main()
