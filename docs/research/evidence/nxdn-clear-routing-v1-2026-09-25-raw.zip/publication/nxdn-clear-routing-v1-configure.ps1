$ErrorActionPreference = 'Stop'
$routingBuild = Join-Path $env:LOCALAPPDATA 'XeraXSDR-build/nxdn-clear-routing-v1-20260925'
$routingRoot = (Get-Location).Path
if (Test-Path -LiteralPath $routingBuild) { throw 'Existing experiment build directory is immutable for this configure invocation.' }
New-Item -ItemType Directory -Path $routingBuild | Out-Null
Copy-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'XeraXSDR-build/nxdn-observation-v2-20260925/toolchain.cmake') -Destination (Join-Path $routingBuild 'toolchain.cmake')
& cmake -S experiments/nxdn_clear_routing_v1 -B $routingBuild -G Ninja `
  -DCMAKE_BUILD_TYPE=Release `
  "-DCMAKE_TOOLCHAIN_FILE=$env:LOCALAPPDATA/XeraXSDR-build/vcpkg/scripts/buildsystems/vcpkg.cmake" `
  "-DVCPKG_CHAINLOAD_TOOLCHAIN_FILE=$routingBuild/toolchain.cmake" `
  "-DVCPKG_INSTALLED_DIR=$env:LOCALAPPDATA/XeraXSDR-build/lab-installed" `
  -DVCPKG_TARGET_TRIPLET=x64-mingw-static -DVCPKG_HOST_TRIPLET=x64-mingw-static `
  -DVCPKG_MANIFEST_MODE=OFF -DCMAKE_C_FLAGS=-Wno-unused-command-line-argument `
  -DCMAKE_CXX_FLAGS=-Wno-unused-command-line-argument -DDSD_AUDIO_BACKEND=none `
  -DDSD_ENABLE_QT_UI=OFF -DDSD_ENABLE_TERMINAL_UI=OFF -DDSD_FORCE_RADIO_PIPELINE=ON `
  -DDSD_ENABLE_LTO=OFF -DDSD_ENABLE_FAST_MATH=OFF -DDSD_ENABLE_NATIVE=OFF `
  2>&1 | Tee-Object -FilePath (Join-Path $routingRoot 'build/nxdn-clear-routing-v1-configure.log')
if ($LASTEXITCODE -ne 0) { throw 'Receiver configure failed; evidence retained.' }
& cmake --build $routingBuild --target xerax_nxdn_clear_routing_v1 --parallel 4 `
  2>&1 | Tee-Object -FilePath (Join-Path $routingRoot 'build/nxdn-clear-routing-v1-build.log')
if ($LASTEXITCODE -ne 0) { throw 'Receiver build failed; evidence retained.' }
