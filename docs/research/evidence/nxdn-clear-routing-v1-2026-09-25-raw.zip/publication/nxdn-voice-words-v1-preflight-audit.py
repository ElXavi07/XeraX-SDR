"""Read-only binary/import/source and fixed corpus audit; never loads a native DLL/EXE."""
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BUILD = Path(os.environ['LOCALAPPDATA']) / 'XeraXSDR-build/nxdn-voice-words-v1-20260925'
PRIMARY = ROOT / 'build/nxdn-voice-v1-primary'
CORPUS = ROOT / 'build/nxdn-voice-words-v1-inputs-20260925'
OUT = ROOT / 'build/nxdn-voice-words-v1-preflight-audit'


def need(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pe_imports(path):
    data = Path(path).read_bytes()
    need(data[:2] == b'MZ', 'not PE: ' + str(path))
    nt = struct.unpack_from('<I', data, 60)[0]
    need(data[nt:nt + 4] == b'PE\0\0', 'bad PE header')
    machine, count = struct.unpack_from('<HH', data, nt + 4)
    need(machine == 0x8664, 'expected AMD64 image')
    optional_size = struct.unpack_from('<H', data, nt + 20)[0]
    optional = nt + 24
    need(struct.unpack_from('<H', data, optional)[0] == 0x20b, 'expected PE32+')
    sections = []
    for i in range(count):
        at = optional + optional_size + i * 40
        virtual_size, rva, raw_size, raw_start = struct.unpack_from('<IIII', data, at + 8)
        sections.append((rva, max(virtual_size, raw_size), raw_start, raw_size))

    def file_offset(rva, length=1):
        for start, size, raw, raw_size in sections:
            if start <= rva and rva + length <= start + size:
                delta = rva - start
                need(delta + length <= raw_size, 'RVA has no stored bytes')
                need(raw + delta + length <= len(data), 'RVA outside image')
                return raw + delta
        raise ValueError('RVA not mapped')

    def text_at(rva):
        at = file_offset(rva)
        end = data.find(b'\0', at, at + 512)
        need(end >= at, 'unterminated import name')
        return data[at:end].decode('ascii')

    names = []
    rva, length = struct.unpack_from('<II', data, optional + 112 + 8)
    if rva:
        for i in range(4096):
            row = struct.unpack_from('<IIIII', data, file_offset(rva + i * 20, 20))
            if row == (0, 0, 0, 0, 0):
                break
            names.append(text_at(row[3]))
        else:
            raise ValueError('unterminated imports')
    # This profile has no delay imports. Refuse to silently omit that closure.
    delay_rva, delay_length = struct.unpack_from('<II', data, optional + 112 + 13 * 8)
    need(delay_rva == delay_length == 0, 'delay import closure not handled')
    return names


def map_owners(path, symbols):
    owner = None
    result = {symbol: set() for symbol in symbols}
    for line in Path(path).read_text().splitlines():
        if ':(.text' in line:
            owner = line.split(maxsplit=3)[3]
        for symbol in symbols:
            if line.strip().endswith(symbol):
                need(owner is not None, 'symbol without owner')
                result[symbol].add(owner)
    need(all(result.values()), 'missing mapped symbol')
    return {k: sorted(v) for k, v in result.items()}


def main():
    manifest_path = CORPUS / 'manifest.json'
    need(digest(manifest_path) == '4d31e3d17c56162b706f9187f8f000bfbb0fce0f1e353f9ee2519bd66e355a84', 'corpus manifest changed')
    manifest = json.loads(manifest_path.read_bytes())
    for name, record in manifest['files'].items():
        p = CORPUS / name
        need(p.stat().st_size == record['bytes'] and digest(p) == record['sha256'], 'corpus file changed: ' + name)
    need((CORPUS / 'primary-manifest.json').read_bytes() == (PRIMARY / 'manifest.json').read_bytes(), 'primary manifest differs')
    primary_manifest = json.loads((PRIMARY / 'manifest.json').read_bytes())
    for row in primary_manifest['files']:
        raw = (PRIMARY / row['path']).read_bytes()
        need(digest(PRIMARY / row['path']) == row['sha256'], 'primary source drift')
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        need(blob == row['git_blob_sha1'], 'primary blob drift')
    for name, expected in manifest['generation_sources'].items():
        need(digest(ROOT / 'experiments/nxdn_voice_words_v1' / name) == expected, 'generation source drift')

    # Reconstruct source words and normalized packing directly from the pinned
    # asset. Do not import prepare.py, encoding.py, a checker, or any decoder.
    asset = (PRIMARY / 'NXDNClients/NXDNGateway/Audio/en_GB.nxdn').read_bytes()
    linked = asset[652 * 13:662 * 13]
    need((CORPUS / 'linked-source.bin').read_bytes() == linked, 'linked source changed')
    silence = bytes.fromhex('f0000000000078000000000000')
    need((CORPUS / 'silence-source.bin').read_bytes() == silence, 'silence source changed')
    voice = (PRIMARY / 'NXDNClients/NXDNGateway/Voice.cpp').read_text()
    definition = re.search(r'const unsigned char SILENCE\[\]\s*=\s*\{([^}]+)\}', voice).group(1)
    need(bytes(int(x, 16) for x in re.findall(r'0x([0-9A-Fa-f]+)U', definition)) == silence, 'silence is not pinned declaration')
    expected_rows = []

    def add(kind, index, bits):
        expected_rows.append({'id': len(expected_rows), 'kind': kind, 'source_index': index, 'bits': bits})

    for kind, raw in (('announcement', linked), ('upstream_silence', silence)):
        for unit in range(len(raw) // 13):
            bits = ''.join(format(byte, '08b') for byte in raw[unit * 13:(unit + 1) * 13])
            add(kind, unit * 2, bits[:49])
            add(kind, unit * 2 + 1, bits[49:98])
    add('zero', 0, '0' * 49)
    add('ones', 0, '1' * 49)
    for i in range(49):
        add('onehot', i, ''.join('1' if j == i else '0' for j in range(49)))
    for i in range(4096):
        add('sweep_a', i, format(i, '012b') + '0' * 37)
    for i in range(4096):
        add('sweep_b', i, '0' * 12 + format(i, '012b') + '0' * 25)
    add('pair_padding', 0, '0' * 49)
    need(json.loads((CORPUS / 'words.json').read_bytes()) == expected_rows, 'source ID/word recipe mismatch')
    pairs = (CORPUS / 'input.pairs13').read_bytes()
    need(len(expected_rows) == 8266 and len(pairs) == 53729, 'dimensions')
    for i in range(4133):
        text = expected_rows[2 * i]['bits'] + expected_rows[2 * i + 1]['bits'] + '000000'
        expected = bytes(int(text[j:j + 8], 2) for j in range(0, 104, 8))
        need(pairs[13 * i:13 * (i + 1)] == expected, 'packed word order/padding mismatch')
    pads = [linked[i + 12] & 63 for i in range(0, 130, 13)]
    need(manifest['linked_original_padding'] == pads and manifest['silence_original_padding'] == (silence[12] & 63), 'original padding provenance mismatch')
    need((CORPUS / 'expected.channels9').stat().st_size == 74394, 'expected output length')

    commands_path = BUILD / 'compile_commands.json'
    commands = json.loads(commands_path.read_bytes())
    need(len(commands) == 5, 'unexpected translation units')
    need(all('-DUSE_NXDN' not in row['command'] and '-Werror' in row['command'] for row in commands), 'flags drift')
    want = {'primary_encoder.cpp', 'primary_support.cpp', 'NXDNAudio.cpp', 'Golay24128.cpp', 'probe.c'}
    need({Path(row['file']).name for row in commands} == want, 'unexpected source closure')
    for row in commands:
        if Path(row['file']).name in ('NXDNAudio.cpp', 'Golay24128.cpp'):
            need(Path(row['file']).resolve() == (PRIMARY / 'MMDVM-Host' / Path(row['file']).name).resolve(), 'wrong primary source')
    hard = 'mbe_decodeAmbe3600x2450Frame'
    soft = 'mbe_decodeAmbe3600x2450SoftFrame'
    probe_owners = map_owners(BUILD / 'xerax_voice_probe.map', [hard, soft])
    need(all(value == ['ambe3600x2450.c.obj:(.text)'] for value in probe_owners.values()), 'decoder owner replaced')
    enc = 'CNXDNAudio::encode(unsigned char const*, unsigned char*) const'
    primary_owners = map_owners(BUILD / 'xerax_voice_primary.map', [enc, 'CGolay24128::encode23127(unsigned int)', 'CGolay24128::encode24128(unsigned int)', 'CUtils::countBits(unsigned int)'])
    need(all('NXDNAudio.cpp.obj:' in owner for owner in primary_owners[enc]), 'primary owner replaced')
    for symbol in ('CGolay24128::encode23127(unsigned int)', 'CGolay24128::encode24128(unsigned int)'):
        need(all('Golay24128.cpp.obj:' in owner for owner in primary_owners[symbol]), 'Golay owner replaced')
    need(all('primary_support.cpp.obj:' in owner for owner in primary_owners['CUtils::countBits(unsigned int)']), 'support owner replaced')

    installed = Path(os.environ['LOCALAPPDATA']) / 'XeraXSDR-build/lab-installed/x64-mingw-static'
    archive = installed / 'lib/libmbe-neo-static.a'
    ninja = (BUILD / 'build.ninja').read_text()
    need(str(archive).replace('\\', '/') in ninja and '-lpthread' in ninja, 'actual static library/thread linkage absent')
    compiler = Path(re.search(r'^"?(.+?clang\+\+\.exe)', commands[0]['command']).group(1))
    nm = compiler.parent / 'llvm-nm.exe'
    result = subprocess.run([str(nm), '--defined-only', '--print-file-name', str(archive)], text=True, capture_output=True, check=True)
    definitions = [line for line in result.stdout.splitlines() if line.endswith(' ' + hard) or line.endswith(' ' + soft)]
    need(len(definitions) == 2 and all('ambe3600x2450.c.obj:' in line and ' T ' in line for line in definitions), 'static decoder definition missing/duplicated')
    # System DLLs are platform prerequisites; never load them or recurse through
    # the Windows OS. All non-system runtime DLL imports are recursively pinned.
    sysroot = Path(re.search(r'--sysroot=([^ ]+)', commands[0]['command']).group(1))
    system = Path(os.environ['SystemRoot']) / 'System32'
    search = [BUILD, sysroot / 'bin', installed / 'bin', system]
    runtime = {}
    import_graph = {}
    system_names = set()
    todo = [BUILD / 'xerax_voice_primary.exe', BUILD / 'xerax_voice_probe.exe']
    seen = set()
    while todo:
        path = todo.pop()
        if path in seen:
            continue
        seen.add(path)
        imports = pe_imports(path)
        import_graph[str(path)] = imports
        for name in imports:
            if name.lower().startswith(('api-ms-', 'ext-ms-')):
                system_names.add(name)
                continue
            resolved = next((p / name for p in search if (p / name).is_file()), None)
            need(resolved is not None, 'unresolved imported DLL: ' + name)
            if resolved.parent == system:
                system_names.add(name)
            else:
                runtime[str(resolved.resolve())] = digest(resolved)
                todo.append(resolved)
    dependency_paths = [archive, installed / 'include/mbelib-neo/mbelib.h', installed / 'share/mbe-neo/vcpkg-spdx-resources.json', installed / 'share/mbe-neo/vcpkg.spdx.json', installed / 'share/mbe-neo/mbe-neoTargets-release.cmake', ROOT / 'upstream/dsd-neo/include/dsd-neo/core/ambe_interleave.h', ROOT / 'upstream/dsd-neo/src/core/vocoder/dsd_mbe.c', commands_path, BUILD / 'CMakeCache.txt', BUILD / 'build.ninja', BUILD / 'xerax_voice_primary.map', BUILD / 'xerax_voice_probe.map', nm, compiler]
    dependency_paths += [Path(row['file']) for row in commands]
    dependency_paths += [PRIMARY / 'MMDVM-Host' / name for name in ('NXDNAudio.h', 'Golay24128.h', 'Defines.h', 'Utils.h', 'Utils.cpp', 'LICENCE')]
    dependency_paths += [ROOT / 'experiments/nxdn_voice_words_v1' / name for name in ('CMakeLists.txt', 'prepare.py', 'encoding.py')]
    resources = json.loads((installed / 'share/mbe-neo/vcpkg-spdx-resources.json').read_bytes())
    source_archive = ROOT / 'build/mbelib-voice-words-v1-source.tar.gz'
    portfile = ROOT / 'upstream/dsd-neo/vcpkg-ports/mbe-neo/portfile.cmake'
    source_sha512 = hashlib.sha512(source_archive.read_bytes()).hexdigest()
    expected_sha512 = '9675428bd2d7d87cc77a4b3feed65312622ffa15618ff87399f264e8feca288552aae0bbaa16c79cde97fcef57d4fbb89928df0eca3830668afa8a5871748446'
    need(source_sha512 == expected_sha512 and expected_sha512 in portfile.read_text(), 'mbelib source archive/port identity mismatch')
    need(any(check['algorithm'] == 'SHA512' and check['checksumValue'] == source_sha512 for package in resources['packages'] for check in package['checksums']), 'installed source metadata differs')
    dependency_paths += [source_archive, portfile]
    dependencies = {str(p.resolve()): digest(p) for p in dependency_paths}
    outcome = {'audit_pass': True, 'source_and_linkage_pass': True, 'corpus_pass': True, 'native_execution': False, 'script_sha256': digest(Path(__file__)), 'corpus_manifest_sha256': digest(manifest_path), 'words': 8266, 'paired_records': 4133, 'input_bytes': 53729, 'expected_channel_bytes': 74394, 'declared_probe_calls': 27044, 'original_linked_padding': pads, 'source_word_order_and_normalized_packing_independently_reconstructed': True, 'channel_goldens_validated_by_native_encoder': False, 'dependencies': dependencies, 'runtime_files': runtime, 'binary_hashes': {role: digest(BUILD / filename) for role, filename in (('primary', 'xerax_voice_primary.exe'), ('probe', 'xerax_voice_probe.exe'))}, 'binary_import_graph': import_graph, 'system_runtime_prerequisites': sorted(system_names), 'map_symbol_owners': {'primary': primary_owners, 'probe': probe_owners}, 'archive_definition_evidence': definitions, 'installed_library_source_metadata': resources, 'limits': ['No encoder/decoder executable was invoked; llvm-nm only inspects stored symbols.', 'Channel-byte agreement and 27044 decoder outcomes remain future gates.', 'Imported binary/archive/header identity and linker records are verified; no new mbelib source rebuild was performed, and its historical extracted source directory is absent.', 'Recursive non-system DLL closure can be copied by the runner; system DLLs remain OS prerequisites. No runtime-loader smoke test was performed.', 'Source review found no expected-output feedback; this component probe bypasses framing, acquisition, synthesis, playback, RF and privacy.']}
    outcome['installed_library_source_archive_sha512'] = source_sha512
    OUT.with_suffix('.json').write_text(json.dumps(outcome, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'audit_pass': True, 'binary_hashes': outcome['binary_hashes'], 'runtime_files': runtime, 'json_sha256': digest(OUT.with_suffix('.json'))}, indent=2))


if __name__ == '__main__':
    main()
