# Independent clear-routing v1 result audit

2026-09-25. The registered 36-invocation study was read only after root confirmed completion. This audit imported neither the experiment analyzer nor any encoder/generator and invoked no native executable. It independently reconstructed the original source words, associated observations with source coordinates before comparing bits, and checked raw events plus preservation records.

The first audit passes **118 checks**. A separate, explicitly post-execution supplement passes **2,026 checks**, including another preservation pass, all 112 detailed outer input matrices/reliabilities and correct primary flag masks. These audit passes mean the preserved evidence supports the findings below. They do **not** change the experiment's failed progression gate.

## Final registered result

- All 36 native attempts exited zero; raw measurement and final preservation passed.
- H1 primed complete routing failed; the fixed primer did not expose the scored header or retain all 24 occurrences.
- H2 detail/common and provider-chunk neutrality passed in the independent comparisons.
- H3 aggregate negative-control gate failed because the intended bad-LICH rejection was not exposed. The single-weak and zero controls did pass their exposed restrictions.
- H4 recorded no unavailable-slot synthesis, but **none of the 12 EOF-prefix invocations exercised active voice or any partial/empty body call**. EOF occurred during search. This is no demonstration that active voice handles EOF safely.
- Aggregate progression and product promotion remain false. There was no input adjustment, native retry or policy repair.

## Actual bits and routes

Per invocation, both chunks and both detail modes agree:

| Configuration | Receiver frame calls | Exact routed 49-bit occurrences | Actual source occurrence IDs |
|---|---:|---:|---|
| Primed, public fast off | 8 | 8 | V4 words 16–19; first-steal words 2,3; second-steal words 4,5 |
| Cold, public fast off | 7 | 8 | Same eight occurrences |
| Cold, public fast on | 9 | 24 | Words 0–19, then repeated first-steal 2,3 and second-steal 4,5 |
| Single weak voice | 1 | 0 | Accepted source V0 with one valid weak SACCH, unconfirmed |
| Bad LICH | 9 | 16 | V2–V4 words 8–19, then stolen-format survivors 2,3,4,5 |
| Zero | 0 | 0 | None |
| Each prefix 9999 / 10000 / 10001 | 2 | 0 | None |

Across all 36 invocations there are **160 frame calls, 224 actual outer soft-FEC calls and 224 synthesis calls**. There are no hard or nested FEC calls. The 18 detailed invocations contain 80 frame calls, 112 exact routed words and 54 fully supplied canonical source frames. All **90 source-attributed CRC6/12 observations** match independently known information/checkwords. All 10,732 detailed body calls are fully supplied 20-sample commits; no body call in this matrix crosses EOF.

Every one of the 224 routed occurrences matches its known source 49 bits and unchanged synthesis input. Attribution uses the actual frame/slot sample interval, not the decoded word value; repeated IDs 2,3,4,5 remain distinct occurrences. The supplement checks all 96 actual matrix cells and all 96 reliability positions for each of 112 detailed outer calls, including the unused cells. This result certifies bit routing within this fixture, not intelligible speech.

## Acquisition and control observations

In the primed case, the first two actual body starts are 3,120 and 6,960 discriminator samples. Their observed full LICH is `0xF6`, receiver LICH `0x7B`, rejected as unsupported. The canonical primer/header body starts would have been 840 and 4,680. The fixed primer therefore did not establish the required scored header exposure. The first actual canonical voice frame is V3 (source frame 4), which supplies one weak proof and remains unconfirmed; V4 supplies the next weak proof and begins voice. The raw observations establish this sequence; no universal RF explanation is inferred from it.

In primed/default and bad-LICH paths, the first voice initially creates a generic epoch 1 with unknown IDs/crypto and `media_active=1`; this is the real pre-FEC bookkeeping. Later valid FACCH VCALL refines it to group source 901 / target 1201 / clear, and the trailer actually ends epoch 1 with TERMINATOR, media inactive and audio permission cleared. Frozen issue labels about missing header-linked termination or the next eligible RAN concern absent prerequisite exposure; they are **not** evidence that the later observed trailer or live-RAN update decoded incorrectly.

The cold-fast descriptive control exposes all nine canonical frames. Header VCALL publishes source 901, group 1201 and clear classification while live RAN is initially -1; the next valid confirmed SACCH sets RAN 1. The same epoch remains active through voice and terminates correctly at the trailer. This subset does not replace the failed registered primed retention gate.

For the same fixed cold waveform, the first real FEC call occurs at delivered frontier **8,320** with the existing public option and **23,680** without it, in every chunk/detail pairing. The difference is 15,360 samples, or **320 ms of this 48 kHz discriminator source**. It is not measured CPU time, wall-clock latency, an RF improvement or an application claim.

The bad-LICH modification changes the observed acquisition sequence and yields 16 later exact words, but the intended rejected V0 was never exposed. More later words cannot turn that negative-control failure into a pass or establish improved recovery.

## Synthesis flags and the frozen test limitation

All 224 synthesis returns are status 0. After-result flags are **208 × 3** and **16 × 35**. The audited primary header defines ERASURE=`0x20`, REPEAT=`0x40`, MUTE=`0x80`; flags 35 equal base flags 3 plus ERASURE. Every erasure is the exact known source word 19, pure V4 slot 3, once per voiced invocation. No REPEAT or MUTE bit appears in these raw results. Correct source bits and a status-zero synthesis call do not establish valid original speech or speaker playback.

The frozen framework test named `test_substitution_flags_are_reported_without_speech_claim` used values **4, 8 and 16**, not the actual masks **32, 64 and 128**. That is a real pre-execution coverage limitation. No frozen test or evidence has been edited. The supplement checks actual masks and counterexamples 3/35/67/131/227 plus 4/8/16, explicitly **after execution**; it cannot retroactively claim complete preregistered flag coverage. No registered source-bit or finite-ownership gate depends on these flags, and the checker has no speech-acceptance metric.

## Preservation and evidence identities

Every declared before-execution group matches current bytes: **142 frozen files, 531 originals, 142 copied identities, 922 configured sources and 47 protected prior artifacts**. All **359 report-listed output hashes** match. The independent audit script was not present in any before-execution group; the earlier possibility that it was caught by the broad preflight glob was checked and disproved. It remains unchanged regardless, and the post-run clarification is a separate script/JSON.

- Frozen report SHA-256: `50a7dbb4b33200e203e102f58195110abedf6159ce02b66b551ebb2c65b74ab0`.
- First audit script: `71fadd82b1643cf96006271e74a40ff23f7616a9387369d7cb75315e496983c5`.
- First audit JSON: `dd9559fe103f0d47a30914223397c5a54c8d3d8c73afccfd7c9d215d9140ead4`.
- Supplement script: `6ed6e73d179e362d6220f9b8ecf49592c8ae5c3aa0bbff0f1f0387a831749b71`.
- Supplement JSON: `2ecf4fdf1b5ff35895622da25b65c184c6c9c3a045425997e11be9f5eb933e16`.

The machine files preserve per-case source intervals, statuses, flags, call transitions, failed quality gates and scope. No result establishes speech intelligibility, hardware playback, impaired complex-IQ robustness, encryption capability or production readiness.
