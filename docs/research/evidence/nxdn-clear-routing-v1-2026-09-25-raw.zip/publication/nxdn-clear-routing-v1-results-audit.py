"""Read saved clear-routing evidence only; no encoder/decoder/checker imports.

Prepared before the native matrix. Execute only after the root confirms that
all registered attempts and final preservation/report files exist.
"""
import collections
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent.parent
STUDY = ROOT / "build/nxdn-clear-routing-v1-run-20260925"
OUTPUT = ROOT / "build/nxdn-clear-routing-v1-results-audit"
DETAIL = {"crc", "lich", "scch", "voice_begin", "voice_end", "mbe_begin", "mbe_end", "audio_begin", "audio_end", "fec_input"}
CONFIGURATIONS = (("primed", "primed", 0), ("cold_default", "cold", 0), ("cold_fast", "cold", 1),
                  ("single_weak", "single_weak", 1), ("bad_lich", "bad_lich", 0), ("zero", "zero", 0),
                  ("prefix_9999", "prefix_9999", 0), ("prefix_10000", "prefix_10000", 0), ("prefix_10001", "prefix_10001", 0))


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result: raise ValueError("Duplicate JSON key " + key)
        result[key] = value
    return result


def parse(raw):
    def reject(value): raise ValueError("Nonfinite JSON " + value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=reject)


def sha(raw): return hashlib.sha256(raw).hexdigest()


def checksum(info, width):
    # Direct serial shift register, independently of receiver/test-checker tables.
    value = (1 << width)-1
    for bit in info:
        feedback = ((value >> (width-1)) & 1) ^ int(bit)
        value = (value << 1) & ((1 << width)-1)
        if feedback: value ^= {6: 0x27, 12: 0x80f}[width]
    return value


def asbits(data): return "".join(format(value, "08b") for value in data)


def descramble(dibits, seed):
    register = 228 if seed == 0 else min(seed, 511)
    result = []
    for value in dibits:
        result.append(int(value) ^ ((register & 1) << 1))
        register = (register >> 1) | (((register ^ (register >> 4)) & 1) << 8)
    return result


def oracle(inputs):
    records = (inputs / "reference/primary.records96").read_bytes()
    source = (inputs / "reference/linked-source.bin").read_bytes()
    channels = (inputs / "reference/voice-reference.channels9").read_bytes()
    packed = (inputs / "reference/input.records41").read_bytes()
    expected = {"source": "8f4116e67a4c950a524c8568caf17d550e9b0b0bbdac3f9e3761ce76c0056e41",
                "records": "bedb3ae824c357e68e8d2883b808b357e228e74c7ce253acf0a41cf257234c0b",
                "channels": "05ed6f2d7c548e6b6e94e81bb12534afde0c2e13301791a8f1d4d2778dd6eed3",
                "packed": "74c0fd60a05624623157f82598cf20ad9da7f9ea86a957b396933672f5efcaab"}
    for name, raw in (("source",source),("records",records),("channels",channels),("packed",packed)):
        if sha(raw) != expected[name]: raise ValueError("Pinned source changed: " + name)
    words=[]
    for n in range(10):
        pair=asbits(source[n*13:(n+1)*13]); words += [pair[:49],pair[49:98]]
    truth=[]
    for i in range(9):
        record=packed[i*41:(i+1)*41]; raw=records[i*96:i*96+48]; air=records[i*96+48:(i+1)*96]
        lich=record[0]
        slots=[] if i in (0,8) else [2,3] if i==6 else [0,1] if i==7 else [0,1,2,3]
        quartet=[] if i in (0,8) else [0,1,2,3] if i==6 else [4,5,6,7] if i==7 else list(range((i-1)*4,i*4))
        truth.append({"raw":raw,"air":air,"lich":lich,"sacch":asbits(record[1:5])[:26],
                      "facch":asbits(record[5:15]),"slots":{s:quartet[s] for s in slots}})
    return truth,words,[asbits(channels[i*9:(i+1)*9]) for i in range(20)]


def source_frames(configuration):
    if configuration=="zero": return []
    if configuration=="single_weak": ids=[1]
    elif configuration.startswith("cold_"): ids=list(range(9))
    else: ids=[0]+list(range(9))
    return [{"ordinal":i,"source_frame":fid,"start":640+3840*i,
             "scored":configuration.startswith("cold_") or configuration=="single_weak" or i!=0,
             "bad_parity":configuration=="bad_lich" and i==2} for i,fid in enumerate(ids)]


def complete(call):
    return (call["eof_before"]==call["eof_after"]==0 and call["after"]-call["before"]==20
            and (call["symbol_after"]-call["symbol_before"]) & 0xffffffff == 1)


def coordinate(frame, sources, indices):
    calls=frame["end"]["body_calls"]
    if frame["begin"]["sync"]!=28 or any(i>=len(calls) or not complete(calls[i]) for i in indices): return None
    matches=[]
    for source in sources:
        delta=[calls[i]["after"]-(source["start"]+20*(11+i)) for i in indices]
        if all(-20<v<20 for v in delta): matches.append({**source,"phase_min":min(delta),"phase_max":max(delta)})
    if len(matches)>1: raise ValueError("Ambiguous source coordinates")
    return matches[0] if matches else None


def common(rows, chunk=False):
    ignored={"seq","frontier","pops","observed","crcs","skipped"}
    if chunk: ignored|={"provided","cache_pos","cache_len","read_start","chunk"}
    return [{k:v for k,v in row.items() if k not in ignored} for row in rows if row["kind"] not in DETAIL]


def inspect_raw(rows, pops, scenario, chunk, detail, samples, truth, words, channels):
    problems=[]; quality=[]
    def check(ok, reason):
        if not ok: problems.append(reason)
    check([r["seq"] for r in rows]==list(range(len(rows))),"event_sequence")
    check([r["kind"] for r in rows[:2]]==["configuration","initialized"] and [r["kind"] for r in rows[-2:]]==["completed","summary"],"boundaries")
    summary=rows[-1]
    check((summary["chunk"],summary["observed"],summary["fast"])==(chunk,detail,int(scenario in ("cold_fast","single_weak"))),"identity")
    check(summary["samples"]==samples and summary["eof"]==1 and summary["errors"]==summary["starts"]==summary["tunes"]==0,"native_summary")
    expected_pops=b"".join(struct.pack("<I",i) for i in range(samples)) if detail else b""
    check(pops==expected_pops,"finite_pop_trace")
    frames=[]; active=None
    for row in rows:
        if row["kind"]=="frame_begin":
            check(active is None,"nested_frame"); active={"begin":row,"events":[]}
        elif row["kind"]=="frame_end":
            if active is None: raise ValueError("Unowned frame end")
            active["end"]=row; frames.append(active); active=None
        elif active is not None: active["events"].append(row)
    check(active is None and len(frames)==summary["frames"],"frame_count")
    sources=source_frames(scenario); occurrences=[]; unsafe=[]; positions=[]; calls=collections.Counter()
    fec_flags=collections.Counter(); synthesis_flags=collections.Counter(); statuses=collections.Counter()
    call_classes=collections.Counter(); fully=[]; source_control=[]; routes_total=0
    for frame in frames:
        end=frame["end"]; count=end["body_count"]
        check(count==len(end["body"])==len(end["body_positions"])==len(end["body_calls"]),"body_lengths")
        previous=None
        for i,item in enumerate(end["body_calls"]):
            if previous is not None:
                check((item["before"],item["eof_before"],item["symbol_before"])==previous,"body_chain")
            previous=(item["after"],item["eof_after"],item["symbol_after"])
            if complete(item): kind="complete"
            else:
                delta=item["after"]-item["before"]
                check(item["eof_after"]==1 and item["after"]==samples and item["symbol_before"]==item["symbol_after"] and 0<=delta<20,"invalid_EOF_call")
                kind="partial" if delta else "empty"
            call_classes[kind]+=1
            check(end["body_positions"][i]==(item["after"] if kind=="complete" else 0),"source_position_truth")
        source=coordinate(frame,sources,list(range(8)))
        frame["source"]=source
        full=coordinate(frame,sources,list(range(count))) if count==182 else None
        if full:
            fully.append({"frame":frame["begin"]["frame"],**full})
            positions.append({"frame":frame["begin"]["frame"],"ordinal":full["ordinal"],"source_frame":full["source_frame"],
                              "first":end["body_calls"][0]["before"],"end":end["body_calls"][-1]["after"],
                              "phase_min":full["phase_min"],"phase_max":full["phase_max"]})
        if source:
            target=truth[source["source_frame"]]
            air=bytearray(target["air"])
            if source["bad_parity"]: air[4]^=0x20
            dibits=[(b>>shift)&3 for b in air for shift in (6,4,2,0)]
            if any(complete(c) and int(end["body"][i])!=dibits[10+i] for i,c in enumerate(end["body_calls"])):
                quality.append("source_body_bits")
            for event in frame["events"]:
                if event["kind"]=="crc":
                    info=target["sacch"] if event["channel"]==1 else target["facch"]
                    width=6 if event["channel"]==1 else 12
                    good=(event["bits"],event["computed"],event["received"])==(info,checksum(info,width),checksum(info,width))
                    source_control.append({"frame":frame["begin"]["frame"],"source_frame":source["source_frame"],"channel":event["channel"],"part":event["part"],"exact":good})
                    if not good: quality.append("source_control_bits")
        route=None; routes=[]
        for row in frame["events"]:
            kind=row["kind"]
            if kind=="route_begin":
                check(route is None,"nested_route"); route={"begin":row,"fec":[],"synthesis":[],"inputs":[]}
            elif kind=="route_end":
                if route is None: raise ValueError("Unowned route end")
                route["end"]=row; routes.append(route); route=None
            elif kind in ("fec","synthesis","fec_input"):
                if route is None: raise ValueError("Unowned API call")
                check(row["route_id"]==route["begin"]["route_id"],"route_identity")
                route[{"fec":"fec","synthesis":"synthesis","fec_input":"inputs"}[kind]].append(row)
        check(route is None,"unfinished_route")
        frame["routes"]=routes
        for route in routes:
            routes_total+=1; begin=route["begin"]; slot=begin["slot"]
            indices=list(range(38+36*slot,74+36*slot)); owned=all(i<count and complete(end["body_calls"][i]) for i in indices)
            if route["synthesis"] and not owned:
                unsafe.append({"frame":frame["begin"]["frame"],"route_id":begin["route_id"],"slot":slot,
                    "complete_dibits":sum(i<count and complete(end["body_calls"][i]) for i in indices),
                    "synthesis_calls":len(route["synthesis"]),"statuses":[r["status"] for r in route["synthesis"]]})
            for event in route["fec"]:
                calls[event["mode"]]+=1; calls["outer" if event["outer"] else "nested"]+=1
                statuses["fec:"+str(event["status"])]+=1
                if event["result"] is not None: fec_flags[str(event["result"]["flags"])]+=1
                check(event["input_unchanged"]==1,"FEC_input_mutation")
            for event in route["synthesis"]:
                calls["synthesis"]+=1; statuses["synthesis:"+str(event["status"])]+=1
                if event["result_after"] is not None: synthesis_flags[str(event["result_after"]["flags"])]+=1
                check(event["input_unchanged"]==1,"synthesis_input_mutation")
            identity=coordinate(frame,sources,list(range(8))+indices)
            if identity is None: continue
            target=truth[identity["source_frame"]]
            if slot not in target["slots"] or identity["bad_parity"]:
                quality.append("stolen_or_rejected_route"); continue
            sid=target["slots"][slot]; plain=descramble(end["body"],frame["begin"]["pn95"])
            channel="".join(format(v,"02b") for v in plain[indices[0]:indices[-1]+1])
            outer=[r for r in route["fec"] if r["outer"]]
            exact=channel==channels[sid] and len(outer)==1 and outer[0]["status"]>=0 and outer[0]["bits49"]==words[sid]
            exact=exact and len(route["synthesis"])==1 and route["synthesis"][0]["input49"]==words[sid]
            if detail:
                inputs=[r for r in route["inputs"] if r["outer"]]
                exact=exact and len(inputs)==1 and inputs[0]["channel72"]==channel
                if len(inputs)==1:
                    for p,value in enumerate(channel):
                        k=18*(p%4)+p//4
                        row,col=(0,23-k) if k<24 else (1,46-k) if k<47 else (2,57-k) if k<58 else (3,71-k)
                        exact=exact and inputs[0]["matrix96"][24*row+col]==value
            if not exact: quality.append("source49_route_mismatch")
            occurrences.append({**identity,"slot":slot,"source_id":sid,"exact":bool(exact),
                                "first":end["body_calls"][indices[0]]["before"],"end":end["body_calls"][indices[-1]]["after"],
                                "decoded_statuses":[r["status"] for r in outer],"synthesis_statuses":[r["status"] for r in route["synthesis"]]})
        if any(r["begin"]["confirmed"]!=1 for r in routes): quality.append("unconfirmed_voice")
    check(routes_total==summary["route_words"],"route_total")
    check(calls["synthesis"]==summary["synthesis_calls"] and calls["soft"]==summary["fec_soft_calls"] and calls["hard"]==summary["fec_hard_calls"],"API_totals")
    identity_pairs=[(r["ordinal"],r["slot"]) for r in occurrences]
    if len(set(identity_pairs))!=len(identity_pairs): quality.append("duplicate_occurrence")
    h1=None
    transitions=[]
    if scenario=="primed":
        scored=[r for r in fully if r["scored"]]
        expected=[(s["ordinal"],slot,sid) for s in sources if s["scored"] for slot,sid in truth[s["source_frame"]]["slots"].items()]
        actual=[(s["ordinal"],s["slot"],s["source_id"]) for s in occurrences if s["scored"]]
        h1=([r["source_frame"] for r in scored]==list(range(9)) and actual==expected and len(actual)==24 and not quality)
        header=next((f for f in frames if f["source"] and f["source"]["ordinal"]==1),None)
        trailer=next((f for f in frames if f["source"] and f["source"]["source_frame"]==8),None)
        first=next((f for f in frames if f["source"] and f["source"]["source_frame"]==1),None)
        def clear(call):
            return call is not None and (call["phase"],call["kind"],call["source"],call["target"],call["crypto"],call["algid"],call["kid"],call["audio_permitted"])==(1,2,901,1201,1,0,0,1)
        header_call=header["end"].get("call") if header else None
        trailer_call=trailer["end"].get("call") if trailer else None
        h1=bool(h1 and header and header["end"]["value"]==2 and clear(header_call) and first and first["end"]["ran"]==1
            and trailer_call and (trailer_call["epoch"],trailer_call["phase"],trailer_call["end_reason"],trailer_call["media_active"],trailer_call["audio_permitted"])==(header_call["epoch"],2,3,0,0))
        for frame in frames:
            if frame["source"]:
                transitions.append({"source_frame":frame["source"]["source_frame"],"ordinal":frame["source"]["ordinal"],
                                    "call":frame["end"].get("call"),"ran":frame["end"]["ran"],"frame_result":frame["end"]["value"]})
                if frame["source"]["scored"] and 1<=frame["source"]["source_frame"]<=7:
                    h1=bool(h1 and all(clear(r["begin"].get("call")) and r["begin"]["call"]["epoch"]==header_call["epoch"] for r in frame["routes"]))
    negative=None
    if scenario=="single_weak" and detail:
        exposed=[f for f in frames if f["source"] and f["source"]["source_frame"]==1 and len(f["end"]["body_calls"])==182 and all(map(complete,f["end"]["body_calls"]))]
        negative=len(exposed)==1 and not routes_total and not calls["synthesis"]
        if exposed:
            crcs=[r for r in exposed[0]["events"] if r["kind"]=="crc"]
            negative=bool(negative and exposed[0]["end"]["confirmed"]==0 and len(crcs)==1 and crcs[0]["computed"]==crcs[0]["received"])
    elif scenario=="bad_lich" and detail:
        exposed=[f for f in frames if f["source"] and f["source"]["bad_parity"]]
        negative=len(exposed)==1 and not exposed[0]["routes"]
        if exposed:
            lich=[r for r in exposed[0]["events"] if r["kind"]=="lich"]
            negative=bool(negative and len(lich)==1 and lich[0]["reason"]=="parity_reject")
    elif scenario=="zero":
        negative=not routes_total and not any(f["end"]["value"]==2 or f["end"]["confirmed"] for f in frames)
    return {"measurement_errors":problems,"quality_observations":quality,"h1_primed_pass":h1,"h3_negative_pass":negative,
            "h4_finite_voice_safety_pass":not unsafe,"unsafe_synthesis":unsafe,"source_occurrences":occurrences,
            "fully_supplied_frames":fully,"source_positions":positions,"source_control":source_control,"transitions":transitions,
            "counts":{"frames":len(frames),"routes":routes_total,**dict(calls)},"call_classes":dict(call_classes),
            "status_histogram":dict(statuses),"fec_flags":dict(fec_flags),"synthesis_flags":dict(synthesis_flags),
            "common":common(rows),"chunk_common":common(rows,True),"pop_sha256":sha(pops)}


def main():
    if not (STUDY/"report.json").is_file(): raise ValueError("Completed study is required; never launch a receiver here")
    report_raw=(STUDY/"report.json").read_bytes(); report=parse(report_raw)
    if len(report.get("attempts",[]))!=36 or "comparison" not in report or "files" not in report:
        raise ValueError("Sole matrix is not finalized; wait for root completion")
    before=parse((STUDY/"before-execution.json").read_bytes()); manifest=parse((STUDY/"inputs/manifest.json").read_bytes())
    truth,words,channels=oracle(STUDY/"inputs")
    assertions=[]
    def check(ok,label,detail=None): assertions.append({"pass":bool(ok),"label":label,"detail":detail})
    groups={}
    for name in ("frozen_files","original_files","copied_identities","configured_sources","protected"):
        wrong=[]
        for path,digest in before[name].items():
            p=Path(path)
            if not p.is_file() or sha(p.read_bytes())!=digest: wrong.append(path)
        groups[name]={"count":len(before[name]),"mismatches":wrong}; check(not wrong,"preservation:"+name,wrong)
    wrong=[]
    for relative,digest in report["files"].items():
        p=(STUDY/relative).resolve()
        if not p.is_relative_to(STUDY.resolve()) or not p.is_file() or sha(p.read_bytes())!=digest: wrong.append(relative)
    check(not wrong,"reported_output_hashes",wrong)
    expected=[(s,c,d) for s,_,_ in CONFIGURATIONS for c in (37,512) for d in (0,1)]
    check([(a["id"],a["observed"]) for a in report["attempts"]]==[(f"{s}-c{c}",d) for s,c,d in expected],"exact_ordered_attempt_matrix")
    attempts=[]; evidence={}; detailed_totals=collections.Counter(); all_totals=collections.Counter()
    for scenario,chunk,detail in expected:
        cid=f"{scenario}-c{chunk}"; folder=STUDY/"runs"/cid/str(detail)
        process=parse((folder/"process.json").read_bytes()); invocation=parse((folder/"invocation.json").read_bytes())
        root_case=next(c for c in manifest["cases"] if c["id"]==cid)
        wave=manifest["waveforms"][root_case["waveform"]]
        args=invocation["arguments"]
        check(args[2:5]==[str(root_case["fast"]),str(chunk),str(detail)] and Path(args[1]).read_bytes()==(STUDY/"inputs"/wave["file"]).read_bytes(),"actual_forwarding:"+cid+f":{detail}")
        rows=[parse(line) for line in (folder/"events.jsonl").read_bytes().splitlines()]
        pops=(folder/"pops.u32le").read_bytes()
        result=inspect_raw(rows,pops,scenario,chunk,detail,wave["samples"],truth,words,channels)
        result.update(id=cid,observed=detail,native_exit=process.get("exit_code"))
        check(process.get("exit_code")==0 and not result["measurement_errors"],"raw_measurement:"+cid+f":{detail}",result["measurement_errors"])
        all_totals.update(result["counts"])
        if detail: detailed_totals.update(result["counts"])
        evidence[(scenario,chunk,detail)]=result; attempts.append(result)
    for scenario,_,_ in CONFIGURATIONS:
        for chunk in (37,512):
            a,b=[evidence[(scenario,chunk,d)] for d in (0,1)]
            check(a["common"]==b["common"],"detail_neutrality:"+scenario+f":{chunk}")
        for detail in (0,1):
            a,b=[evidence[(scenario,c,detail)] for c in (37,512)]
            check(a["chunk_common"]==b["chunk_common"] and a["pop_sha256"]==b["pop_sha256"],"chunk_neutrality:"+scenario+f":{detail}")
    h1=all(r["h1_primed_pass"] is not False for r in attempts)
    h3=all(r["h3_negative_pass"] is not False for r in attempts)
    h4=all(r["h4_finite_voice_safety_pass"] for r in attempts)
    check(report["comparison"]["finite_voice_safety_pass"]==h4,"reported_H4_matches_independent")
    check(report["comparison"]["negative_pass"]==h3,"reported_H3_matches_independent")
    check(not report["product_promotion"],"no_product_promotion")
    # Store bounded observed identities/statuses but not a second full raw stream.
    for result in attempts:
        result.pop("common"); result.pop("chunk_common")
    out={"schema":1,"audit_pass":all(a["pass"] for a in assertions),"assertions":len(assertions),
         "failures":[a for a in assertions if not a["pass"]],"study":str(STUDY),"source_imports":[],
         "native_invocations_by_audit":0,"report_sha256":sha(report_raw),"preservation":groups,
         "output_hashes_checked":len(report["files"]),"raw_attempts":36,"detailed_attempts":18,
         "all_attempt_totals":dict(all_totals),"detailed_totals":dict(detailed_totals),
         "independent_h1_primed_pass":h1,"independent_h3_negative_pass":h3,"independent_h4_finite_voice_safety_pass":h4,
         "reported_measurement_pass":report["measurement_pass"],"reported_progression_pass":report["progression_pass"],
         "reported_comparison":report["comparison"],"attempts":attempts,
         "scope":"Known clear source positions/49-bit routing and actual API observations. No speech, playback, RF, speed or encryption claim."}
    OUTPUT.with_suffix(".json").write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:out[k] for k in ("audit_pass","assertions","failures","raw_attempts","detailed_totals","independent_h1_primed_pass","independent_h3_negative_pass","independent_h4_finite_voice_safety_pass")}))


if __name__=="__main__": main()
