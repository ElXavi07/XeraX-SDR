XeraX clear NXDN48 routing evidence, 25 September 2026
Registration d98ccd3; frozen harness 9fd7e2c859b356b3e697ce95b800ca60e9c60bbc.
Exactly 36 Windows receiver processes; all exited zero. Measurement passes,
routing and negative exposure gates FAIL. No product promotion or new app build.
Existing public fast option routed 24 known words versus default 8 on one cold
fixture; 320 ms earlier in source-stream time, not measured CPU/RF/app speed.
EOF prefixes contain no voice calls: active-voice EOF safety was not exercised.
Source word 19 has an ERASURE synthesis flag. Exact bits are not accepted speech.
The frozen flag counterexample used wrong constants; the explicitly post-execution
supplement checks actual 32/64/128 masks without changing any frozen outcome.

study/ contains every native attempt, immutable input, raw events and pop trace,
frozen observer/checker sources, research executable/runtime DLLs and identities.
These tools are not a phone APK or Windows app installer. The source baseline is
https://github.com/ElXavi07/XeraX-SDR/tree/289a82f8fd9c0495b64bf948fd45413bc63261c4
Toolchain/system libraries are identified; Windows system DLLs are prerequisites.
publication/ includes independent audits, the supplemental coverage limitation,
CI and outer execution logs. These post-execution items were not pre-execution evidence.

Offline review without running native code: import analyze from
study/frozen/source_repository/experiments/nxdn_clear_routing_v1; keep this hierarchy.
Call validate_inputs(study/inputs), then inspect(rows, trace_path, case, manifest,
inputs, detail) for every saved events.jsonl and pops.u32le; compare the full grid.
The archive checker should reproduce measurement=true, progression=false.
Absolute identities refer to the study machine and are not rewritten on extraction.
Windows-relative report paths use backslashes. Archive names use forward slashes.
No speech, playback, I/Q, RF, privacy, GPU or whole-app performance claim.
