# Independent clear NXDN routing design review

2026-09-25. Read-only review at repository HEAD `289a82f8fd9c0495b64bf948fd45413bc63261c4`. Reviewed `build/nxdn-clear-routing-v1-design.md`, the draft `docs/research/NXDN-CLEAR-ROUTING-V1-PREREGISTRATION-2026-09-25.md`, real receiver source and observation-v2's finite-input contract. No corpus generation, native invocation, build, production edit or historical-evidence change occurred.

## Conclusion

The proposed nine configurations / eight waveforms / 36 fresh processes form a feasible bounded observation study. The revised registration correctly separates actual source-bit routing, detail/chunk neutrality, negative controls and finite-EOF synthesis safety. Static feasibility is not an outcome prediction. The existing receiver may fail any receiver-quality hypothesis, including H4, without making faithfully recorded evidence invalid.

No unresolved prerequisite requires changing the fixed corpus or weakening a gate. The implementation and independent checker must retain the ordering and attribution constraints below.

## Consequential finding corrected in the draft

The initial design could be read as requiring live `nxdn_last_ran == 1` on the first strong header. That is too early: `nxdn_decode_control_channels` processes SACCH before FACCH; the first valid SACCH records weak evidence but writes live RAN only when already confirmed. The subsequent FACCH can confirm and publish VCALL. Source RAN 1 should be checked from the header's independently known SACCH, and live RAN 1 at the next valid SACCH processed after confirmation. The revised registration states this distinction explicitly. See `nxdn_deperm.c:288-307,315-355` and `nxdn_frame.c:497-568,608-680`.

## Required source and event ordering

- Final CRC callbacks precede `nxdn_confirm_note_evidence`. A correct callback can therefore show the previous confirmation state. Confirm evidence application at the subsequent route/frame boundary, without relabeling the earlier callback. FACCH's final callback also precedes duplicate suppression and element dispatch (`nxdn_deperm.c:1187-1204`). Two identical full-header FACCH CRC passes do not require two call publications.
- `nxdn_frame` consumes all 182 body dibits before control and voice processing. All four AMBE words can share the same current vocoder cursor. Attribute each route using its parent body's own calls and actual `nxdn_search_voice_index`, never the cursor at synthesis (`nxdn_frame.c:608-680`; `nxdn_voice.c:35-90`).
- The actual route uses a non-null reliability array. It principally exercises real soft FEC; zero hard calls is valid. Nested decoder calls need parent/depth identities and cannot create extra transmitted occurrences.
- `processMbeFrameInternal` marks call media before FEC. It can create a generic call if no active compatible call exists. Cold acquisition may therefore expose a generic identity before a later decoded VCALL. Do not impose the primed-header metadata expectation on every cold route. Media-active state alone proves neither exact bits nor successful synthesis (`dsd_mbe.c:1931-1970`).
- `dsd_call_state_get` returns 0 if no epoch exists and may leave an output object untouched when the extension is absent. Zero a private snapshot, honor the return, and emit `call:null` for absence. The read uses an existing extension and does not create one. End reason is semantically meaningful only for an ended call. Exclude clocks/padding from exact cross-run comparison (`core/util/call_state.c:863-878`; `core/call_state.h:184-225`).
- A real TX_REL can end the known epoch without resetting NXDN sticky confirmation. The end operation is idempotent for an already-ended call. Require the actual final logical transition, not a guessed count of internal end-function calls. Actual no-carrier reset remains separate (`call_state.c:801-859`; `nxdn_confirm.c`; `nxdn_deperm.c:1289-1306`).

## H4 is a valid quality gate with a narrow meaning

H4 must ask whether each actual synthesis call's **own 36-dibit voice interval** is fully supplied, independently of whether later parts of its parent frame have reached EOF. A complete early word may legitimately be processed after the handler has discovered EOF in later slots. Conversely, partial/empty calls in that word's own interval must fail finite voice safety if synthesis is invoked, even if returned bits, PCM or flags appear plausible.

Preserve every call and return status. Do not suppress calls, pad the provider, substitute silence or fabricate positions to satisfy H4. A violation establishes that this finite discriminator-provider route passed unavailable source material into synthesis; it does not prove actual speaker playback or intelligible wrong speech. The registered cut lengths are exposure tests, not a guarantee that sampling phase lands exactly at their nominal boundary. Partial/empty calls require the real no-commit/EOF contract, and complete calls require one symbol commit plus 20 actual delivered samples under this fixed profile.

The testable gate is not the tautology “the checker refused to credit EOF.” It independently counts real synthesis invocations and fails when their own source interval is unavailable. Clean 24-occurrence routing and finite safety remain distinct results; the aggregate includes both without retroactive relaxation.

## Independent checker obligations

1. Require all 36 registered identities once and preserve every native failure, malformed record, incidental synchronization, decoder call and negative return. Detail mode on/off has common FEC, synthesis, route and logical call-state records; detailed source/matrix/CRC telemetry augments them. This establishes detail-callback neutrality only, not a wholly uninstrumented comparison.
2. Credit source identity by unique parent/source coordinates and slot before comparing bits. The 24 transmitted occurrences contain only 20 distinct source words; repeated words 2,3,4,5 are deliberate. Matching a 49-bit word is insufficient identity evidence.
3. Preserve exact full/receiver LICH and slot layout: header/trailer `0x83/0x41`, pure voice `0xAE/0x57` slots 0..3, FACCH-first `0xA6/0x53` slots 2,3, FACCH-second `0xAA/0x55` slots 0,1. The old v2 checker has a narrower profile set and must remain unchanged.
4. Validate real input mutation, matrix/channel placement and independently known channel/49-bit truth. A nonnegative FEC/synthesis status is not accepted speech. Do not read the caller's uninitialized result before decode; negative output/result is unavailable. Preserve ERASURE/REPEAT/MUTE/substitution indications without turning them into speech evidence.
5. A single-weak negative requires actual accepted source LICH and a valid SACCH exposure before claiming the intended unconfirmed behavior. Bad-LICH requires the intended rejection. No exposure is a failed/inconclusive control, not a passing negative. Preserve subsequent incidental frames and quality failures.
6. Canonical frame/slot ownership requires source-complete body calls and the registered strict phase window `-20 < deviation < 20`. Reject ambiguous mappings; do not assign missing samples by read-ahead, copied previous frontier or slot output matching.
7. Exact detail/chunk comparisons must remove only registered provider/detailed fields. PCM contents remain descriptive because the registration does not seed the vocoder RNG; do not add PCM equality as an unstated gate. Named logical status fields and source bits remain comparable.

## Implementation preflight still required

Actual wrapper forwarding, real archive ownership, relocations/link map, no LTO bypass, fixed source hashes, bounded event capacities, strict event grammar and failure persistence must be reviewed after the private recorder exists. A source-level wrapper declaration alone does not establish that the intended real function was intercepted. Detailed matrix/CRC observations must never be fabricated in observation-off records. The final schema should distinguish admitted common calls, nested calls, unavailable output and finite-source ownership explicitly.

The proposed scope can establish known clear bits traversing a specific production decoder/synthesis route. It cannot establish valid original speech, application audio output, RF acquisition, general NXDN conformance, speed or encrypted-traffic capability. No additional corpus or outcome-dependent tuning is recommended for this registration.
