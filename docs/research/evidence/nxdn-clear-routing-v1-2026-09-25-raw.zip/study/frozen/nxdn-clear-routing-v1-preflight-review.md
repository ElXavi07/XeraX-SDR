# Clear routing v1: independent pre-execution review

2026-09-25. Read-only review of the registered runner, seven mocked runner tests, actual generated recorder, private-source identity and registration, finalized at frozen harness commit `9fd7e2c859b356b3e697ce95b800ca60e9c60bbc`. No receiver/native executable, build, historical matrix or generator was invoked. No checker or recorder source was edited during this review.

## Conclusion and prerequisites

No new source-backed execution blocker was found in the reviewed runner or wrappers. Proceed only after the parent's independent build/linkage audit passes, the harness/checker files are committed and the runner's pre-launch identity gates pass. The build-audit JSON had not yet been written at the point of this review; this review does not replace the mandatory symbol/archive/runtime audit.

The finite matrix remains 18 registered cases times two detail modes, one invocation per identity. H1 known clear routing, H2 detail/chunk neutrality, H3 negative controls and H4 slot-specific finite voice safety remain separate. A measurement-valid H4 failure is an intended possible outcome and must remain a progression failure. No receiver result has informed this review.

## Runner and preservation

- `invoke()` forwards the exact registered waveform path, fast option, chunk, detail mode and trace destination without a shell. It strips case-insensitive `DSD_*` overrides and uses a 60-second timeout. The actual option values are written to an invocation record.
- A successfully returned native exit code is persisted to `process.json` before checker code runs. Timeout/launch/checker/JSON exceptions retain partial stdout, stderr, failure traceback and an audit record; no retry loop exists. The parent loop continues to the next distinct identity following a recorded native or evidence failure.
- Directory creation uses `exist_ok=False`, preventing reuse of a completed or partial native identity. Source drift in `checked_invoke()` blocks further native launches rather than pretending the remaining cases are comparable.
- Before execution, the runner requires the fixed input manifest, independently reconstructed inputs, a committed experiment, unchanged registered production source and a passing build audit. It checks the audited executable and runtime/dependency identities, freezes actual copies, and rechecks originals, copied identities, configured source files, earlier protected evidence and live Python files before each call.
- The intended preflight correction is now present: `LIVE` captures the actual `source_truth.py` and frozen finite helper in addition to runner/analyzer/preparer. The analyzer's finite helper hash is also verified at load time. No missing dynamic Python helper was found in the current guard.
- Measurement depends on all 36 successful, validly analyzed attempts and final preservation. Quality failures remain in per-case audits and comparison results. Exit success is tied to measurement integrity rather than silently demanding positive receiver quality; `progression_pass` and permanent `product_promotion:false` remain explicit.
- The copy policy excludes an in-progress outer execution log and copies completed preflight reviews/logs only. This avoids treating bytes written by the outer shell after runner finalization as frozen pre-execution content.

The intended output is a new sibling study directory. This is not a generic hostile-filesystem runner: it does not promise safe operation with its output nested inside an input/build/source tree, concurrent hostile filesystem replacement, or a compromised trusted build-audit JSON. Use the registered separate output location; these exclusions do not weaken its fixed-study identity checks.

## Actual recorder and source identity

The current `generated/source-identity.json` was checked against disk: all **13 original source hashes, three observation source hashes and seven generated-file hashes match**. The generated observer retains the real live-loop call, original dispatcher/frame implementation, real no-carrier, finite provider and actual radio-context creation/destruction. Only the public fast option differs per case. The reviewed configured observer/core compile entries contain the research observation macros and real `dsd_mbe.c`; they do not by themselves prove final archive ownership, which remains the parent's separate linkage gate.

The generated provider sets EOF only after real finite delivery is exhausted, preserves zero-length returns and records actual pop indices. It does not append EOF samples. Body positions require the actual symbol-counter commit and no EOF; the checker must continue using per-slot body calls rather than the shared cursor at synthesis. Exact input truth is absent from the native recorder.

The wrapper implementation forwards each original call once with the original pointers and real return value. Hard/soft inputs are copied before the real call and compared afterward. Output49/result fields are emitted only for nonnegative decoder status. The synthesis wrapper reads the preceding result context only after successful outer decode and only when the actual pointer matches; it records named fields, not padding. The context can legitimately have been modified by the receiver before synthesis; this is visible evidence for quality assessment. Negative synthesis results emit no guessed after-result. Calls made with unavailable EOF source slots are preserved.

Call snapshots use a zero-initialized local and the actual `dsd_call_state_get` return. They omit wall clocks and do not create epochs. Media-active is correctly treated as pre-FEC state, not speech proof. The final logical/ownership checks run before state destruction, and post-destruction summary printing does not dereference the freed receiver state.

The preflight generated-source correction/failed snapshot is retained by the parent; this review uses the corrected current generated hash below. It does not erase or reinterpret the earlier build failure as a successful execution.

## Tests and portability scope

The runner tests use temporary directories and mocks; they exercise refusal of an existing identity, fast/chunk/detail forwarding, environment removal, timeout byte retention, checker exceptions after native exit persistence, nonzero native exit, changed-source launch blocking and strict duplicate/nonfinite/malformed JSON rejection. They do not invoke the native receiver. The frozen finite helper's working bytes equal its Git blob, and `.gitattributes` disables text conversion; its fixed hash is therefore not tied to Windows CRLF conversion.

The registered native executable path is intentionally Windows `.exe`. Mocked framework tests are portable; this review makes no claim that the Windows native batch ran on another platform. Native stdout is finite-bounded by recorder event/sample capacities; optional PCM statistics remain descriptive and excluded from common neutrality. No speech, playback, complex-IQ, encryption, speed or full-application conclusion follows.

## Reviewed identities

- Registration: `39d080fcfd680176f420c4313e61e582b062300b6f572aa57b3b4145dc1fc251`.
- Runner after LIVE expansion: `dda9b2c98e1c02e0132dba86e467b8858a771d82598d0f627e7265af3d28fe0f`.
- Runner tests: `3367010532804e875ab854477b05740df57095d82992fb7799c64234966752ac`.
- Wrapper: `9459b0f168e47511beb2f4bb66832fff5f9ff8542f40725c93187d197eb8a192`.
- Generated observer: `76c6c78813ce8de97ac6b1eb51d2b1386a8f0ce87beeedd1c2dcd0427836fba2`.
- Analyzer: `6241cd1596f2a5b1ef87ce017e3083283cc12af43af2fed10bbcd5e5b7fe0009`.
- Independent input helper: `28f92b0a021a971d355085fd3876d25e5e055e7bdf31dee714b562cd385d47ea`.
- Frozen finite helper: `bef0e7614fb39e9e0491ed422822710a780e245f6e70361bfeae73f2d3786198`.

Source changes after these identities require the relevant preflight/freeze checks again; this is a bounded review of these bytes, not blanket approval of later revisions.
