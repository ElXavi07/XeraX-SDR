"""Read-only clear-routing source/COFF/PE audit; never execute the receiver.

Only llvm-nm/llvm-objdump inspect stored binaries. No compiler, linker, DLL
loader, fixture generator, matrix runner, or earlier study main is invoked.
"""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BUILD = Path(os.environ['LOCALAPPDATA']) / 'XeraXSDR-build/nxdn-clear-routing-v1-20260925'
INSTALLED = Path(os.environ['LOCALAPPDATA']) / 'XeraXSDR-build/lab-installed/x64-mingw-static'
OUT = ROOT / 'build/nxdn-clear-routing-v1-build-audit'
BASELINE = '289a82f8fd9c0495b64bf948fd45413bc63261c4'
PARSER_SHA = '771f7d520ca6783aaa4a0b8e45a52e41bcd7004cc8b8bbb028e4d8c274ac6595'
MBE_SHA = '28007fa92e61618526c876656291d671f7d8bf41cc5ff8117bbe6702ac95088f'
MBE_HEADER_SHA = '800093e90ee74abb9564dc66f63a5c3334689deeb947f5a0b2aa80384c49612c'


def need(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def text(path):
    return Path(path).read_text(encoding='utf-8').replace('\r\n', '\n')


def replace_one(value, before, after=''):
    need(value.count(before) == 1, 'audit inverse seam not unique: ' + before[:80])
    return value.replace(before, after)


def run_inspector(program, *args):
    result = subprocess.run([str(program), *map(str, args)], capture_output=True, text=True, check=True)
    return result.stdout


def cache_values():
    result = {}
    for line in text(BUILD / 'CMakeCache.txt').splitlines():
        match = re.match(r'^([^#/:][^:]*):[^=]+=(.*)$', line)
        if match:
            result[match[1]] = match[2]
    return result


def audit_sources():
    generated = BUILD / 'generated'
    identity = json.loads((generated / 'source-identity.json').read_bytes())
    need(identity['source_commit'] == BASELINE, 'wrong product baseline')
    need(identity['v2_recorder_commit'] == 'a07b3ab37ffcdc127d40fad9a48a043c6ffcb3f7', 'wrong V2 provenance')
    need(len(identity['original_sources']) == 13, 'original source inventory differs')
    for category, base in (('original_sources', ROOT), ('observation_sources', ROOT), ('generated_sources', generated)):
        for relative, expected in identity[category].items():
            need(digest(base / relative) == expected, 'source changed: ' + relative)
    for relative, expected in identity['original_sources'].items():
        raw = subprocess.check_output(['git', 'show', BASELINE + ':' + relative], cwd=ROOT)
        need(hashlib.sha256(raw).hexdigest() == expected, 'baseline Git bytes differ: ' + relative)

    engine = text(generated / 'engine_observed.c')
    engine = replace_one(engine, '#include "observer_api.h"\n#define getFrameSync xerax_record_sync\n#define processFrame xerax_record_dispatch\n')
    engine = replace_one(engine, '\nvoid xerax_run_live_loop(dsd_opts* opts, dsd_state* state) { live_scanner_main_loop(opts, state); }\n')
    engine = replace_one(engine, 'void\nxerax_real_noCarrier(dsd_opts* opts, dsd_state* state)',
                         'void\nnoCarrier(dsd_opts* opts, dsd_state* state)')
    need(engine == text(ROOT / 'upstream/dsd-neo/src/engine/engine.c'), 'private engine contains more than declared observation seams')

    frame = text(generated / 'nxdn_frame_observed.c')
    frame = replace_one(frame, '#include "observer_api.h"\n')
    frame, count = re.subn(r'^[ \t]*xerax_v2_lich\(state, "(?:parity_reject|direction_reject|unsupported_profile|accepted)",[^\n]+\);\n', '', frame, flags=re.M)
    need(count == 4, 'wrong LICH hook count')
    # The regex may consume only blank whitespace before hook lines; normalize
    # blank-line whitespace for the inverse comparison, not any C tokens.
    original_frame = text(ROOT / 'upstream/dsd-neo/src/protocol/nxdn/nxdn_frame.c')
    need(frame.splitlines() == original_frame.splitlines(), 'private frame has undeclared changes')

    deperm = replace_one(text(generated / 'nxdn_deperm_observed.c'), '#include "observer_api.h"\n')
    deperm = replace_one(deperm, '    const int v2_soft_pass = crc == check;\n')
    deperm = replace_one(deperm, '    xerax_v2_scch(state, trellis_buf, crc, check, v2_soft_pass, direction);\n\n')
    need(deperm == text(ROOT / 'upstream/dsd-neo/src/protocol/nxdn/nxdn_deperm.c'), 'private channel decoder has undeclared changes')
    dispatch = replace_one(text(generated / 'dispatch_observed.c'), '#include "observer_api.h"\n#define nxdn_frame xerax_record_frame\n')
    need(dispatch == text(ROOT / 'upstream/dsd-neo/src/engine/dispatch/dispatch_nxdn.c'), 'dispatcher differs beyond observer redirection')
    need(text(generated / 'v2_observer_extra.inc') == text(ROOT / 'experiments/nxdn_observation_v2/observer_extra.inc'), 'frozen V2 forwarding changed')

    observer = text(generated / 'observer.c')
    old = text(ROOT / 'experiments/nxdn_engine_gap/observer.c')
    v2_tree = ast.parse(text(ROOT / 'experiments/nxdn_observation_v2/prepare_build.py'))
    candidates = [n.value for n in ast.walk(v2_tree) if isinstance(n, ast.Constant) and isinstance(n.value, str)
                  and len(n.value) > 100 and n.value.startswith('int\n__wrap_getDibitSoft(')]
    need(len(candidates) == 1, 'frozen V2 body-call seam not found uniquely')
    start, end = observer.index('int\n__wrap_getDibitSoft('), observer.index('int __wrap_rtl_stream_start')
    need(observer[start:end] == candidates[0], 'finite body-call wrapper differs from frozen V2')
    old_start, old_end = old.index('int\n__wrap_getDibitSoft('), old.index('int __wrap_rtl_stream_start')
    observer = observer[:start] + old[old_start:old_end] + observer[end:]
    for before, after in (
        ('static void routing_snapshot(const dsd_state* state);\n\n', ''),
        ('    routing_snapshot(s);\n', ''),
        ('#include "observer_extra.inc"\n\n', ''),
        ('    printf("]"); v2_dump_body_calls(); printf("}\\n");\n    return result;', '    printf("]}\\n");\n    return result;'),
        ('    opts.use_cosine_filter = 0; opts.msize = 1; opts.ssize = 128; opts.datascope = 0;',
         '    opts.use_cosine_filter = 0; opts.msize = 1; opts.ssize = 128;'),
        ('    routing_configuration(&opts, &state);\n', ''),
        ('    printf(",\\"observation_schema\\":2,\\"datascope\\":%d,\\"pulse_digi_rate_out\\":%d,\\"floating_point\\":%d,\\"dmr_stereo\\":%d",\n'
         '           opts.datascope, opts.pulse_digi_rate_out, opts.floating_point, opts.dmr_stereo);\n', ''),
        ('    routing_final_check();\n', ''),
        ('    routing_summary();\n', ''),
        ('    printf(",\\"v2_lich_events\\":%u,\\"v2_scch_events\\":%u,\\"v2_voice_calls\\":%u,\\"v2_mbe_calls\\":%u,\\"v2_audio_calls\\":%u",\n'
         '           v2_lich_events, v2_scch_events, v2_voice_calls, v2_mbe_calls, v2_audio_calls);\n', ''),
    ):
        observer = replace_one(observer, before, after)
    need(observer == old, 'recorder differs beyond enumerated V2/routing observation additions')

    extra = text(ROOT / 'experiments/nxdn_clear_routing_v1/observer_extra.inc')
    need(not re.search(r'\b(?:state|opts)->\w+\s*=(?!=)', extra), 'observer writes receiver field')
    need('mbe_setThreadRngSeed' not in extra, 'observer changes RNG seed')
    need('status >= 0 ? output : NULL' in extra and 'status >= 0 ? result : NULL' in extra, 'negative output guard absent')
    need('result == routing_word.decode_result' in extra, 'uninitialized synthesis context guard absent')
    for symbol in ('mbe_decodeAmbe3600x2450Frame', 'mbe_decodeAmbe3600x2450SoftFrame', 'mbe_processAmbe2450Dataf'):
        match = re.search(r'^__wrap_' + symbol + r'\([^\n]*(?:\n[^\n]*)*?\n\}', extra, flags=re.M)
        need(match and match.group().count('__real_' + symbol + '(') == 1, 'real API does not forward once: ' + symbol)
    return identity


def pe_and_map_parsers():
    source_path = ROOT / 'build/nxdn-voice-words-v1-preflight-audit.py'
    need(digest(source_path) == PARSER_SHA, 'prior read-only parser changed')
    source = text(source_path)
    scope = {'need': need, 'Path': Path, 'struct': struct}
    selected = 0
    for node in ast.parse(source).body:
        if isinstance(node, ast.FunctionDef) and node.name in ('pe_imports', 'map_owners'):
            code = ast.get_source_segment(source, node)
            code = code.replace('line.strip().endswith(symbol)',
                '(len(line.split(maxsplit=3)) == 4 and line.split(maxsplit=3)[3] == symbol)')
            exec(compile(code, str(source_path), 'exec'), scope)
            selected += 1
    need(selected == 2, 'parser inventory changed')
    return scope['pe_imports'], scope['map_owners'], source_path


def main():
    binary = BUILD / 'xerax_nxdn_clear_routing_v1.exe'
    link_map = BUILD / 'clear-routing.map'
    need(binary.is_file() and link_map.is_file(), 'completed EXE/map are not yet available')
    initial_binary = digest(binary)
    identity = audit_sources()
    pe_imports, map_owners, parser_source = pe_and_map_parsers()
    cache = cache_values()
    commands_path = BUILD / 'compile_commands.json'
    commands = json.loads(commands_path.read_bytes())
    need(commands and all('-flto' not in c['command'].lower() for c in commands), 'LTO configured')
    forbidden = ('XERAX_FIRST_CANONICAL_NXDN48', 'XERAX_NXDN_BOUNDARY')
    need(all(not any(re.search(r'[-/]D' + name, c['command']) for name in forbidden) for c in commands), 'private policy configured')
    objdump, nm = Path(cache['CMAKE_OBJDUMP']), Path(cache['CMAKE_NM'])
    compiler = Path(cache['CMAKE_C_COMPILER'])
    ninja = text(BUILD / 'build.ninja')
    block = re.search(r'^build xerax_nxdn_clear_routing_v1.exe:.*?(?=\n\n)', ninja, flags=re.M | re.S).group()
    need('-flto' not in block.lower(), 'link LTO configured')
    wraps = ('getDibitSoft', 'nxdn_voice', 'processMbeFrameSoft', 'processMbeFrame', 'processAudio',
        'mbe_decodeAmbe3600x2450Frame', 'mbe_decodeAmbe3600x2450SoftFrame', 'mbe_processAmbe2450Dataf',
        'rtl_stream_start', 'rtl_stream_tune', 'rtl_stream_tune_tagged', 'rtl_stream_output_rate', 'rtl_stream_request_fsk_reacquire')
    need(set(re.findall(r'--wrap=([\w]+)', block)) == set(wraps), 'link wrapper inventory differs')
    libraries = re.search(r'^  LINK_LIBRARIES = (.+)$', block, flags=re.M).group(1).split()
    archives = sorted({(Path(p) if Path(p).is_absolute() else BUILD / p).resolve() for p in libraries if p.endswith('.a')})
    need(all(p.is_file() for p in archives), 'linked archive absent')
    archive = INSTALLED / 'lib/libmbe-neo-static.a'
    need(archive.resolve() in archives and digest(archive) == MBE_SHA, 'real previous-study mbelib archive differs')
    mbe_header = INSTALLED / 'include/mbelib-neo/mbelib.h'
    need(digest(mbe_header) == MBE_HEADER_SHA, 'mbelib API header differs')
    defined = run_inspector(nm, '--defined-only', '--print-file-name', archive)
    mbe_functions = ('mbe_decodeAmbe3600x2450Frame', 'mbe_decodeAmbe3600x2450SoftFrame', 'mbe_processAmbe2450Dataf')
    definitions = [line for line in defined.splitlines() if any(line.endswith(' ' + s) for s in mbe_functions)]
    need(len(definitions) == 3 and all('ambe3600x2450.c.obj:' in x and ' T ' in x for x in definitions), 'mbelib real definitions missing or duplicated')

    owner_expectations = {
        'main': 'generated/observer.c.obj:(.text)',
        'xerax_run_live_loop': 'generated/engine_observed.c.obj:(.text)',
        'xerax_real_noCarrier': 'generated/engine_observed.c.obj:(.text)',
        'noCarrier': 'generated/observer.c.obj:(.text)',
        'dsd_dispatch_handle_nxdn': 'generated/dispatch_observed.c.obj:(.text)',
        'nxdn_frame': 'nxdn_frame_observed.c.obj:(.text)',
        'nxdn_deperm_facch_soft': 'nxdn_deperm_observed.c.obj:(.text)',
        'nxdn_deperm_sacch_soft': 'nxdn_deperm_observed.c.obj:(.text)',
        'nxdn_voice': 'nxdn_voice.c.obj:(.text)',
        'processMbeFrameSoft': 'dsd_mbe.c.obj:(.text)',
        'processMbeFrame': 'dsd_mbe.c.obj:(.text)',
        'processMbeFrameInternal': 'dsd_mbe.c.obj:(.text)',
        'decode_ambe2450_frame': 'dsd_mbe.c.obj:(.text)',
        'processAudio': 'dsd_audio.c.obj:(.text)',
        'getDibitSoft': 'dsd_dibit.c.obj:(.text)',
        'getFrameSync': 'dsd_frame_sync.c.obj:(.text)',
        'getSymbol': 'dsd_symbol.c.obj:(.text)',
        **{s: 'ambe3600x2450.c.obj:(.text)' for s in mbe_functions},
        **{'__wrap_' + s: 'generated/observer.c.obj:(.text)' for s in wraps},
    }
    owners = map_owners(link_map, owner_expectations)
    for symbol, suffix in owner_expectations.items():
        need(len(owners[symbol]) == 1 and owners[symbol][0].replace('\\', '/').endswith(suffix), 'wrong mapped symbol owner: ' + symbol + ' ' + repr(owners[symbol]))
    map_text = text(link_map)
    need('dsd_test_first_canonical_nxdn48_enabled' not in map_text and 'phase_policy' not in map_text
         and 'phase_runtime' not in map_text, 'private acquisition/boundary implementation linked')

    def command_path(command, field):
        path = Path(command[field])
        return path if path.is_absolute() else Path(command['directory']) / path

    def object_for(name, target=None):
        choices = [c for c in commands if Path(c['file']).name == name and (target is None or target in c['output'])]
        need(len(choices) == 1, 'source/object identity ambiguous: ' + name)
        p = command_path(choices[0], 'output')
        need(p.is_file() and p.read_bytes()[:2] == b'\x64\x86', 'expected actual AMD64 COFF object: ' + str(p))
        return p

    critical_objects = {
        'observer': object_for('observer.c', 'xerax_nxdn_clear_routing_v1'),
        'engine': object_for('engine_observed.c'), 'dispatch': object_for('dispatch_observed.c'),
        'frame': object_for('nxdn_frame_observed.c'), 'channel': object_for('nxdn_deperm_observed.c'),
        'voice': object_for('nxdn_voice.c', 'dsd-neo_proto_nxdn'),
        'vocoder': object_for('dsd_mbe.c', 'dsd-neo_core'),
        'dibit': object_for('dsd_dibit.c', 'dsd-neo_core'),
        'sync': object_for('dsd_frame_sync.c', 'dsd-neo_dsp_private_test_support'),
        'symbol': object_for('dsd_symbol.c', 'dsd-neo_dsp_private_test_support'),
        'audio': object_for('dsd_audio.c', 'dsd-neo_core'),
    }
    relocations = {}
    expected_relocations = {
        'vocoder': mbe_functions,
        'voice': ('processMbeFrameSoft', 'processMbeFrame'),
        'frame': ('getDibitSoft', 'nxdn_voice'),
        'dispatch': ('xerax_record_frame',),
        'observer': tuple('__real_' + s for s in wraps if s not in ('rtl_stream_start', 'rtl_stream_tune', 'rtl_stream_tune_tagged')),
    }
    for key, wanted in expected_relocations.items():
        rows = run_inspector(objdump, '-r', critical_objects[key]).splitlines()
        selected = [line for line in rows if any(line.split() and line.split()[-1] == symbol for symbol in wanted)]
        need(all(any(line.split()[-1] == s and 'IMAGE_REL_AMD64_REL32' in line for line in selected) for s in wanted), 'actual call relocation missing: ' + key)
        relocations[key] = selected

    # Observe final resolved call destinations, not merely link flags or names.
    disassembly_symbols = tuple('__wrap_' + s for s in mbe_functions) + (
        'decode_ambe2450_frame', 'processMbeFrameInternal', 'nxdn_voice')
    disassembly = run_inspector(objdump, '--disassemble-symbols=' + ','.join(disassembly_symbols), binary)
    functions = {}
    current = None
    for line in disassembly.splitlines():
        match = re.match(r'^[0-9a-fA-F]+ <(.+)>:$', line)
        if match:
            current = match.group(1); functions.setdefault(current, [])
        elif current and re.search(r'\b(?:callq?|jmpq?)\s', line):
            functions[current].append(line.strip())
    final_calls = {}
    for name in mbe_functions:
        wrapper = '__wrap_' + name
        rows = [line for line in functions.get(wrapper, []) if re.search(r'<' + re.escape(name) + r'>$', line)]
        need(len(rows) == 1, 'final wrapper does not call real mbelib exactly once: ' + name)
        final_calls[wrapper] = rows
        callers = {symbol: [line for line in lines if '<' + wrapper + '>' in line]
                   for symbol, lines in functions.items() if symbol != wrapper and any('<' + wrapper + '>' in line for line in lines)}
        expected_caller = 'processMbeFrameInternal' if name == 'mbe_processAmbe2450Dataf' else 'decode_ambe2450_frame'
        need(expected_caller in callers, 'required real vocoder function does not call final wrapper: ' + name)
        final_calls['callers_of_' + wrapper] = callers
    for original, wrapper in (('nxdn_voice', '__wrap_processMbeFrameSoft'), ('nxdn_voice', '__wrap_processMbeFrame')):
        rows = [line for line in functions.get(original, []) if '<' + wrapper + '>' in line]
        need(rows, 'real nxdn_voice bypasses route observer: ' + wrapper)
        final_calls[original + '_to_' + wrapper] = rows

    sysroot = Path(re.search(r'--sysroot=([^ ]+)', commands[0]['command']).group(1))
    system = Path(os.environ['SystemRoot']) / 'System32'
    search = [BUILD, sysroot / 'bin', INSTALLED / 'bin', system]
    pending, graph, runtime, os_names = [binary], {}, {}, set()
    while pending:
        path = pending.pop().resolve()
        if str(path) in graph:
            continue
        imports = pe_imports(path); graph[str(path)] = imports
        for name in imports:
            if name.lower().startswith(('api-ms-', 'ext-ms-')):
                os_names.add(name); continue
            resolved = next((directory / name for directory in search if (directory / name).is_file()), None)
            need(resolved is not None, 'unresolved PE import: ' + name)
            if resolved.parent.resolve() == system.resolve():
                os_names.add(name)
            else:
                resolved = resolved.resolve(); runtime[str(resolved)] = digest(resolved); pending.append(resolved)

    dep_paths = set(archives + list(critical_objects.values()))
    dep_paths.update([Path(__file__), parser_source, binary, link_map, commands_path,
        BUILD / 'CMakeCache.txt', BUILD / 'build.ninja', BUILD / 'CMakeFiles/rules.ninja', BUILD / 'toolchain.cmake'])
    # Runtime binaries are pinned separately, but all original/generated sources,
    # actual built translation-unit source files and critical headers are frozen.
    dep_paths.update(ROOT / p for group in ('original_sources', 'observation_sources') for p in identity[group])
    dep_paths.update((BUILD / 'generated').glob('*'))
    built_commands = [c for c in commands if command_path(c, 'output').is_file()]
    need(len(built_commands) >= len(critical_objects), 'built object source inventory is unexpectedly empty')
    dep_paths.update(command_path(c, 'file') for c in built_commands)
    dep_paths.update(Path(cache[name]) for name in ('CMAKE_C_COMPILER', 'CMAKE_CXX_COMPILER', 'CMAKE_AR', 'CMAKE_LINKER', 'CMAKE_NM', 'CMAKE_OBJDUMP', 'CMAKE_MAKE_PROGRAM', 'CMAKE_TOOLCHAIN_FILE'))
    dep_paths.update([mbe_header,
        INSTALLED / 'share/mbe-neo/vcpkg-spdx-resources.json', INSTALLED / 'share/mbe-neo/vcpkg.spdx.json',
        INSTALLED / 'share/mbe-neo/mbe-neoTargets-release.cmake',
        ROOT / 'build/mbelib-voice-words-v1-source.tar.gz',
        ROOT / 'upstream/dsd-neo/vcpkg-ports/mbe-neo/portfile.cmake',
        ROOT / 'docs/research/NXDN-CLEAR-ROUTING-V1-PREREGISTRATION-2026-09-25.md'])
    dep_paths.update(ROOT / 'upstream/dsd-neo/include/dsd-neo/core' / p
        for p in ('call_state.h', 'state.h', 'opts.h', 'vocoder.h', 'key_presence.h', 'dibit.h'))
    dep_paths.update(ROOT / 'upstream/dsd-neo/src/protocol/nxdn' / p for p in ('nxdn_test_support.h', 'nxdn_confirm.h'))
    dep_paths.update(ROOT / 'upstream/dsd-neo/src/dsp' / p for p in ('symbol_test_support.h',))
    dep_paths.update([ROOT / 'build' / p for p in (
        'nxdn-clear-routing-v1-build.log', 'nxdn-clear-routing-v1-build-corrected.log',
        'nxdn-clear-routing-v1-configure.log', 'nxdn-clear-routing-v1-configure.ps1',
        'nxdn-clear-routing-v1-preflight-corrections.log',
        'nxdn-clear-routing-v1-build-audit-initial.py',
        'nxdn-clear-routing-v1-build-audit-development.txt',
        'nxdn-clear-routing-v1-build-audit-first-pass.json',
        'nxdn-clear-routing-v1-build-audit-first-pass.md')])
    dep_paths.update(p for p in (ROOT / 'build/nxdn-clear-routing-v1-preflight-build-failure').rglob('*') if p.is_file())
    need(all(p.is_file() for p in dep_paths), 'dependency missing')
    dependencies = {str(p.resolve()): digest(p) for p in sorted(dep_paths)}
    need(digest(binary) == initial_binary, 'executable changed during audit')
    result = {'schema': 1, 'source_and_linkage_pass': True, 'native_execution': False,
        'binary_sha256': initial_binary, 'binary_bytes': binary.stat().st_size,
        'configured_translation_units': len(commands), 'existing_built_object_translation_units': len(built_commands),
        'linked_archive_inputs': len(archives), 'dependencies': dependencies, 'runtime_files': runtime,
        'original_source_hashes': identity['original_sources'], 'source_identity': identity,
        'map_symbol_owners': owners, 'mbelib_definition_evidence': definitions,
        'object_relocation_evidence': relocations, 'final_resolved_calls': final_calls,
        'binary_import_graph': graph, 'system_runtime_prerequisites': sorted(os_names),
        'runtime_search_directories': [str(p) for p in search],
        'private_source_inverse_comparison_pass': True, 'no_lto_or_private_policy': True,
        'preflight_corrections': [
            'Before source generation/build, a manually transcribed nxdn_voice.c source hash was 62 hex characters; the read-only source-pin preflight rejected it. Corrected to the actual 64-character baseline Git/disk hash before configure. No inputs or native executions preceded correction.',
            'The initial build failed because generated/dispatch_observed.c could not find protocol_dispatch_impl.h. The source CMake include path was corrected to include src/engine/dispatch, and the corrected build passed. Original generated sources/configuration and both logs are retained and hashed. No receiver invocation occurred.',
            'The first read-only audit AST selector matched both a short getDibitSoft search literal and the complete wrapper literal. Its script and failure diagnostic are retained; selection now requires the full function string. The resulting full-disassembly audit passed and its first report is retained. Final audit narrows disassembly to the required real callers/wrappers and explicitly resolves compile-command relative paths. No product/harness input or binary was changed.'],
        'limits': ['No receiver executable or DLL was executed or loaded; llvm tools inspect stored bytes only.',
            'Configured command count is not claimed to be actual compiled count; existing COFF objects and mapped definitions are separately inspected.',
            'PE import resolution uses the stated explicit search directories; the runner must preserve/copy this DLL closure. Windows OS DLLs remain prerequisites; no loader smoke test.',
            'Source/linkage audit does not establish future receiver outcomes, observer neutrality, clear routing or finite-EOF safety.',
            'Mutable current runner/checker files are excluded and must be frozen separately by the runner.']}
    OUT.with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    OUT.with_suffix('.md').write_text(
        '# Clear routing v1 pre-execution build audit\n\nPASS: source and linkage checks passed without executing the receiver.\n\n'
        f'Executable SHA-256: `{initial_binary}` ({result["binary_bytes"]:,} bytes). '
        f'{len(commands)} configured translation units; {len(built_commands)} existing object translation units; '
        f'{len(archives)} explicit linked archive inputs; {len(runtime)} non-system runtime DLLs. '
        'Configured sources are not equated to compiled/link-selected objects.\n\n'
        'All 13 pinned originals match disk and registered baseline Git bytes. Inverse comparison removes only the declared engine/frame/channel/dispatcher observation seams and recovers the original sources. '
        'The finite body-call wrapper exactly matches the frozen V2 implementation. '
        'Mapped real engine, sync, symbol, dibit, dispatch, frame, voice, vocoder, audio and mbelib definitions are recorded. '
        'Object relocations plus final resolved calls demonstrate both FEC wrappers and the synthesis wrapper forward to the installed mbelib archive used by the earlier word study. '
        'No LTO, private first-canonical prototype or failed boundary policy is configured/linked.\n\n'
        'Before configure, a 62-character manual source-hash transcription was rejected and corrected to the baseline 64-character hash. No receiver or fixture outcome was involved. '
        'The old map-parser suffix ambiguity is avoided by exact symbol-field comparison, as in AIR v1.\n\n'
        'The initial build failed on the missing private dispatcher include directory. Root added src/engine/dispatch; the successful build and original failure logs/configuration are preserved and hashed. '
        'The first auditor run rejected an ambiguous AST literal selector; its original script/diagnostic are retained. The selector was restricted to the complete function. A full-disassembly pass is retained; the final checker explicitly requires the real vocoder caller names and resolves object paths against each compile-command directory.\n\n'
        'No DLL was loaded. The resolved non-system PE closure is pinned for the runner; OS DLLs remain prerequisites. '
        'The current runner and checker are intentionally outside these build dependencies until their own freeze. '
        'This audit proves identity/observation linkage, not runtime decoding, neutrality, speech or finite-EOF safety.\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in ('source_and_linkage_pass', 'binary_sha256', 'configured_translation_units', 'existing_built_object_translation_units', 'linked_archive_inputs')}, indent=2))


if __name__ == '__main__':
    main()
