# Clear routing v1 pre-execution build audit

PASS: source and linkage checks passed without executing the receiver.

Executable SHA-256: `6682f833c9c9a9ec23b596af2c8fe3f176de28134a90f3f487e8ab996b464704` (10,646,528 bytes). 1341 configured translation units; 354 existing object translation units; 36 explicit linked archive inputs; 4 non-system runtime DLLs. Configured sources are not equated to compiled/link-selected objects.

All 13 pinned originals match disk and registered baseline Git bytes. Inverse comparison removes only the declared engine/frame/channel/dispatcher observation seams and recovers the original sources. The finite body-call wrapper exactly matches the frozen V2 implementation. Mapped real engine, sync, symbol, dibit, dispatch, frame, voice, vocoder, audio and mbelib definitions are recorded. Object relocations plus final resolved calls demonstrate both FEC wrappers and the synthesis wrapper forward to the installed mbelib archive used by the earlier word study. No LTO, private first-canonical prototype or failed boundary policy is configured/linked.

Before configure, a 62-character manual source-hash transcription was rejected and corrected to the baseline 64-character hash. No receiver or fixture outcome was involved. The old map-parser suffix ambiguity is avoided by exact symbol-field comparison, as in AIR v1.

The initial build failed on the missing private dispatcher include directory. Root added src/engine/dispatch; the successful build and original failure logs/configuration are preserved and hashed. The first auditor run rejected an ambiguous AST literal selector; its original script/diagnostic are retained. The selector was restricted to the complete function. A full-disassembly pass is retained; the final checker explicitly requires the real vocoder caller names and resolves object paths against each compile-command directory.

No DLL was loaded. The resolved non-system PE closure is pinned for the runner; OS DLLs remain prerequisites. The current runner and checker are intentionally outside these build dependencies until their own freeze. This audit proves identity/observation linkage, not runtime decoding, neutrality, speech or finite-EOF safety.
