# Ownership/observation correctness evidence, 25 September 2026

These are functional and fault-injection tests, NOT an isolated performance
screen. Some executions overlapped builds. Do not rank their timing values.
The slab core is synchronous and has no request coordinator or live integration.

raw/candidate and raw/baseline preserve final observer test CSV/stdout/stderr.
Numbered files are real executable observations. Named modified CSV files are
deliberately corrupted or shifted-origin validator fixtures; their expected
outcomes are specified in test_observed_latency.py. Failed injected runs must
remain ineligible for performance claims. Their failures are intentional.
Earlier baseline validation failures are kept in logs: signed offsets from a
future origin were initially rejected, and a later test assumed zero always
reverses a timestamp. Final tests fix both assumptions without changing old runs.
Public logs replace local repository paths; original local log hashes are in
the accompanying JSON. No phone execution, APK or application EXE is included.

Run the standalone core with its CMakeLists.txt and CTest. Build the observation
harness with the included credit/history sources and XERAX_CHUNK_COPY=1 for the
current candidate. The frozen library/new observer compiles without that macro.
Set XERAX_OBSERVED_EXE to a built observer and run Python unittest discovery for
test_observed_latency.py. Required frozen/candidate source hashes and executable
hashes are in the accompanying report; binaries are not part of this archive.
