# Independent observation-v2 input audit â€” 2026-09-25

**Input preflight passes.** All nine waveforms, 18 base cases and 36 planned
invocations agree with the preregistered construction. No native process was run;
no receiver outcome, successful voice decode or measurement pass is inferred.
Only the ignored independent audit artifacts were written.

The companion Python oracle imports no preparer, decoder or production encoder.
It uses polynomial long division for CRC7, explicit four-bit convolution history
instead of the generator's packed-register parity masks, matrix transposition,
nine separate PN stages, and prefix sums for waveform shaping. It checks exact
bytes and metadata, not only the preparer's stored hash strings.

## Frozen controls

The independent full-frame constants were calculated and reported before the new
generator's output was inspected. They match the actual generated vectors:

| Control | Computed CRC7 | Transmitted CRC7 | Complete 192-dibit SHA-256 |
| --- | ---: | ---: | --- |
| `scch_valid` | 17 | 17 | `e49e9872c987d580c76ba274aca18137767ca9db452a8e6f0a508a156411b4c1` |
| `scch_wrong` | 17 | 81 | `fb1afd6934f61d552131f84a635789fbae9d57f8537527cc9edc59cbeed00137` |

Each has 25 zero information bits, seven check bits and four convolutional tail
bits; 72 coded bits become 60 punctured/interleaved bits. Exact mapping is
`transmitted[j] = punctured[(j % 5) * 12 + floor(j / 5)]`. This equation avoids
ambiguity about which matrix dimension is called a row or a column.

The full LICH is 0xEF, profile 0x77 with valid parity. The 144 voice dibits are zero
before whitening. They are **synthetic observation slots, not validated speech**.
A passing SCCH check only establishes the deliberately known channel information
and checkword; it cannot establish AMBE, voice, audio or standards-conformance
correctness.

The two new `CCSSVV` waveforms independently reconstruct to 24,960 float samples
each. Their first 16,000 samples exactly match the frozen parent `CCSS` prefix.
Shaping uses the explicit `[i-4,i+3]` eight-sample window, endpoint extension and
the +8000 dibit-zero trailer. Both new origin maps are exact identity maps and
both occurrence maps are zero.

## Primary corroboration and its limit

The [DSD-FME primary implementation at commit 719d9709](https://github.com/lwvmobile/dsd-fme/blob/719d9709e6d4c738be70183616b7b87081b50776/src/nxdn_deperm.c#L291)
implements SCCH CRC7 with seven one-initialized stages and feedback equivalent to
`x^7+x^3+1`. [Its SCCH check gate](https://github.com/lwvmobile/dsd-fme/blob/719d9709e6d4c738be70183616b7b87081b50776/src/nxdn_deperm.c#L888)
uses 25 information bits followed by seven received check bits. The retrieved
whole-file SHA-256 was
`aae26e450b73a5b74db70e6ee8e0cb99c6e6115e77aa9dfab4b8bc54b34e3c0f`.
Independent polynomial division agrees with a simultaneous-register expression
of that primary recurrence for empty, all-zero, all-one and both alternating
25-bit controls. Empty CRC is 127, alternating starting 1 is 16, and all-zero 25-bit is 17.

This corroborates the declared arithmetic, but DSD-FME and the receiver share
ancestry. It is **not an independent standards authority or independent decoder
certification**. The pinned MMDVM-Host primary CRC source at
`590c531391dfd3146073afbc3956f70d42c62a46` supports the prior CRC6/CRC12 oracle but
does not expose this SCCH CRC7; inspected NXDN files in osmocom/op25 commit
`6f1b25d2d1a48e8afadeb14446c2ba426c310ed7` and dsdcc commit
`f27b32d2df131ae3a376fe72d3fb880ae1f9ede1` also did not supply that corroboration.
The new preregistration correctly calls these observation fixtures rather than
standards-conformance vectors.

## Complete input and matrix checks

The three copied parent waveforms, all associated maps/originals, their frame
metadata and the two h0 control vectors match the prior independent preflight
hashes and bytes exactly. The four cuts at 12360, 12361, 12380 and 12521 are exact
byte prefixes of the old clean waveform, with no padding or reshaping. Their
identity origin and zero occurrence maps have exactly the delivered prefix length.

Prefix metadata keeps nominal source-frame boundaries from the original waveform.
Some nominal ends exceed the finite prefix length by design; these descriptors
must never be mistaken for complete delivered frame availability. The new EOF
measurement contract must establish full/partial/empty symbol consumption from
actual events. This audit confirms the cut coordinates, not a future receiver's
behavior at those coordinates.

All 35 generated files (manifest included) are accounted for with no extras or
missing files. Exact binary comparisons cover 2,761,752 bytes. The nine waveform
names each appear once per chunk 37/512 with acquisition fixed 0. Expanding detailed
observation 0/1 gives exactly 36 unique planned invocations. The companion JSON
retains each planned identity and every file hash, plus the generator,
preregistration and parent-manifest hashes. The original parent preflight remains
unchanged. Native results must be recorded separately and may still fail.
