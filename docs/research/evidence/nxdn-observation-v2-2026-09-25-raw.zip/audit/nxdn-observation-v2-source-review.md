# Bounded SCCH / LICH / voice observation review — 2026-09-25

Recommendation: build a new isolated observation contract around the unchanged
receiver, with four required event families: selected/rejected LICH, final SCCH
checkword, actual voice-call boundaries, and audio-staging writes. Record vocoder
return status if interpreting synthesis, and treat PCM energy as optional. This
is observability work, not a proposed voice gate or decoder improvement. Preserve
the published recovery matrix and its failed conditions unchanged.

No native process or test was executed in this review; no product, previous
experiment, vector, build target or evidence was edited. Only this ignored note
was written. Source snapshot: repository commit
`938c5fe8a24719dbfad510bc536f1084de650a1a`.

## Smallest truthful seams

| Event | Exact source seam | What it establishes |
| --- | --- | --- |
| `lich_decision` | Private copy of `nxdn_frame.c`: after parity/direction/profile decision, before remaining-body reads; emit an outcome for rejection too | Actual received full byte/profile, parity result, direction result, selected profile flags and reason for rejection |
| `scch_final` | `nxdn_deperm_scch_soft`, immediately after the optional hard fallback has supplied final `trellis_buf`, `crc` and `check`, before payload-seed reset, `note_evidence` or `NXDN_decode_scch` | Final 25 information bits, final seven received check bits, computed CRC7, final equality, soft-pass/fallback and routing direction |
| `voice_begin` / `voice_end` | A link wrapper around real `nxdn_voice`, forwarding once with unchanged arguments | Whether voice processing actually ran, requested half/both selection, input reliability presence, before/after confirmation/evidence and indices |
| `audio_stage_begin` / `audio_stage_end` | Wrapper around real `processAudio` / `processAudioR`, forwarding once; optionally an explicit post-emitter event inside a private source copy | Actual staging call and before/after pointer/index movement; native-rate output writes can be counted at the emitter rather than inferred from final frame counters |

For the LICH event, include `frame_id`, `full_lich`, `profile`, parity computed and
received, nullable direction/profile decision status, `voice`, `facch`, `scch`,
`sacch`, `idas`, `pich_tch` and the other existing profile bits. Emit exactly once
for every LICH collection, including parity failure, direction failure and
unsupported profile. Do not re-run `nxdn_apply_lich_profile` to obtain diagnostics;
retain the actual result from the original call. A name string alone is weaker
than the numeric selector and flags. Unknown/unexecuted checks must be null or
explicitly skipped, not marked passed.

The selected-profile event occurs before optional LimeZulu processing later in
the frame. If that feature is enabled, record the effective voice flags again at
the actual voice decision; otherwise explicitly freeze it off. Keep the existing
voice decision unchanged. A skipped `voice_begin` is meaningful only if a frame
completion/decision event and a no-overflow trace establish that the path was
observed and deliberately not called.

For SCCH, snapshot the first soft result before fallback only to name
`soft_crc_pass` truthfully. Log the **final** 32 decoded bits after fallback as
25 information plus seven check bits. `computed == received` is the actual
acceptance condition. Tail bits are not included. The current final SCCH gate is
at `nxdn_deperm.c:1479–1498`; check bits come from positions 25..31 through
`nxdn_scch_crc7_check_from_trellis` (`nxdn_dcr_utils.c:13`). Emit before any state
mutation so existing confirmation accounting remains reconstructible. A final
SCCH equality is evidence about that codeword, not proof that it is the expected
transmitted source content; compare the information and received checkword to
independent fixture truth as a separate test.

Do not extend old schema enums silently. Use a new schema and explicit channel
name/CRC width. An omitted SCCH event is not a failed CRC. The validator should
know whether the selected profile calls SCCH and require the corresponding event,
or flag the observation incomplete. CRC failure, unsupported format, rejected
LICH and source exhaustion need distinct outcomes.

## Voice and sample observability

`nxdn_frame.c:554–569` gates `nxdn_voice` on the selected voice flag and sticky
confirmation, not on fresh proof from this frame. In the retained failure,
profile 0x77 selects SCCH and voice=3. `nxdn_voice.c:42–53` requests two AMBE blocks
for voice=1/2 or four for voice=3; each real call must retain its index 0..3 and
parent frame/voice-call identity. Preserve both hard and soft call paths.

The next minimum seam is wrapping `processMbeFrame` / `processMbeFrameSoft` to
record entry/exit and the enclosing AMBE block. Forward exactly once. These APIs
return void: a completed call alone is **not** a successful vocoder decode. If
the experiment reports synthesis status, observe the actual results from
`mbe_decodeAmbe3600x2450Frame` / `mbe_decodeAmbe3600x2450SoftFrame` and
`mbe_processAmbe2450Dataf` without invoking them again. Their arguments/results
are available at external-library call boundaries. Match every return to its
parent AMBE block. Only read result fields guaranteed valid for that return code;
on negative status, leave unavailable flags/check statistics explicitly absent.

This matters because `store_process_result` in `dsd_mbe.c:138` substitutes silence
and clears error fields after a negative return. `errs == errs2 == 0` therefore
does not prove successful decoding. Erasure/repeat/mute/tone context also matters;
the upstream [mbelib-neo API documentation](https://github.com/arancormonk/mbelib-neo/blob/main/README.md)
distinguishes staged decoding from synthesis and describes these result flags.
That live primary page was checked on 2026-09-25; pin the actually linked library
version/source/library hash rather than assuming its main branch matches the
frozen binary.

At 8000 output samples/s, `dsd_audio_emit_native_left` writes 160 int16 samples
and increments both left indices (`dsd_audio.c:543–555`). `playSynthesizedVoiceMS`
resets the working index and clears temporary buffers (`dsd_audio2.c:1140`), so
frame-end indices miss intermediate work. A wrapper must record before playback
clears the data. If using a direct emitter hook, pass the exact bounded written
span and count after original writes; do not derive an unchecked pointer from a
potentially wrapped index. For other rates, record actual counts/upsampling mode;
do not assume every staging call wrote 160 samples. Include ring reset markers.

Optional PCM diagnostics should contain the sample domain (`codec_float`,
`post_gain_float`, or `staged_s16`), exact count, finite/nonfinite count, zero/nonzero
count, peak and double-accumulated energy. Snapshot after the relevant successful
operation and before playback/reset. On a failed operation, distinguish substituted
silence or unavailable output from successful synthesis. State the float scale;
mbelib's float API is not normalized to [-1,1]. Avoid one undifferentiated `audio`
metric combining pre-gain and post-gain samples.

No nonzero-energy threshold establishes speech correctness. Random, concealed,
repeated or wrong AMBE parameters can produce finite nonzero samples; silence can
be legitimate. Exact PCM equality across independent runs also needs declared
library state, RNG seed, compiler/SIMD and floating-point policy. The primary
mbelib documentation describes per-thread RNG seeding and SIMD-dependent rounding.
If such control is not already part of the frozen profile, energy is descriptive,
not an observer-parity quality oracle or a reason to modify historical fixtures.

Keep `audio_out=0`, null WAV/MBE output handles, no active device stream and no
network audio output. Preserve real playback routine execution if it is part of
the original path; inspect/count the final output API boundary and require no
actual output attempts. Do not replace voice/playback with silent stubs and then
claim the real pipeline stayed silent. A call to a function named `play...` is
not an actual write: `dsd_output_s16_block`/`dsd_output_float_block` return early
when output is disabled (`dsd_audio2.c:181–205`). Any unexpected sink write should
abort the isolated experiment and fail its side-effect contract.

## Controls and available truth

| Control | Already available | Legitimate conclusion |
| --- | --- | --- |
| Frozen valid/bad-all-CRC/wrong-LICH control frames | Independent `experiments/nxdn_frames/generate_vectors.py` and frozen vector artifacts | Retain exact LICH/SACCH/FACCH bits, final gates and rejection paths; no valid voice claim |
| Held-out clean/corrupted-header sequences | Preserved recovery input set, including warm_drop20 and its occurrence maps | Recorder can expose known profile0x41 → observed0x77 transition without redefining it as valid speech |
| Empty/zero/EOF controls | Existing finite fixtures and forthcoming EOF contract | No fictitious input sample attribution; absence of hooks is not enough without completion/coverage checks |
| Voice routing/map unit fixtures | `test_nxdn_voice_mapping.c`, `test_nxdn_frame_routing.c` | Wrapper cardinality, hard/soft mapping, two/four subframe handling; their vocoder/playback spies are not real PCM/voice proof |
| CRC7 primitive fixtures | `test_nxdn_deperm_primitives.c`, `test_nxdn_dcr_utils.c` | Arithmetic/extraction cross-checks only; not independently encoded SCCH air truth |
| Lower-level AMBE words in `tests/engine/nxdn_search_voice.c` | Fixed49-bit words, production Golay encode and real MBElib checks | Candidate plumbing control, not independent NXDN SCCH/voice over-air ground truth; do not reuse its search/key setup in this clear observation experiment |

A useful new direct SCCH control can be independently encoded as 25 information
bits +7 check bits +4 tail bits, convolution/interleave/puncture as the declared
profile requires. The current CRC7 register recurrence corresponds to polynomial
`x^7 + x^3 + 1` with all-ones initialization; verify that independently (for example
long division) and against an external primary encoder/specification before
calling a full air vector standards-grounded. Current primitive goldens are empty
CRC=127 and alternating25-bit pattern starting1 CRC=16. They come from the same
receiver tree, so they are useful regression checks but are not independent
protocol validation by themselves. A wrong-checkword variant must preserve the
information bits and flip a check bit before encoding.

No independently grounded, clean SCCH-plus-AMBE speech air fixture was established
by this audit. Do not treat arbitrary payload bits with a voice LICH as a positive
voice-retention oracle. First increment may truthfully test **observation of the
retained bad transition** plus direct SCCH/voice plumbing, while leaving valid
voice quality/retention unestablished. Any future guard requires an independent
legitimate control-to-voice transition and supported voice format cases before it
can be considered an improvement.

## Isolation, cardinality and falsifiers

Use new private instrumented source copies or uniquely gated new research hooks.
Do not edit the released native source or old evidence. Assert source substitutions
match exactly once, preserve original function calls/return values, and retain
link maps proving wrappers resolved to real implementations. Link wrapping does
not intercept every same-object/internal call; map/symbol proof is required.
Provide bounded per-run event storage, explicit overflow/error status, and stable
frame/block/call IDs. Callbacks copy borrowed bytes synchronously, never retain
source pointers, mutate decoder state, reenter decode or print inside a hot seam.

Before interpreting any new event, compare observation off/on using the same
frozen input and compare common outcomes, consumed-pop traces, resets and real
output side effects. Add negative trace controls for missing/duplicate SCCH,
wrong frame/block IDs, before/after inversion, fabricated writes, invalid check
lengths, unexpected sink activity and trace overflow. Missing observation must
fail measurement, not appear as no voice/no error. The new EOF contract must
mark returned symbols that consumed no actual input; optional audio events must
inherit source-truncation flags and cannot turn EOF-generated data into a valid
voice frame.

Required falsifiers: a hook alters common decoder outcomes; an observed event
cannot be paired with exactly one real operation; a voice profile has missing
status/coverage; final decoded bits/checkword disagree with independently expected
truth; or an output sink is invoked. Measurement failure remains distinct from
receiver quality failure. No timing, RF, app, decryption or speed claims follow
from this observation contract.

## Exact reviewed source hashes (SHA-256)

```text
nxdn_deperm.c  fca07d14eeefb128dddcd70dded0630f85f704643f5aac45e9ce92959e820010
nxdn_frame.c   a2c0d15efd6258c1469df2ebbb7dea05400f9e0ab74fba653c1e20125f04919a
nxdn_voice.c   4e56a528681b11f4f694a1b7f1d1f4cbeb6866fda8ff6b95d2116bc9d23dc675
dsd_mbe.c     6d46d12147e041123bd66654435c8dfc0f503e0faa43b1dfb933078604dad96c
dsd_audio.c   dc2a7c6c76be8b3220444c14a2f70f405819f70dbbf78c317723553b582769a3
dsd_audio2.c  26940bba57f68898c2254c41f5da78128fe642d215061c016031acca61d8f00e
```
