#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mbe_neo::mbe-static" for configuration "Release"
set_property(TARGET mbe_neo::mbe-static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(mbe_neo::mbe-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libmbe-neo-static.a"
  )

list(APPEND _cmake_import_check_targets mbe_neo::mbe-static )
list(APPEND _cmake_import_check_files_for_mbe_neo::mbe-static "${_IMPORT_PREFIX}/lib/libmbe-neo-static.a" )

# Import target "mbe_neo::mbe-shared" for configuration "Release"
set_property(TARGET mbe_neo::mbe-shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(mbe_neo::mbe-shared PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libmbe-neo.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/libmbe-neo.dll"
  )

list(APPEND _cmake_import_check_targets mbe_neo::mbe-shared )
list(APPEND _cmake_import_check_files_for_mbe_neo::mbe-shared "${_IMPORT_PREFIX}/lib/libmbe-neo.dll.a" "${_IMPORT_PREFIX}/bin/libmbe-neo.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
