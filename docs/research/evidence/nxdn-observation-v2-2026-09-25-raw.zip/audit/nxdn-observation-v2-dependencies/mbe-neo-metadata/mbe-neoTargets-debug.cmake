#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debug".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mbe_neo::mbe-static" for configuration "Debug"
set_property(TARGET mbe_neo::mbe-static APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBUG)
set_target_properties(mbe_neo::mbe-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_DEBUG "C"
  IMPORTED_LOCATION_DEBUG "${_IMPORT_PREFIX}/debug/lib/libmbe-neo-static.a"
  )

list(APPEND _cmake_import_check_targets mbe_neo::mbe-static )
list(APPEND _cmake_import_check_files_for_mbe_neo::mbe-static "${_IMPORT_PREFIX}/debug/lib/libmbe-neo-static.a" )

# Import target "mbe_neo::mbe-shared" for configuration "Debug"
set_property(TARGET mbe_neo::mbe-shared APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBUG)
set_target_properties(mbe_neo::mbe-shared PROPERTIES
  IMPORTED_IMPLIB_DEBUG "${_IMPORT_PREFIX}/debug/lib/libmbe-neo.dll.a"
  IMPORTED_LOCATION_DEBUG "${_IMPORT_PREFIX}/debug/bin/libmbe-neo.dll"
  )

list(APPEND _cmake_import_check_targets mbe_neo::mbe-shared )
list(APPEND _cmake_import_check_files_for_mbe_neo::mbe-shared "${_IMPORT_PREFIX}/debug/lib/libmbe-neo.dll.a" "${_IMPORT_PREFIX}/debug/bin/libmbe-neo.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
