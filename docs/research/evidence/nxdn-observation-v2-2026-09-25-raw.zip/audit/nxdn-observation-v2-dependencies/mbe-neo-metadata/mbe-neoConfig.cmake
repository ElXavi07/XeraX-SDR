
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was mbe-neoConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Imported targets
include("${CMAKE_CURRENT_LIST_DIR}/mbe-neoTargets.cmake")

# Provide underscore-named aliases for convenience/compatibility
if(NOT TARGET mbe_neo::mbe_shared AND TARGET mbe_neo::mbe-shared)
    add_library(mbe_neo::mbe_shared ALIAS mbe_neo::mbe-shared)
endif()
if(NOT TARGET mbe_neo::mbe_static AND TARGET mbe_neo::mbe-static)
    add_library(mbe_neo::mbe_static ALIAS mbe_neo::mbe-static)
endif()

check_required_components(mbe-neo)
