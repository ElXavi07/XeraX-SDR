# Independent EOF results audit

**No discrepancy found in this scope.** Read all 36 raw invocations from the single frozen v2 run without importing its analyzer, runner or generator. No native execution, regeneration, product changes or analyzer changes occurred. The reproducible audit is [nxdn-observation-v2-eof-results.py](nxdn-observation-v2-eof-results.py); detailed results and raw-file hashes are in [the JSON report](nxdn-observation-v2-eof-results.json).

The 18 callback-enabled runs contain **394,884 exact, ordered delivered indices**, with no gaps or repeats. Their in-frame calls partition **284,244** of those sample deliveries exactly; the remaining deliveries belong to synchronization searches. Across the enabled runs there are:

- **14,212 complete calls**, each with one symbol-counter commit, 20 real samples and a valid after-frontier.
- **4 partial calls**, each with one real sample, no symbol-counter commit, and first EOF transition.
- **6 first-empty calls** and **530 already-EOF calls**, each with zero new samples and no commit.

All incomplete calls have source position **0/unavailable** while their actual consumed interval remains recorded separately. Every frame's interval partition equals its actual trace slice. Callback-off common records match callback-on records; both chunks match, including detailed events and delivered traces. The off runs have no pop traces and are not described as independently traced deliveries.

## Fixed prefix exposures

Both chunks and both observation modes reproduce each registered boundary exactly. Counts below describe the final truncated frame in one invocation:

| Input length | Complete calls | Partial calls | First empty | Later empty | LICH / actual frame return |
| --- | ---: | ---: | ---: | ---: | --- |
| 12360 | 0 | 0 | 1 | 7 | Parity reject / historical 1 |
| 12361 | 0 | 1 | 0 | 7 | Parity reject / historical 1 |
| 12380 | 1 | 0 | 1 | 6 | Parity reject / historical 1 |
| 12521 | 8 | 1 | 0 | 173 | Accepted 0x41 / historical 1 |

All four preserve prior confirmation but end with **evidence=0, proved=0, weak streak=0**. No truncated frame returns new proof 2. The first three reach no recorded channel decoder. At 12521, all three final recorded checks fail after fallback:

| Channel | Independently computed CRC | Received checkword |
| --- | ---: | ---: |
| SACCH CRC6 | 10 | 3 |
| FACCH A CRC12 | 3825 | 1763 |
| FACCH B CRC12 | 37 | 2304 |

The audit recomputes the recorded CRC6/CRC12 observations throughout the prefix runs and retains every actual frame result. Numeric returned dibits are not used to infer sample delivery: these prefix EOF paths return dibit 2 even when no samples arrive.

All **10 EOF-truncated frames across enabled runs**—eight prefix frames and two old cold-sync-blank frames—are unattributed and not marked fully sampled. Independent canonical attribution agrees with every saved frame attribution; none of the partial or empty positions creates source truth.

## Old EOF anchor and limits

The old h0-cold_sync_blank final frame still has **109 completed calls, one first-empty call, then 72 already-empty calls**. It remains unconfirmed and returns 0, with no current proof. For each chunk and observer mode, projecting only new telemetry and changing exactly **73 invalid tail positions** to unavailable reproduces all old receiver rows, returned body values and actual pop traces. The old values were 32634 for chunk 37 and 32256 for chunk 512. No original receiver outcome was changed or omitted.

This audit finds no EOF-related reason that the v2 observation gate should have failed. Its claim remains limited: the pop trace stores delivered indices and the native recorder checks sample bytes; it does not store a second independent call id per pop. Call ownership is cross-checked using the common coordinates, real completion counters and exact frame slices under the registered filter-off/fixed-generation assumptions. This is not an independent DSP reimplementation, SCCH/PCM revalidation, recovery improvement or speech-success finding.

The former recovery report remains byte-identical and failed: SHA-256 `c32a8922e7e4a939194a1a71c8da0cd0b74faf9a79740317830e26b027b0337f`. The audited v2 report is `bf611c30966c492c7f0e6cad1431737b5f04115fb937bc1e3af48de267021b52`.
