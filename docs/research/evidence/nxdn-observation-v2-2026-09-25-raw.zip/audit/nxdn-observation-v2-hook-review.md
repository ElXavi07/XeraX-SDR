# NXDN observation v2: independent pre-execution hook review

Reviewed 2026-09-25 at repository HEAD `0243ac6b1458b550349ade00e7a5039582c88d6b`, before any native matrix execution by this reviewer. This is a read-only source review; no product changes, native execution, build, or input regeneration was performed.

## Finding

No required source-policy or telemetry correction was identified in the reviewed hook implementation. The generated seams preserve the receiver's branch decisions and forward the real wrapped functions once. The selected telemetry is suitable for the explicitly registered finite discriminator-input, 8 kHz, nonfloating, left-audio path. This is not approval of unexecuted matrix results or proof of the final link composition.

The final executable still needs the planned link-map/symbol audit: private generated frame/deperm objects and real voice/vocoder/audio implementations must supply the active symbols, with no fixture sink replacing them. The source-level CMake arrangement is consistent with that intent. The matrix must retain off/on parity, EOF censoring, independent CRC truth, configuration, and failure gates; this review does not replace those checks.

## Forwarding and policy neutrality

* `__wrap_getDibitSoft` calls `__real_getDibitSoft` exactly once with the same arguments and returns its result. It records pre/post provider-cache frontiers, EOF flags and symbol counters. A body position is committed only if EOF is not set and the symbol counter advanced once. Returned zero by itself is not treated as supplied data. These are finite discriminator-source observations, not original RF/IQ sample coordinates.
* `__wrap_nxdn_voice`, `__wrap_processMbeFrameSoft`, and `__wrap_processAudio` each call their corresponding real implementation exactly once, forwarding original arguments. Their added operations read receiver state and update observer-local counters/rows; they do not alter audio options, frame evidence, confirmation state, protocol flags, or buffer contents.
* Detailed observation off still executes these wrappers and their counters. It is not an entirely uninstrumented production binary. Existing sample/CRC6/CRC12 callbacks are disabled in that mode; the newly inserted direct SCCH/LICH observer functions still run and return before detailed output. This distinction matters for descriptions of neutrality and any future timing use.
* `prepare_build.py` checks the four source inputs byte-for-byte against commit `938c5fe8a24719dbfad510bc536f1084de650a1a`. Each textual insertion requires a unique seam. Generated files live in the private build directory; no product file is rewritten. The explicit `datascope=0` matches the underlying initialization default rather than changing this profile's prior policy.
* The new CMake target removes original `nxdn_frame.c` and `nxdn_deperm.c` from the copied private protocol source list and adds the generated versions. It links the private protocol/DSP paths and real engine/CLI dependencies, without explicitly linking the former frame observer's side-effect sink source files. Runtime/link selection remains a separate audit.

## SCCH and LICH telemetry

`xerax_v2_scch` is inserted after the original soft-decoded CRC7 check and the complete existing hard-fallback branch. Both `trellis_buf` and computed/received CRC fields therefore describe the final selected candidate. `soft_pass` preserves the first check, while `fallback=!soft_pass` correctly indicates that the original fallback branch ran. The hook precedes evidence mutation and semantic SCCH dispatch; its state snapshot is pre-evidence for this channel and must not be described as the final frame state. The 25 information bits and seven check bits are copied from the final buffer without recomputation by the observer. Independent CRC arithmetic and the frozen good/wrong-CRC vector audit remain the truth oracle.

`xerax_v2_lich` reports the original parity/direction/profile outcomes and the actual initialized `ctx` fields. Reject events expose the actual flags before a successful profile application; successful events occur immediately after profile selection. The recorded voice/SCCH/PICH-TCH/IDAS/SACCH/FACCH fields are a deliberately selected subset, not a complete enumeration of every possible NXDN channel flag. The registered profiles must remain independently checked by the analyzer. The later LimaZulu helper does not overwrite `ctx.voice`; source inspection found profile assignment as its only write.

Neither accepted LICH nor an SCCH CRC pass establishes intelligible voice, correct playback, or general receiver correctness. Confirmation state, this frame's evidence, and actual voice-processing invocation remain distinct observations.

## Audio domain and limits

At the registered `pulse_digi_rate_out=8000`, `floating_point=0` configuration, `processAudio` applies gain then invokes the native-left emitter. That emitter clamps and writes all 160 `audio_out_temp_buf` values, stages the corresponding 160 signed samples in `s_l`, and advances the output indices. The wrapper reads immediately after that real call. The string `internal_post_gain_float160_and_staged_short160` is accurate; more specifically the native float samples are already clamped by the emitter.

At output rates above 8 kHz the real emitter writes `s_lu` instead, so this hook's `s_l160` interpretation would be stale. The analyzer currently rejects changed configuration values, including the fixed 8 kHz/nonfloating profile. Keep that gate. Audio output is disabled and no playback is observed. Internal sample energy and buffer writes are not evidence that audio reached an output device or that the synthetic voice field contains valid speech.

Only the soft-MBE and left `processAudio` paths are wrapped. Hard-MBE, right-channel `processAudioR`, and MBElib result/erasure/mute status are not covered. This is sufficient to observe the declared current NXDN soft-left route but is not a complete generic vocoder monitor. An absent hook cannot establish absence of all possible voice activity. A present hook, zero energy, or cleared error fields cannot establish successful speech decoding; real vocoder code can synthesize silence on errors.

The short checksum is a 32-bit FNV diagnostic over explicit little-endian sample bytes, not collision-free PCM identity. Peak/count/energy are summaries rather than full sample truth. Float nonfinite values are counted separately and excluded from numeric energy; the analyzer requires all 160 finite for its accepted measurement contract, so a zero summary is not silently interpreted as healthy silence after nonfinite samples. Added formatting and buffer scanning have runtime cost; this profile makes no performance claim.

## Reviewed identities

SHA-256, raw bytes:

| File | SHA-256 |
| --- | --- |
| `experiments/nxdn_observation_v2/observer_extra.inc` | `c6d7b0ad47299c5f8ac1135e47c4dd00817198abe4d381f819d8bda9446e7357` |
| `experiments/nxdn_observation_v2/prepare_build.py` | `0779b520c5eef929ff474026521060d5b372a89809a474b2c5f0e689cc045b62` |
| `experiments/nxdn_observation_v2/CMakeLists.txt` | `5364ea5dbdabc130732a1de5b09ce133dd307a35fb9cf508255d34ea28b5db21` |
| `experiments/nxdn_observation_v2/observer_api.h` | `9fb173a4cca90819e88b408196598a3601950903cd1ce99ac5ab8f646682843b` |
| `experiments/nxdn_observation_v2/dispatch_observed.c` | `de222b52c7ceaed7bfedb0edaa9486c5edc28de3230b2a1cabc98faac21dbb8a` |
| preflight `engine_observed.c` | `009f002f693e468f050ad7588e80a8ebfa9afbcc55c475f1c9e7548ef4c0cf8c` |
| preflight `observer.c` | `d557af1bf9cc00962345d27acced53e4d98f8842054c782669b66bec93b1b9bd` |
| preflight `nxdn_frame_observed.c` | `2ba5d8bb393d677637143644770826de454c5341ade77698041dfb5aced9eb7f` |
| preflight `nxdn_deperm_observed.c` | `fc016d03a943fedb33e151a14f164ad4658abc58f6cd0cd06e099a0617ab877b` |

Preflight files are under `build/nxdn-observation-v2-prepared-preflight`; their pinned input/output identities are recorded in its `source-identity.json`. Related independent input truth is retained separately in `build/nxdn-observation-v2-input-audit.py/.json/.md`. No prior failed recovery gate is changed by this new observation contract.
