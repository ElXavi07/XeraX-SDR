"""Independent preflight oracle. No receiver/preparer/production encoder imports."""
import collections
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def crc7_polynomial(bits):
    value = (127 << len(bits)) ^ (int(bits or "0", 2) << 7)
    while value.bit_length() > 7:
        value ^= 0x89 << (value.bit_length() - 8)
    return value


def primary_lineage_crc(bits):
    # DSD-FME 719d9709... nxdn_deperm.c:291-307, independently expressed
    # simultaneous seven-stage update; arithmetic corroboration, not a decoder.
    state = [1] * 7
    for bit in bits:
        feedback = int(bit) ^ state[0]
        state = state[1:4] + [feedback ^ state[4]] + state[5:] + [feedback]
    return int("".join(str(x) for x in state), 2)


def scch_vector(bad_check=False):
    information = "0" * 25
    computed = crc7_polynomial(information)
    received = computed ^ (64 if bad_check else 0)
    check = f"{received:07b}"
    conv_input = information + check + "0000"
    # Reversal-free history formulation, independently expressed from the
    # generator's packed shift-register parity masks.
    history = [0] * 4
    coded = []
    for bit in conv_input:
        value = int(bit)
        coded.extend((value ^ history[2] ^ history[3], value ^ history[0] ^ history[1] ^ history[3]))
        history = [value] + history[:3]
    kept = [value for index, value in enumerate(coded) if (index + 1) % 6]
    matrix = [kept[start:start + 12] for start in range(0, 60, 12)]
    channel = [matrix[column][row] for row in range(12) for column in range(5)]
    lich_bits = "".join(bit + "1" for bit in f"{0xEF:08b}")
    body_bits = lich_bits + "".join(map(str, channel)) + "00" * 144
    body = [int(body_bits[p:p + 2], 2) for p in range(0, len(body_bits), 2)]
    stages = collections.deque(int(bit) for bit in reversed(f"{228:09b}"))
    air_body = []
    for d in body:
        air_body.append(d ^ (stages[0] * 2))
        feedback = stages[0] ^ stages[4]
        stages.popleft()
        stages.append(feedback)
    fsw = f"{0xCDF59:020b}"
    raw = bytes([int(fsw[p:p + 2], 2) for p in range(0, 20, 2)] + air_body)
    require(len(raw) == 192 and len(channel) == 60, "Oracle dimension error")
    text = lambda v: "".join(map(str, v))
    return raw, {"information_bits": information, "computed_crc7": computed,
                 "received_crc7": received, "check_bits": check, "conv_input_bits": conv_input,
                 "coded_bits": text(coded), "punctured_bits": text(kept), "channel_bits": text(channel),
                 "full_lich": 239, "lich_profile": 119, "raw_voice_dibits": 144,
                 "raw_voice_value": 0, "voice_semantics": "synthetic observation slots, no valid speech claim",
                 "sha256": sha(raw), "dibits": list(raw)}


def waveform(dibits):
    level = (8000, 24000, -8000, -24000)
    nrz = [level[d] for d in dibits for _ in range(20)]
    extended = [nrz[0]] * 4 + nrz + [nrz[-1]] * 3
    total = [0]
    for value in extended:
        total.append(total[-1] + value)
    samples = [(total[i + 8] - total[i]) / 8 for i in range(len(nrz))]
    return struct.pack("<" + str(len(samples)) + "f", *samples)


def constants():
    require(crc7_polynomial("") == 127 and crc7_polynomial("10" * 12 + "1") == 16,
            "Independent CRC7 golden mismatch")
    for bits in ("", "0" * 25, "1" * 25, "10" * 12 + "1", "01" * 12 + "0"):
        require(crc7_polynomial(bits) == primary_lineage_crc(bits), "Primary-lineage register disagreement")
    return {kind: scch_vector(kind == "bad")[1] for kind in ("valid", "bad")}


def audit(directory):
    directory = Path(directory)
    parent = ROOT / "build/nxdn-recovery-inputs-20260925"
    manifest_raw = (directory / "manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    old_raw = (parent / "manifest.json").read_bytes()
    require(sha(old_raw) == "897035e6a439272d50312bcf7286b41e031bd61bdfdbba02ec775f1fc521c602", "Parent manifest drift")
    old = json.loads(old_raw)
    preflight = json.loads((ROOT / "build/nxdn-recovery-input-audit.json").read_bytes())
    require(preflight["input_contract_pass"] and preflight["manifest_sha256"] == sha(old_raw), "Parent not independently audited")
    expected_header = {"schema": 2, "kind": "nxdn_observation_v2", "rate_hz": 48000,
                       "samples_per_symbol": 20, "parent_manifest_sha256": sha(old_raw)}
    require(all(manifest.get(k) == v for k, v in expected_header.items()), "Profile differs")
    files = {}

    def check(name, expected, digest):
        require(Path(name).name == name or name.startswith("vectors/"), "Unexpected path")
        actual = (directory / name).read_bytes()
        require(actual == expected and sha(actual) == digest, "Independent bytes/hash differ: " + name)
        files[name] = {"bytes": len(actual), "sha256": sha(actual)}

    vector_bytes = {}
    for name in ("h0-C.dibits", "h0-S.dibits"):
        meta = manifest["vectors"]["vectors"][name]
        require(meta == old["vectors"]["vectors"][name], "Prior control vector metadata changed")
        raw = (parent / "vectors" / name).read_bytes()
        require(sha(raw) == preflight["files"]["vectors/" + name]["sha256"], "Preflight vector drift")
        check("vectors/" + name, raw, meta["sha256"])
        vector_bytes[name] = raw
    copied = ("h0-warm_clean", "h0-cold_sync_blank", "h0-warm_drop20")
    for name in copied:
        wave = manifest["waveforms"][name]
        require(wave == dict(old["waveforms"][name], anchor_waveform=name), "Copied waveform metadata drift")
        for key, digest in (("file", "sha256"), ("original_file", "original_sha256"),
                            ("lineage_file", "lineage_sha256"), ("occurrence_file", "occurrence_sha256")):
            raw = (parent / wave[key]).read_bytes()
            require(sha(raw) == preflight["files"][wave[key]]["sha256"], "Preflight waveform/map drift")
            check(wave[key], raw, wave[digest])
    clean = old["waveforms"]["h0-warm_clean"]
    clean_raw = (parent / clean["file"]).read_bytes()
    prefixes = (12360, 12361, 12380, 12521)

    def maps(name, size, wave):
        origins = struct.pack("<" + str(size) + "I", *range(size))
        zeroes = bytes(size * 4)
        require(wave["lineage_file"] == name + ".origin.u32le" and wave["occurrence_file"] == name + ".occurrence.u32le", "Map name differs")
        check(wave["lineage_file"], origins, wave["lineage_sha256"])
        check(wave["occurrence_file"], zeroes, wave["occurrence_sha256"])

    for cut in prefixes:
        name = f"prefix_{cut}"
        wave = manifest["waveforms"][name]
        expected = {"file": name + ".f32le", "samples": cut, "original_file": clean["file"],
                    "original_sha256": clean["sha256"], "original_samples": clean["samples"],
                    "frames": [f for f in clean["frames"] if f["start"] < cut], "scenario": name, "payload": 0,
                    "edit": {"kind": "prefix", "source_start": cut, "count": clean["samples"] - cut}}
        require(all(wave[k] == v for k, v in expected.items()), "Prefix metadata differs")
        check(wave["file"], clean_raw[:cut * 4], wave["sha256"])
        maps(name, cut, wave)
    constants_by_kind = constants()
    scch_checks = []
    for wrong in (False, True):
        name = "scch_wrong" if wrong else "scch_valid"
        vector_name = name + ".dibits"
        raw, meta = scch_vector(wrong)
        fixed_hash = "fb1afd6934f61d552131f84a635789fbae9d57f8537527cc9edc59cbeed00137" if wrong else "e49e9872c987d580c76ba274aca18137767ca9db452a8e6f0a508a156411b4c1"
        require(sha(raw) == fixed_hash, "Pre-generator independent constant drift")
        expected_check = {"information_bits": "0" * 25, "computed_crc": 17,
                          "transmitted_crc": 81 if wrong else 17, "crc_width": 7, "crc_expected_pass": not wrong}
        vector_meta = manifest["vectors"]["vectors"][vector_name]
        require(vector_meta == {"name": "V", "lich": 119, "full_lich": 239, "sha256": fixed_hash,
                                "scch": expected_check, "voice_truth": "unspecified synthetic bits; no speech-validity claim"}, "SCCH metadata differs")
        check("vectors/" + vector_name, raw, fixed_hash)
        wave = manifest["waveforms"][name]
        dibits = [1, 3] * 16
        frames = []
        for ordinal, kind in enumerate("CCSSVV"):
            selected = vector_name if kind == "V" else f"h0-{kind}.dibits"
            data = raw if kind == "V" else vector_bytes[selected]
            frames.append({"ordinal": ordinal, "kind": kind, "start": 640 + 3840 * ordinal,
                           "end": 4480 + 3840 * ordinal, "vector": selected, "sha256": sha(data)})
            dibits.extend(data)
        dibits.extend([0] * 64)
        expected_wave = waveform(dibits)
        expected_meta = {"file": name + ".f32le", "samples": 24960, "original_file": name + ".f32le",
                         "original_sha256": sha(expected_wave), "original_samples": 24960,
                         "frames": frames, "scenario": name, "payload": 0, "scch_expected": expected_check,
                         "edit": {"kind": "none", "source_start": 0, "count": 0}}
        require(all(wave[k] == v for k, v in expected_meta.items()), "SCCH waveform metadata differs")
        check(wave["file"], expected_wave, wave["sha256"])
        maps(name, 24960, wave)
        require(expected_wave[:16000 * 4] == clean_raw[:16000 * 4], "CCSS prefix differs from old control")
        scch_checks.append({"name": name, "expected": meta, "waveform_sha256": sha(expected_wave),
                            "samples": 24960, "copied_ccss_prefix_samples": 16000})
    names = set(copied) | {f"prefix_{c}" for c in prefixes} | {"scch_valid", "scch_wrong"}
    require(set(manifest["waveforms"]) == names, "Waveform set differs")
    require(set(manifest["vectors"]["vectors"]) == {"h0-C.dibits", "h0-S.dibits", "scch_valid.dibits", "scch_wrong.dibits"}, "Vector set differs")
    expected_cases = {(f"{n}-c{c}", n, c, 0) for n in names for c in (37, 512)}
    actual_cases = [(c["id"], c["waveform"], c["chunk"], c["fast"]) for c in manifest["cases"]]
    require(len(actual_cases) == 18 and set(actual_cases) == expected_cases, "Registered case grid differs")
    require(all(set(c) == {"id", "waveform", "chunk", "fast"} for c in manifest["cases"]), "Case fields differ")
    actual_paths = {p.relative_to(directory).as_posix() for p in directory.rglob("*") if p.is_file()}
    require(actual_paths == set(files) | {"manifest.json"}, "Unlisted/missing input files")
    invocation_grid = [{"id": cid, "waveform": n, "chunk": c, "fast": f, "observed": obs}
                       for cid, n, c, f in sorted(actual_cases) for obs in (0, 1)]
    return {"audit_schema": 1, "input_contract_pass": True, "native_execution": False,
            "source_at_audit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
            "input_directory": str(directory.resolve()), "manifest_sha256": sha(manifest_raw),
            "generator_sha256": sha((ROOT / "experiments/nxdn_observation_v2/prepare.py").read_bytes()),
            "preregistration_sha256": sha((ROOT / "docs/research/NXDN-OBSERVATION-V2-PREREGISTRATION-2026-09-25.md").read_bytes()),
            "parent_manifest_sha256": sha(old_raw), "parent_independent_audit_sha256": sha((ROOT / "build/nxdn-recovery-input-audit.json").read_bytes()),
            "files": files, "file_count_including_manifest": len(files) + 1,
            "checked_binary_bytes": sum(v["bytes"] for v in files.values()), "waveforms": 9, "base_cases": 18,
            "planned_native_invocations": 36, "invocations": invocation_grid, "scch_vectors": scch_checks,
            "primary_corroboration": {"repository": "https://github.com/lwvmobile/dsd-fme", "commit": "719d9709e6d4c738be70183616b7b87081b50776",
                "file": "src/nxdn_deperm.c", "sha256": "aae26e450b73a5b74db70e6ee8e0cb99c6e6115e77aa9dfab4b8bc54b34e3c0f",
                "crc_lines": [291, 307], "crc_and_received_check_gate_lines": [888, 913],
                "qualification": "Primary upstream lineage corroboration, not an independent standards authority; register recurrence agrees with independent polynomial division."},
            "independence": "No decoder, preparer or production encoder imports. Explicit convolution history differs from generator register masks; matrix transpose and PN bit stages; prefix-sum waveform reconstruction.",
            "limits": ["Positive truth is final SCCH information/check only; 144 zero voice dibits are not valid speech truth.",
                       "Prefix frame descriptors can extend beyond finite delivered length; they are nominal original frames, not assertions of complete availability.",
                       "CRC7 external corroboration shares receiver ancestry; new vectors are not standards-conformance certification.",
                       "No native invocation or output has been audited or inferred here."]}


if __name__ == "__main__":
    if len(sys.argv) == 1:
        values = constants()
        print(json.dumps({k: {name: data[name] for name in ("computed_crc7", "received_crc7", "sha256")}
                          for k, data in values.items()}, indent=2))
    else:
        output = ROOT / "build/nxdn-observation-v2-input-audit.json"
        require(not output.exists(), "Preserve previous audit; output already exists")
        try:
            result = audit(sys.argv[1])
        except Exception as error:
            result = {"input_contract_pass": False, "native_execution": False,
                      "exception": type(error).__name__, "detail": str(error)}
        output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({key: result.get(key) for key in ("input_contract_pass", "waveforms", "base_cases", "planned_native_invocations", "checked_binary_bytes", "detail")}))
        sys.exit(0 if result["input_contract_pass"] else 1)
