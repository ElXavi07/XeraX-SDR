"""Read-only independent EOF audit; no experiment analyzer/generator imports."""
import collections
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
PAIR = ROOT / "build/nxdn-observation-v2-pair-20260925"
OLD = ROOT / "build/nxdn-recovery-pair-20260925"
OUT = ROOT / "build/nxdn-observation-v2-eof-results.json"
OPTIONAL = {"crc", "lich", "scch", "voice_begin", "voice_end", "mbe_begin", "mbe_end", "audio_begin", "audio_end"}
issues = []


def check(ok, reason, **context):
    if not ok:
        issues.append({"reason": reason, **context})


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def words(path):
    raw = path.read_bytes()
    check(len(raw) % 4 == 0, "partial u32le word", file=str(path))
    return list(struct.unpack("<" + "I" * (len(raw) // 4), raw))


def crc_check(bits, width):
    register = (1 << width) - 1
    for bit in bits:
        feedback = int(bit) ^ (register >> (width - 1))
        register = (register << 1) & ((1 << width) - 1)
        if feedback:
            register ^= {6: 0x27, 12: 0x80F}[width]
    return register


manifest = json.loads((PAIR / "inputs/manifest.json").read_text())
report = json.loads((PAIR / "report.json").read_text())
all_rows, results, hashes = {}, [], {}
for case in manifest["cases"]:
    wave = manifest["waveforms"][case["waveform"]]
    samples = wave["samples"]
    origin = words(PAIR / "inputs" / wave["lineage_file"])
    for observed in (0, 1):
        folder = PAIR / "runs" / case["id"] / str(observed)
        rows = [json.loads(line) for line in (folder / "events.jsonl").read_text().splitlines()]
        all_rows[(case["id"], observed)] = rows
        trace = words(folder / "pops.u32le")
        hashes[str((folder / "events.jsonl").relative_to(PAIR))] = sha(folder / "events.jsonl")
        hashes[str((folder / "pops.u32le").relative_to(PAIR))] = sha(folder / "pops.u32le")
        check(trace == (list(range(samples)) if observed else []), "nonexact finite pop trace", case=case["id"], observed=observed)
        check(rows[-1]["errors"] == rows[-1]["skipped"] == 0, "recorder sample-byte/skip error", case=case["id"])
        check(rows[0]["cosine_filter"] == rows[0]["datascope"] == rows[-1]["fast"] == 0,
              "finite observer assumptions changed", case=case["id"])
        saved = json.loads((folder / "audit.json").read_text())["audit"]
        starts = {r["frame"]: r for r in rows if r["kind"] == "frame_begin"}
        per_run = collections.Counter(); frames = []; frame_pop_count = 0
        for end in (r for r in rows if r["kind"] == "frame_end"):
            fid = end["frame"]; begin = starts[fid]; counts = collections.Counter(); live = []
            check(begin["sps"] == end["sps"] == 20 and begin["rf_mod"] == end["rf_mod"] == 2,
                  "in-frame profile assumption changed", case=case["id"], frame=fid)
            classes = []; first_eof = None; expected_symbol = begin["symbolcnt"]
            expected_position = samples if begin["eof"] else begin["read_start"] + begin["cache_pos"]
            expected_eof = begin["eof"]
            for index, entry in enumerate(end["body_calls"]):
                before, after = entry["before"], entry["after"]
                eb, ea = entry["eof_before"], entry["eof_after"]
                sb, sa = entry["symbol_before"], entry["symbol_after"]
                delta, commits = after - before, (sa - sb) & 0xffffffff
                context = {"case": case["id"], "observed": observed, "frame": fid, "call": index}
                check((before, eb, sb) == (expected_position, expected_eof, expected_symbol), "per-call chain discontinuity", **context)
                check(0 <= before <= after <= samples and eb <= ea and commits in (0, 1), "invalid per-call bounds", **context)
                if commits == 1:
                    kind = "complete"
                    check(not eb and not ea and delta == 20, "false full-sample completion", **context)
                elif delta:
                    kind = "partial"
                    check(eb == 0 and ea == 1 and 1 <= delta <= 19 and after == samples, "invalid partial EOF", **context)
                else:
                    kind = "later_empty" if eb else "first_empty"
                    check(ea == 1 and after == samples, "empty call outside actual EOF", **context)
                check(end["body_positions"][index] == (after if kind == "complete" else 0), "invented dibit source position", **context)
                if ea and not eb:
                    first_eof = {"index": index, **entry, "kind": kind}
                live.extend(range(before, after)); counts[kind] += 1; classes.append(kind)
                expected_position, expected_eof, expected_symbol = after, ea, sa
            check(expected_position == (samples if end["eof"] else end["read_start"] + end["cache_pos"]), "call frontier misses frame end", case=case["id"], frame=fid)
            check((expected_symbol, expected_eof) == (end["symbolcnt"], end["eof"]), "completion/EOF frame mismatch", case=case["id"], frame=fid)
            if observed:
                check(live == trace[begin["pops"]:end["pops"]], "calls do not own exact frame trace slice", case=case["id"], frame=fid)
                frame_pop_count += len(live)
            matches = []
            if classes and all(c == "complete" for c in classes) and not begin["eof"] and not end["eof"]:
                mapped = [origin[p - 1] + 1 for p in end["body_positions"]]
                for source in wave["frames"]:
                    differences = [p - source["start"] - (11 + i) * 20 for i, p in enumerate(mapped)]
                    if differences and all(-20 < d < 20 for d in differences):
                        matches.append(source["ordinal"])
            check(len(matches) <= 1, "ambiguous source identity", case=case["id"], frame=fid)
            original_audit = next(f for f in saved["frames"] if f["end"]["frame"] == fid)
            attributed = original_audit["source"]["ordinal"] if original_audit["source"] else None
            check(attributed == (matches[0] if matches else None), "saved source attribution differs", case=case["id"], frame=fid)
            fully_sampled = len(classes) == 182 and all(c == "complete" for c in classes)
            check(original_audit["fully_sampled"] == fully_sampled, "saved fully-sampled flag differs", case=case["id"], frame=fid)
            crcs = []
            for event in (r for r in rows if r["frame"] == fid and r["kind"] == "crc"):
                width = 6 if event["channel"] == 1 else 12
                if end["eof"] or wave["scenario"].startswith("prefix_"):
                    check(crc_check(event["bits"], width) == event["computed"], "truncated CRC recomputation differs", case=case["id"], frame=fid)
                crcs.append({k: event[k] for k in ("channel", "part", "bits", "computed", "received", "soft_pass", "fallback")})
            frames.append({"frame": fid, "classes": dict(counts), "source_ordinal": attributed,
                "fully_sampled": fully_sampled, "eof": end["eof"], "first_eof": first_eof,
                "body_count": end["body_count"], "proof_state": {k: end[k] for k in ("value", "confirmed", "streak", "evidence", "proved")},
                "crc6_12": crcs, "new_current_proof": end["value"] == 2,
                "lich": [{k: e[k] for k in ("full_lich", "lich", "result", "reason")} for e in rows if e["kind"] == "lich" and e["frame"] == fid]})
            per_run.update(counts)
        results.append({"id": case["id"], "scenario": wave["scenario"], "observed": observed,
                        "samples": samples, "frame_trace_samples": frame_pop_count, "classes": dict(per_run), "frames": frames})

observer_differences = []; chunk_differences = []
for case in manifest["cases"]:
    omitted = {"seq", "frontier", "pops", "observed", "crcs", "skipped"}
    common = lambda rows: [{k: v for k, v in r.items() if k not in omitted} for r in rows if r["kind"] not in OPTIONAL]
    if common(all_rows[(case["id"], 0)]) != common(all_rows[(case["id"], 1)]): observer_differences.append(case["id"])
for wave in manifest["waveforms"]:
    for obs in (0, 1):
        omit = {"provided", "cache_pos", "cache_len", "read_start", "chunk"}
        project = lambda rows: [{k: v for k, v in r.items() if k not in omit} for r in rows]
        if project(all_rows[(wave + "-c37", obs)]) != project(all_rows[(wave + "-c512", obs)]): chunk_differences.append([wave, obs])

anchor_details = []
for chunk in (37, 512):
    for observed in (0, 1):
        cid = f"h0-cold_sync_blank-c{chunk}"
        old_path = OLD / "runs" / cid / "0" / str(observed)
        old_rows = [json.loads(line) for line in (old_path / "events.jsonl").read_text().splitlines()]
        new_rows = all_rows[(cid, observed)]
        projected = [json.loads(json.dumps(r)) for r in new_rows if r["kind"] not in OPTIONAL - {"crc"}]
        changed = []
        for seq, (old, new) in enumerate(zip(old_rows, projected)):
            new["seq"] = seq
            for key in ("observation_schema", "datascope", "pulse_digi_rate_out", "floating_point", "dmr_stereo"):
                if new["kind"] == "configuration": new.pop(key, None)
            if new["kind"] == "summary":
                for key in list(new):
                    if key.startswith("v2_"): new.pop(key)
            if new["kind"] == "frame_end":
                calls = new.pop("body_calls")
                for i, c in enumerate(calls):
                    if c["symbol_after"] == c["symbol_before"] and c["eof_after"]:
                        changed.append({"frame": new["frame"], "index": i, "old_position": old["body_positions"][i], "new_position": new["body_positions"][i]})
                        check(new["body_positions"][i] == 0, "legacy incomplete position not unavailable", case=cid)
                        old["body_positions"][i] = 0
            check(old == new, "legacy anchor changed receiver outcome", case=cid, observed=observed, row=seq)
        check(len(old_rows) == len(projected), "legacy event count differs", case=cid)
        trace_equal = (old_path / "pops.u32le").read_bytes() == (PAIR / "runs" / cid / str(observed) / "pops.u32le").read_bytes()
        check(trace_equal, "legacy real trace changed", case=cid)
        anchor_details.append({"case": cid, "observed": observed, "positions_replaced": changed,
                               "old_event_sha256": sha(old_path / "events.jsonl"), "trace_equal": trace_equal})

observed_runs = [r for r in results if r["observed"]]
counts = collections.Counter()
for r in observed_runs: counts.update(r["classes"])
truncated = [{"id": r["id"], **f} for r in observed_runs for f in r["frames"] if f["eof"]]
check(not observer_differences and not chunk_differences, "common outcome difference")
check(all(f["source_ordinal"] is None and not f["fully_sampled"] and not f["new_current_proof"] for f in truncated), "truncated frame credited")
check(len(results) == 36 and len(observed_runs) == 18 and len(truncated) == 10, "registered exposure count differs")
prefix_patterns = {12360: {"first_empty": 1, "later_empty": 7}, 12361: {"partial": 1, "later_empty": 7},
                   12380: {"complete": 1, "first_empty": 1, "later_empty": 6},
                   12521: {"complete": 8, "partial": 1, "later_empty": 173}}
for run in results:
    if not run["scenario"].startswith("prefix_"): continue
    cut = int(run["scenario"].removeprefix("prefix_"))
    selected = [f for f in run["frames"] if f["eof"]]
    check(len(selected) == 1 and selected[0]["classes"] == prefix_patterns[cut], "fixed prefix exposure differs", case=run["id"])
    if selected:
        last = selected[0]
        check(last["proof_state"] == {"value": 1, "confirmed": 1, "streak": 0, "evidence": 0, "proved": 0},
              "truncated prefix proof was not purely historical", case=run["id"])
        if run["observed"]:
            check(len(last["crc6_12"]) == (3 if cut == 12521 else 0), "truncated channel path differs", case=run["id"])
            check(all(e["computed"] != e["received"] and e["soft_pass"] == 0 and e["fallback"] == 1 for e in last["crc6_12"]),
                  "truncated prefix accepted unexpected recorded content", case=run["id"])
for frame in truncated:
    if frame["id"].startswith("h0-cold_sync_blank"):
        check(frame["classes"] == {"complete": 109, "first_empty": 1, "later_empty": 72}
              and frame["proof_state"] == {"value": 0, "confirmed": 0, "streak": 0, "evidence": 0, "proved": 0},
              "old EOF path changed proof outcome", case=frame["id"])
output = {"audit_pass": not issues, "issues": issues, "scope": "EOF sample ownership, truncated outcomes and old cold_sync_blank projection only; not independent SCCH/PCM revalidation",
          "native_executions": 0, "source_changes": 0, "reported_measurement_pass": report["measurement_pass"],
          "report_sha256": sha(PAIR / "report.json"), "old_failed_report_sha256": sha(OLD / "report.json"),
          "invocations_read": len(results), "observed_runs": len(observed_runs), "observed_samples": sum(r["samples"] for r in observed_runs),
          "observed_frame_trace_samples": sum(r["frame_trace_samples"] for r in observed_runs), "observed_call_classes": dict(counts),
          "observer_differences": observer_differences, "chunk_differences": chunk_differences,
          "truncated_frames": truncated, "cold_anchor_projection": anchor_details, "runs": results, "raw_file_hashes": hashes,
          "limit": "Pop trace contains delivered indices and native byte checks, not independent call ids; per-call partition is cross-checked against common before/after coordinates, completion counters and exact frame trace slices. No source attribution or speech claim for EOF-generated dibits."}
OUT.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in output.items() if k not in ("runs", "truncated_frames", "cold_anchor_projection", "raw_file_hashes")}, indent=2))
