# Independent audit of NXDN observation v2 results

2026-09-25. The retained 36-invocation observation matrix passes this independent read-only audit. No native executable was run, input regenerated, or harness changed. The audit script imports neither the production decoder nor the experiment analyzer/runner; it recomputes final CRCs by GF(2) polynomial division and checks raw events, recorded call intervals, exact pop indices, projections, input bytes and manifest hashes directly.

This is an observation-validity result. The previous 216-invocation recovery study remains failed and unchanged. This result establishes no recovery improvement, valid speech, hardware reception, or playback.

## Counts and controls

All 36 native attempts report exit zero and recorder/backend error counts zero. There are 18 detailed-observation runs and 18 corresponding off runs.

| Observation | Independently counted result |
| --- | ---: |
| On/off common-outcome pairs equal | 18/18 |
| Chunk 37/512 event and pop-trace pairs equal | 18/18, covering both observer modes |
| Archived anchor event/trace pairs equal after the registered projection | 12/12 |
| Detailed frame/LICH observations | 104 |
| Actual sample-pop indices across detailed runs | 394,884 |
| Complete body dibit calls | 14,212 |
| Partial EOF body calls | 4 |
| First empty EOF body calls | 6 |
| Later empty EOF body calls | 530 |
| Final CRC6 results independently recomputed | 54: 36 equal, 18 unequal |
| Final CRC12 results independently recomputed | 108: 72 equal, 36 unequal |
| Final CRC7 results independently recomputed | 10: 4 equal, 6 unequal |
| Detailed voice / soft-MBE / audio calls | 10 / 40 / 40, all entry/exit pairs accounted for |

A separate direct read of the same detailed rows also confirms **40 current-proof returns**, **10 EOF-truncated frames**, and **60 canonically attributed, complete bodies exactly matching their frozen vector bytes**. Canonical attribution was independently recomputed from the delivered-to-original map and all 182 source-backed body endpoints, with the registered strict +/-20-sample window. Truncated or negative-polarity frame calls were excluded from that complete-source count.

The always-active counters across all 36 runs report 208 frame/LICH visits, 20 SCCH/voice calls and 80 soft-MBE/audio calls. Those counts include the repeated off/on executions; they are not 208 independent radio transmissions.

The two V frames in each `scch_valid` run return all 25 expected zero information bits, computed CRC7 **17**, and received checkword **17**. All four detailed positive control observations pass without fallback, report new frame evidence, and return 2.

The two V frames in each `scch_wrong` run return the same independently known information, computed CRC7 **17**, and deliberately altered received checkword **81**. All four detailed negative observations remain wrong after fallback, report no new frame proof, and return 1 from the transmission's earlier confirmed state. Every observed control-frame body matches its frozen 182-dibit source body exactly. The new telemetry distinguishes a CRC result from retained confirmation and from a voice-processing call.

## Damaged-channel voice and PCM observations

Both `h0-warm_drop20` chunk variants show the same frame-4 route:

* Independent dewhitening of the recorded first eight dibits yields full LICH **0xEF**, profile **0x77**, valid parity, voice format **3**, SCCH enabled and IDAS enabled.
* Final SCCH information is `1100101001011100100011100`; independent CRC7 is **1**, while the received bits `0100000` encode **32**. Soft decoding failed and hard fallback was used; the final check still fails.
* The frame enters with historical confirmation and ends confirmed, but with evidence **0**, proved **0**, and return value **1**. It is not newly proven by this failed SCCH.
* The real route makes **one voice call, four soft-MBE calls and four audio-staging calls**. End-of-frame output indices are `[0,640,0,0]`.

The four measured internal 160-sample blocks have short-sample nonzero counts **0, 104, 160, 160**: **424/640** nonzero staged samples per run. Short peaks are **0, 15178, 16677, 18430**; the maximum float peak is **18430.45703125** in the native PCM scale. All 640 measured float elements are finite. The first zero block's checksum independently matches 320 zero bytes. Both chunks have identical recorded diagnostics.

For each `scch_valid` and `scch_wrong` run, eight audio blocks contain 1,224 nonzero float elements and 1,096 nonzero short samples out of 1,280; maximum short peak is 29. The recorded PCM diagnostics are identical between the valid/wrong SCCH controls, whose synthetic voice fields are identical and lack independent speech truth. This reinforces that current SCCH acceptance and historically enabled voice processing are distinct.

Across all 18 detailed runs, the 40 audio blocks expose 6,400 finite float elements, 5,744 nonzero float elements and 5,232 nonzero staged short samples. These are mechanically summed diagnostic counts. Full PCM arrays were not recorded, and a 32-bit checksum is not collision-free sample identity. Neither nonzero samples nor paired wrapper calls prove intelligibility, MBElib acceptance, a valid voice message, or sound delivered to a device. Audio output was disabled; no playback event was recorded.

## Neutrality and evidence preservation

All 18 off/on pairs preserve common receiver state, returned body, per-call records and always-active counters. All nine waveforms preserve exact detailed event/trace outcomes across the two chunks after excluding provider-buffer fields. Twelve copied-anchor pairs preserve the old recorded receiver decisions, CRC6/12 results, body data, counters and pop traces. The sole allowed legacy-coordinate projection marks **292 old EOF positions** explicitly unavailable across those anchor executions; it does not relabel the old study as passing.

The audit rehashed and matched: **83** before-execution frozen-file entries, **3** execution scripts, **922** configured-source entries, **24** original anchor-file entries and **264** final artifact entries. These categories overlap and are not a distinct-file total. All **35** copied input files remain byte-identical to the separately audited preflight directory. Configured-source hashes enumerate existing paths in compilation commands; they are not a claim that every listed unit supplied the final executable or a substitute for the separately recorded link audit.

Identity:

* Harness commit: `a07b3ab37ffcdc127d40fad9a48a043c6ffcb3f7`.
* Executable SHA-256: `a92511f7e1ece923d8b848d8658dc2d9a2e8bcafdc445e859295859672226afc`.
* Original result report SHA-256: `bf611c30966c492c7f0e6cad1431737b5f04115fb937bc1e3af48de267021b52`.
* Independent audit script SHA-256: `e2a836d7feb3113e86d236a342789d5bb435ec3c4ab0382a945a7832b41652cc`.
* Independent machine audit SHA-256: `06e50f02258e752f8b82a8c5d68a4631c279ed10ee687584fd5ced7476d5a4d9`.

The machine audit and arithmetic/read-only script are `build/nxdn-observation-v2-results-independent.json` and `.py`; original evidence remains under `build/nxdn-observation-v2-pair-20260925`.

The parent draft `docs/research/NXDN-OBSERVATION-V2-2026-09-25.md` was reviewed against these raw results. No material numeric or receiver/PCM claim error was identified. Its Windows-native versus Python-only cross-platform CI distinction and preservation of the prior failed recovery result are appropriate. CI outcome and release-file preservation claims remain the parent's separately collected evidence; this raw-result audit does not independently rerun or certify those jobs/builds.
