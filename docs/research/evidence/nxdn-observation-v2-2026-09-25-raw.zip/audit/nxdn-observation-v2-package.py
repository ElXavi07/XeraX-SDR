"""Package completed observation evidence without executing a decoder or changing old artifacts."""
from pathlib import Path
import hashlib,json,os,re,zipfile
ROOT=Path.cwd(); BUILD=ROOT/'build'; STEM='nxdn-observation-v2-2026-09-25'; EVIDENCE=ROOT/'docs/research/evidence'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def require(ok,msg):
 if not ok: raise ValueError(msg)
pair=BUILD/'nxdn-observation-v2-pair-20260925'; result=json.loads((pair/'report.json').read_text())
require(result['measurement_pass'] and len(result['attempts'])==36,'Native contract failed/incomplete')
for rel,field in [('nxdn-observation-v2-results-independent.json','independent_audit_pass'),('nxdn-observation-v2-eof-results.json','audit_pass')]:
 require(json.loads((BUILD/rel).read_text())[field],rel)
summary=json.loads((BUILD/'nxdn-observation-v2-summary-draft.json').read_text()); entries={}
def add(path,name):
 require(name not in entries and not name.startswith('/') and '..' not in Path(name).parts,'Unsafe/duplicate entry')
 entries[name]=path.read_bytes()
for path in sorted(pair.rglob('*')):
 if path.is_file(): add(path,'study/'+path.relative_to(pair).as_posix())
for path in sorted(BUILD.glob('nxdn-observation-v2-*')):
 if path.is_file(): add(path,'audit/'+path.name)
for folder in ('nxdn-observation-v2-analyzer-preflight-original','nxdn-observation-v2-dependencies','nxdn-observation-v2-prepared-preflight'):
 for path in sorted((BUILD/folder).rglob('*')):
  if path.is_file(): add(path,'audit/'+path.relative_to(BUILD).as_posix())
add(ROOT/'LICENSE','LICENSE')
for name in ('NXDN-OBSERVATION-V2-PREREGISTRATION-2026-09-25.md','NXDN-OBSERVATION-V2-PREFLIGHT-2026-09-25.md'):
 add(ROOT/'docs/research'/name,'registration/'+name)
# Reject credential-shaped tokens in textual entries; no private settings are included.
pattern=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-(?:proj-)?[A-Za-z0-9_-]{25,})')
for name,raw in entries.items():
 if Path(name).suffix.lower() in ('.log','.json','.jsonl','.md','.txt','.py','.c','.h','.inc','.cmake','.ninja'):
  require(not pattern.search(raw),'Credential-shaped content in '+name)
manifest={name:{'bytes':len(raw),'sha256':sha(raw)} for name,raw in entries.items()}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=EVIDENCE/(STEM+'-raw.zip'); summary_path=EVIDENCE/(STEM+'.json')
require(not archive.exists() and not summary_path.exists(),'Published evidence must not be overwritten')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(entries.items()):
  info=zipfile.ZipInfo(name,(2026,9,25,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw,compresslevel=9)
with zipfile.ZipFile(archive) as z:
 require(len(z.namelist())==len(set(z.namelist()))==len(entries),'Archive entries differ')
 require(z.testzip() is None,'Archive CRC failed')
 for name,raw in entries.items():require(z.read(name)==raw,'Archive bytes differ: '+name)
summary.update(native_report_sha256=sha((pair/'report.json').read_bytes()),
 raw_archive={'file':archive.name,'bytes':archive.stat().st_size,'entries':len(entries),'sha256':sha(archive.read_bytes()),'all_entries_reopened_and_compared':True},
 independent_audits={name:sha((BUILD/name).read_bytes()) for name in ('nxdn-observation-v2-results-independent.json','nxdn-observation-v2-eof-results.json')},
 preservation=json.loads((BUILD/'nxdn-observation-v2-preservation-after.json').read_text()),
 framework_tests={'count':30,'local_normal':True,'local_optimized':True,'ci_platforms':['Windows','Linux'],'ci_push':36173450402,'ci_pr':36173459020,'scope':'Python framework only; no Linux native grid'},
 preflight_reviews_preserved=True)
with summary_path.open('x',encoding='utf-8') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary['raw_archive']))
