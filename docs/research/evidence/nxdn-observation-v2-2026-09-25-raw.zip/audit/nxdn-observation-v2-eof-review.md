# EOF observation v2: bounded design review

Keep the completed 216-invocation study unchanged and failed. The next study should validate a new recorder contract on a small fixed set; it is not a rerun with an easier pass condition, a receiver improvement experiment, or a production patch.

## Recommended callback-free common record

The proposed common frontier is defensible **only within this known-generation, filter-off finite provider**:

`F = exhausted ? length : read_start + rtl_symbol_cache_pos`

Record the before/after values rather than only a derived position. Once the provider actually reports EOF, its final cache has been drained; the real failed refill clears the cache. `read_start + cache_pos` alone then moves backward, whereas `length` remains the final delivered frontier. Merely providing the final cache does not mean EOF or consumption: do not clamp just because `provided == length`.

This is a coordinate watermark, not independently measured pop count. With observation enabled, check it against the real sample-pop ledger at **each dibit boundary**, including the first EOF transition. Do not convert cache invalidation, generation changes, or buffered samples discarded by a reset into supposed sample deliveries. The registered restrictions and the observed trace must exclude those alternatives. The 20-sample expectation applies to in-frame calls under this fixed profile, not generally to synchronization hunt symbols.

For every `getDibitSoft` call inside a frame, retain:

- Frame id and zero-based call index; returned dibit; before/after `F`, provider count, cache position/length and `read_start`.
- Before/after provider `exhausted`, global exit flag, SPS/profile/generation, and symbol-completion evidence.
- With the optional pop callback enabled only: before/after pop count, exact trace slice, first/last newly delivered index, and independently checked sample bits. With it disabled, these are null/unavailable, not fabricated zero counts.
- A derived classification backed by the raw fields. Record the call's returned value even when it had no real sample; never assign that value a new sample origin.

For the selected bounded implementation, before/after `symbolcnt` around `getDibitSoft` is sufficient with **explicitly set and recorded `datascope == 0`** and no other counter-reset path. The discriminator path commits a completed symbol by incrementing `symbolcnt`; a failed sample read returns without that commit. Datascope can reset that counter after `getSymbol`, so an unguarded outer-counter inference is not generally valid. A link-time `getSymbol` wrapper forwarding exactly once would be an alternative if that restriction later changes; it is not required for this scope.

The proposed `body_calls` entries (`before`, `after`, `eof_before`, `eof_after`, `symbol_before`, `symbol_after`) preserve the necessary common evidence. Set `body_positions` to the after-frontier only when the symbol counter increases by one and EOF remains false; use **0 as explicitly unavailable** for partial/empty calls. Preserve the true partial interval in `body_calls`; zero is not a claim of zero consumption. Reject other symbol-counter changes rather than guessing. The older common receiver outcomes should project identically for the three repeated full-wave anchors, excluding the new fields/events and this declared unavailable-position replacement; do not drop actual receiver state or audio differences.

If symbol completion is not observed, use only the narrower labels **non-EOF call**, **first EOF-crossing call**, and **already-EOF call**. Do not call every non-EOF call a successfully sampled symbol based on its returned number alone.

## Exact classifications and counterexamples

| Observation | Truthful classification | Required distinction |
| --- | --- | --- |
| Completion observed; EOF remains false; real trace confirms the registered complete span | Complete real-sample symbol | A returned zero is still a valid sampled symbol. |
| No completion; EOF false→true; F advances | Partially sampled at EOF | The consumed prefix is real; the returned symbol did not complete. |
| No completion; EOF false→true; F unchanged | First EOF boundary call, no new sample | EOF crossing alone does **not** prove partial sampling. |
| No completion; EOF already true; F unchanged | Subsequent no-new-sample call | Many returned dibits may share the same final frontier; none gets another source index. |
| No completion but EOF remains false; completion while EOF true; or impossible counter transition | Unexplained path / measurement failure | Do not repair or silently force it into a favorable class. |

Counterexamples the checker must reject or classify explicitly:

1. A 512-sample refill has already provided the input's final samples, but only one symbol was consumed. `provided == length` cannot mark this call EOF.
2. Input ends exactly on a symbol boundary. That last symbol completes, and a later call discovers EOF with zero new pops. Rejecting the last symbol merely because its frontier equals length is wrong.
3. Input ends one sample into a symbol. Frontier advances by one, but `symbolcnt` does not advance: endpoint positivity is not completion.
4. Input ends 19 samples into the 20-sample registered span. This remains incomplete; a near-full sample count is not success. Cover this with a synthetic checker fixture even if omitted from the native matrix.
5. After EOF, 73 calls return zero with no new delivery, reproducing the prior tail. Their source position must stay unavailable; no decreasing position and no repeated attribution to the final source sample.
6. A complete genuine all-zero input symbol also returns zero. Return value cannot distinguish it from the EOF fallback.
7. A cache reset discards unread buffered samples. A coordinate delta must not masquerade as equal actual pop count. The enabled ledger must falsify this claim even if begin/end coordinates appear plausible.
8. A repeated discriminator segment advances delivered coordinates while its canonical map revisits original samples. Delivered monotonicity and canonical monotonicity are different properties.

## Small exact native matrix

Use unchanged h0 bytes from the frozen recovery inputs; no new payload selection. Fix the public fast option at **0**: this is observation validation, and both option values exposed the former failure. Register **7 waveforms × 2 chunks (37/512) × 2 observer settings = 28 fresh invocations**:

| Input | Exact retained prefix / full input | Intended exposure |
| --- | --- | --- |
| h0-warm_clean | Existing full wave | Ordinary complete sampled symbols and source-frame truth. |
| h0-cold_sync_blank | Existing full wave | Prior wrong-phase EOF path, including the 73 empty tail calls. |
| h0-warm_drop20 | Existing full wave | Prior receiver-generated audio-buffer activity, retained as observed behavior under its separately specified v2 contract. |
| h0-warm_clean prefix | 12360 samples | Frame 3 sync completes; first LICH call discovers EOF with no new sample. |
| h0-warm_clean prefix | 12361 samples | One real sample in the first LICH call, then EOF. |
| h0-warm_clean prefix | 12380 samples | One complete LICH dibit, then an empty EOF call. |
| h0-warm_clean prefix | 12521 samples | Eight real LICH dibits end at 12520; the first payload call consumes one sample and fails to complete. |

The cut coordinates come from the declared waveform layout: 640-sample preamble, source frame 3 start `640 + 3×3840 = 12160`, 200-sample sync, 160-sample LICH. They are fixed before new execution. Hash each prefix and verify exact equality to that source prefix. Preserve canonical frame bounds from the uncut source separately from available input length; do not shorten a frame into an apparently complete new frame.

These are exposure hypotheses, not promises: an absent intended frame or call class is a failed coverage gate. Do not move the cuts after observing output. The full former EOF case and the explicit partial-body case exercise different failure modes. Add further waveforms only through a separate registration if this finite coverage proves inadequate.

Two SCCH profiles with independently specified valid/wrong CRC7 would make **36 invocations** if their generator, checkword oracle and expected native path are independently audited and registered before execution. That addition validates a separate channel observer; it must not become assumed evidence from the old SACCH6/FACCH12 hooks. The seven-wave EOF contract does not depend on accepting those extra vectors.

## Measurement and truth gates

1. Freeze new recorder source, generated source, binary, link map, compile definitions, input bytes, truncation manifests and checker before execution. Verify the same production receiver sources and selected public option; no hidden force-fast define or semantic wrapper. Preserve the original failed study and its hashes.
2. Require balanced frame/call records, exact counts, finite bounds, and one forwarding call per wrapper. The recorder must not mutate receiver state, exit status, provider data or return values. Failure paths must retain raw artifacts and stop promotion without retry.
3. Require valid before/after cache coordinates, `0 ≤ F_before ≤ F_after ≤ length`, and monotone EOF. At the first provider EOF, verify the enabled ledger consumed through `length` and the cache is empty. For every call, its enabled trace slice must match the actual count delta, contain valid delivered indices/sample bits, and agree with the independently derived common frontier. Reject skipped or repeated delivered indices in this fixed-generation scope.
4. Require each registered classification nonvacuously: complete symbols, first EOF with zero pops, partial EOF with one pop, and subsequent empty calls. Synthetic fixtures additionally exercise 19-pop partial symbols, complete zero-valued symbols, tampered per-call counts, provider prefetch, stale cache positions, false completion and cache-discard counterexamples.
5. Compare observer-on/off common records exactly, including classifications, completion evidence, EOF transitions, returned bodies, confirmation/verdict state and all audio-buffer observations. Exclude only declared optional callback fields and normal provider-cache chunk details. Keep the pop callback absent in observer-off. Compare chunk-independent common records and exact enabled delivered traces across 37/512. Require the three repeated full-wave anchors to preserve prior projected receiver outcomes for fast=0, including the unfavorable audio and wrong-phase EOF paths.
6. Attribute canonical **sample-backed positions only for completed calls**. Preserve tentative source geometry separately from fully sampled frame truth. Partial or empty returned dibits cannot supply invented source provenance. A frame with such calls is explicitly truncated; do not credit it as a fully sampled recovered source frame even if a CRC happens to pass. Still independently report every final CRC, expected content match, actual proof return and sticky historical return. Any claim about FEC reconstruction from a truncated codeword requires an explicit separate definition, not a renamed complete frame.
7. The former warm_drop20 audio activity must be visible in both observer modes and chunks under a preregistered contract. Do not reinstate a blanket zero-buffer assertion as recorder validity, and do not suppress that actual receiver behavior to manufacture an observation pass.

A v2 observation pass would establish the narrower finite recorder contract and neutrality evidence. It would not retroactively pass the failed recovery study or demonstrate improved acquisition, warm recovery, audio latency, hardware behavior, or RF robustness.

## Source anchors

- [Frozen observer](../experiments/nxdn_engine_gap/observer.c), lines 110–118: body position is currently recorded after every dibit call; lines 147–158: provider EOF and unchanged `read_start`; lines 172–182: true pop ledger; lines 242–251: fixed profile, filter off, callback installed only for observed mode.
- [Symbol implementation](../upstream/dsd-neo/src/dsp/dsd_symbol.c), lines 887–892 and 1017–1023: cache clears on failed refill; lines 908–929: callback only after successful real pop; lines 606–608: timing-index nudge bypassed for in-frame `have_sync=1`; lines 1306–1314 and 1694–1696: no samples after shutdown; lines 2142–2183: successful commit versus failed-symbol return.
- [Dibit implementation](../upstream/dsd-neo/src/core/frames/dsd_dibit.c), lines 1012–1056: one real `getSymbol` then digitization per `getDibitSoft`; lines 174–179 and 285–286: datascope counter reset caveat.
- [NXDN frame](../upstream/dsd-neo/src/protocol/nxdn/nxdn_frame.c), lines 184–189 and 633–637: LICH/body loops keep requesting dibits; lines 668–680: actual per-frame proof versus historical confirmation remains observable.

Review scope: source inspection and prior raw evidence only; no new native execution, product changes, or harness edits.
