# Independent pre-execution analyzer and runner review

2026-09-25. Read-only review of `experiments/nxdn_observation_v2/analyze.py`, `test_analyze.py`, `run.py`, and the committed `NXDN-OBSERVATION-V2-PREREGISTRATION-2026-09-25.md`. No native decoder, matrix, input generator, or test was executed by this reviewer. Only this ignored review note was written.

## Findings sent before first native execution

1. **Required confirmation-gate correction.** In the initially reviewed analyzer, `validate_lich` required a voice wrapper call whenever an accepted known LICH profile selected voice. The real `nxdn_process_voice_and_mbe` calls `nxdn_voice` only when both `ctx->voice` and `nxdn_confirm_is_confirmed(state)` are true (`nxdn_frame.c:559`). A legitimate unconfirmed voice-marked frame would therefore fail recorder validity, while a fabricated call made while unconfirmed could satisfy the old expectation. Parent acknowledged this before execution and assigned the analyzer owner a correction plus accepted-unconfirmed/no-call and fabricated-call controls. Require confirmation at the actual voice entry, with expected call count consistent with the real gate; do not equate voice-marked LICH with authorized synthesis. `nxdn_confirm_end_frame` does not clear the confirmed flag on the reviewed fixed path.

2. **Diagnostic consistency gap.** The initial `validate_crc` checked `fallback == 1-soft_pass`, but accepted `soft_pass=1`, `fallback=0` with differing final computed/received CRC values. That cannot be emitted correctly by these hooks: with a first-pass match, fallback is skipped and the final check values remain equal. Require the one-way implication `soft_pass => computed == received`; do not require the converse because fallback may recover a check. This concerns widths 6, 7 and 12 and can be tested with a small contradictory-metadata control. Parent was notified. This does not change the independently specified control CRCs or the receiver algorithm.

No additional runner blocker was identified in the current bounded Windows execution policy. The parent-added `anchor_projection` wrapper catches malformed-event projection errors and returns a failed anchor gate rather than silently accepting them or interrupting subsequent native attempts. Malformed archived JSON or an unavailable immutable archive remains an outer infrastructure failure with retained evidence; it is not a native retry.

## Gates reviewed

* The finite matrix remains nine registered scenarios, two chunk sizes, and off/on observation, with acquisition fixed to zero. Aggregate success requires all 36 native invocations, no failed per-attempt inspection/exit status, anchor parity, chunk parity, observer parity, and before/after preservation.
* Complete, partial, first-empty and later-empty calls are classified using delivered frontier, EOF and symbol-counter changes. Completed zero-valued dibits remain valid. Source attribution requires complete calls and real source coordinates; partial/empty frames are retained but not assigned a canonical source identity. Enabled pop traces must equal the finite delivered index range. The native sample callback separately compares each delivered float's bytes against the supplied waveform; a successful Python index check alone does not independently prove those values.
* LICH flags/parity are checked against the returned dibits, channel event order/count is enforced for the known profiles, and final SCCH information/check bits are recomputed independently. The positive and deliberately wrong-CRC controls retain their frozen `(25 zero bits, computed 17, received 17/81)` truth. The checker requires both source-backed V control frames.
* Common state/body/per-call records and always-active counters participate in off/on parity. Chunk comparison removes provider-buffer fields only. Detailed wrappers are paired and nested inside their frame; internal PCM statistics are domain-labeled and bounded. Current analyzer behavior retains nonfinite receiver counts as measured behavior while checking the finite-element statistics; it does not revive the old blanket audio-side-effect ban.
* No recovery, speech, vocoder-success, PCM-playback, RF/IQ, timing, or product improvement conclusion follows from `measurement_pass`. `source_body_exact` is reported separately rather than silently being treated as universal successful decoding. The preregistration explicitly restricts the experiment to observation validity and neutrality on these cases.

## Runner and preservation review

The runner refuses an existing output directory, freezes the executable, local DLLs, generated source, build configuration, experiment files, preregistration, copied inputs and anchor references, then writes a before-execution manifest. Every invocation has a distinct directory, stdout/stderr files, recorded command, a 60-second bound, stripped `DSD_*` environment, and an audit/failure record. Native exceptions and malformed new output fail that invocation; later cases still run. Final success also checks import-time execution-source hashes and frozen/source/anchor preservation. No retry loop or quality-dependent vector change exists.

The revised manifest label `configured_source_hashes` correctly describes existing source paths enumerated by `compile_commands.json`, which also includes configured but unbuilt targets. These hashes are not a hermetic build proof, complete included-header/dependency inventory, or evidence that every listed translation unit supplied the executable. Link-map/symbol selection and the separately recorded fresh build remain necessary. The runner targets the registered Windows `.exe` and is not presented as a portable native-execution wrapper.

Anchor projection removes only the new detailed event types/fields and substitutes unavailable EOF positions when the new call explicitly records EOF with no symbol commit. Original common decisions, bodies, CRC6/12 rows, counters, and actual sample traces remain compared. Prior failed recovery evidence is read/copy-only and never rewritten or reclassified.

## Review snapshot and remaining completion

Initial reviewed analyzer SHA-256: `8a9281fd04a20bd69fdea8222c654db615749e170ed8a8de1ceb60f0fbce055c`.

Initial reviewed tests SHA-256: `ebd3fe26de7e56fe9eef1ae4ff7df61ca9e003ed97f80a9b778521663ba649bd`.

Reviewed runner after malformed-projection wrapper/configured-source label update: `7ff38b0ef812796c2766fad27cf4ac8508edaf03fb5189ef3912adf8c2edff1f`.

Committed preregistration SHA-256: `65df8e427c0f7cfab899436ef37732083a1f4b11c29b6b6755ce2c2c84e32d30`.

These identify the review snapshots, not a claim that the analyzer owner has frozen its final corrections. Parent should retain the before-execution correction evidence and normal/optimized synthetic-test results, then freeze corrected source identities before the one registered matrix. No favorable native result has been observed or assumed by this review.
