"""Read-only arithmetic/evidence audit; no harness import, native run, or vector generation."""
from pathlib import Path
import collections
import copy
import hashlib
import json
import math
import struct

ROOT = Path(__file__).resolve().parent.parent
RUN = ROOT / 'build/nxdn-observation-v2-pair-20260925'
OUT = Path(__file__).with_suffix('.json')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def read_json(path):
    return json.loads(Path(path).read_bytes())


def polynomial_remainder(bits, width):
    # Direct GF(2) long division; independent of native lookup/register code.
    polynomial = (1 << width) | {6: 0x27, 7: 0x09, 12: 0x80f}[width]
    work = (((1 << width) - 1) << len(bits)) ^ (int(bits, 2) << width)
    while work.bit_length() > width:
        work ^= polynomial << (work.bit_length() - 1 - width)
    return work


def read_events(path):
    return [json.loads(line) for line in Path(path).read_bytes().splitlines()]


NEW = {'lich', 'scch', 'voice_begin', 'voice_end', 'mbe_begin', 'mbe_end', 'audio_begin', 'audio_end'}
OPTIONAL = NEW | {'crc'}


def off_projection(rows):
    omit = {'seq', 'frontier', 'pops', 'observed', 'crcs', 'skipped'}
    return [{k: v for k, v in r.items() if k not in omit} for r in rows if r['kind'] not in OPTIONAL]


def chunk_projection(rows):
    omit = {'provided', 'cache_pos', 'cache_len', 'read_start', 'chunk'}
    return [{k: v for k, v in r.items() if k not in omit} for r in rows]


def legacy_compare(old, new):
    left = copy.deepcopy(old)
    right = [copy.deepcopy(r) for r in new if r['kind'] not in NEW]
    require(len(left) == len(right), 'Anchor event-count difference')
    unavailable = 0
    for index, (a, b) in enumerate(zip(left, right)):
        b['seq'] = index
        if b['kind'] == 'configuration':
            for field in ('observation_schema', 'datascope', 'pulse_digi_rate_out', 'floating_point', 'dmr_stereo'):
                del b[field]
        if b['kind'] == 'summary':
            for field in list(b):
                if field.startswith('v2_'):
                    del b[field]
        if b['kind'] == 'frame_end':
            calls = b.pop('body_calls')
            require(len(calls) == len(a['body_positions']) == len(b['body_positions']), 'Anchor body-count difference')
            for n, call in enumerate(calls):
                if b['body_positions'][n] == 0:
                    require(call['eof_after'] == 1 and call['symbol_after'] == call['symbol_before'], 'Invalid EOF projection')
                    a['body_positions'][n] = 0
                    unavailable += 1
        require(a == b, 'Anchor changed at event ' + str(index))
    return unavailable


def main():
    require(not OUT.exists(), 'Independent audit output already exists')
    report = read_json(RUN / 'report.json')
    before = read_json(RUN / 'before-execution.json')
    manifest = read_json(RUN / 'inputs/manifest.json')
    failures = []
    hashes = {}
    for group in ('frozen_files', 'executed_sources', 'configured_source_hashes', 'anchors'):
        for name, expected in before[group].items():
            require(sha(name) == expected, 'Before-manifest hash changed: ' + name)
        hashes[group] = len(before[group])
    for name, expected in report['files'].items():
        require(sha(RUN / name) == expected, 'Final artifact hash changed: ' + name)
    hashes['final_artifacts'] = len(report['files'])
    frozen_inputs = RUN / 'inputs'
    original_inputs = ROOT / 'build/nxdn-observation-v2-inputs-20260925'
    input_files = [p for p in frozen_inputs.rglob('*') if p.is_file()]
    for path in input_files:
        require(path.read_bytes() == (original_inputs / path.relative_to(frozen_inputs)).read_bytes(), 'Frozen/preflight input difference')
    hashes['frozen_inputs_equal_preflight'] = len(input_files)
    require(report['measurement_pass'] and report['preservation_pass'] and not report['measurement_failures']
            and not report['anchor_differences'], 'Parent result does not claim full observation pass')
    expected = {(case['id'], enabled) for case in manifest['cases'] for enabled in (0, 1)}
    require(len(expected) == 36 and {(r['id'], r['observed']) for r in report['attempts']} == expected
            and len(report['attempts']) == 36, 'Matrix cardinality differs')
    require(all(r['exit_code'] == 0 and r['measurement_pass'] for r in report['attempts']), 'Native/inspection failure')
    rows_by_key, totals, detailed, cases = {}, collections.Counter(), collections.Counter(), []
    crc_counts = collections.Counter()
    partial_classes = collections.Counter()
    enabled_pops = 0
    for case in manifest['cases']:
        wave = manifest['waveforms'][case['waveform']]
        for enabled in (0, 1):
            folder = RUN / 'runs' / case['id'] / str(enabled)
            rows = read_events(folder / 'events.jsonl')
            rows_by_key[case['id'], enabled] = rows
            require([r['seq'] for r in rows] == list(range(len(rows))), 'Event sequence not exact')
            summary = rows[-1]
            require(summary['errors'] == summary['starts'] == summary['tunes'] == 0, 'Recorder/backend error')
            require(summary['observed'] == enabled and summary['fast'] == 0 and summary['chunk'] == case['chunk'], 'Invocation identity differs')
            require(summary['samples'] == summary['provided'] == wave['samples'] and summary['eof'] == 1, 'Finite waveform incomplete')
            raw = (folder / 'pops.u32le').read_bytes()
            words = list(struct.unpack('<' + 'I' * (len(raw) // 4), raw))
            require(words == (list(range(wave['samples'])) if enabled else []), 'Actual sample trace differs')
            require(summary['pops'] == len(words), 'Pop summary differs')
            enabled_pops += len(words)
            counts = collections.Counter(r['kind'] for r in rows)
            for field in ('frames', 'dispatches', 'v2_lich_events', 'v2_scch_events', 'v2_voice_calls', 'v2_mbe_calls', 'v2_audio_calls'):
                totals[field] += summary[field]
            if not enabled:
                require(not any(r['kind'] in OPTIONAL for r in rows), 'Detailed row in off mode')
                continue
            detailed.update(counts)
            frame_groups = collections.defaultdict(list)
            stack = []
            for row in rows:
                frame_groups[row['frame']].append(row)
                kind = row['kind']
                if kind in ('crc', 'scch'):
                    width = 7 if kind == 'scch' else (6 if row['channel'] == 1 else 12)
                    require(polynomial_remainder(row['bits'], width) == row['computed'], 'Independent final CRC disagreement')
                    require(row['fallback'] == 1 - row['soft_pass'] and (not row['soft_pass'] or row['computed'] == row['received']), 'Impossible CRC diagnostic')
                    if width == 7:
                        require(int(row['check_bits'], 2) == row['received'], 'CRC7 check bits disagree')
                    crc_counts[f'crc{width}'] += 1
                    crc_counts[f'crc{width}_pass' if row['computed'] == row['received'] else f'crc{width}_fail'] += 1
                if kind in ('voice_begin', 'mbe_begin', 'audio_begin'):
                    category = kind.split('_')[0]
                    parent = {'voice': None, 'mbe': 'voice', 'audio': 'mbe'}[category]
                    require((stack[-1][0] if stack else None) == parent, 'Invalid call nesting')
                    if category == 'voice': require(row['confirmed'] == 1, 'Voice while unconfirmed')
                    stack.append((category, row['frame']))
                if kind in ('voice_end', 'mbe_end', 'audio_end'):
                    require(stack.pop() == (kind.split('_')[0], row['frame']), 'Unpaired wrapper')
                if kind == 'audio_end':
                    require(row['pcm_domain'] == 'internal_post_gain_float160_and_staged_short160', 'PCM domain differs')
                    require(row['float_finite'] == 160 and math.isfinite(row['float_energy']), 'Nonfinite PCM in recorded run')
                if kind == 'frame_end':
                    for call, position in zip(row['body_calls'], row['body_positions']):
                        span = call['after'] - call['before']
                        delta = (call['symbol_after'] - call['symbol_before']) & 0xffffffff
                        if not call['eof_after']:
                            require(span == 20 and delta == 1 and position == call['after'], 'Invented complete symbol')
                            partial_classes['complete'] += 1
                        else:
                            require(0 <= span < 20 and delta == 0 and position == 0, 'Invented EOF symbol')
                            partial_classes['partial' if span else ('empty_after_eof' if call['eof_before'] else 'empty_first_eof')] += 1
            require(not stack, 'Unclosed wrapper call')
            require(counts['voice_begin'] == counts['voice_end'] == summary['v2_voice_calls'], 'Voice count mismatch')
            require(counts['mbe_begin'] == counts['mbe_end'] == summary['v2_mbe_calls'], 'MBE count mismatch')
            require(counts['audio_begin'] == counts['audio_end'] == summary['v2_audio_calls'], 'Audio count mismatch')
            result = {'id': case['id'], 'scenario': wave['scenario'], 'frames': summary['frames'],
                      'scch': counts['scch'], 'voice': counts['voice_begin'], 'mbe': counts['mbe_begin'],
                      'audio': counts['audio_begin'], 'samples': wave['samples']}
            result['voice_frames'] = []
            for fid, group in frame_groups.items():
                scch = [r for r in group if r['kind'] == 'scch']
                if not scch: continue
                require(len(scch) == 1, 'Multiple SCCH events in one frame')
                event = scch[0]
                lich = next(r for r in group if r['kind'] == 'lich')
                first = next(r for r in group if r['kind'] == 'frame_begin')
                last = next(r for r in group if r['kind'] == 'frame_end')
                body = list(map(int, last['body'][:8]))
                reg, decoded = first['pn95'] or 228, 0
                for dibit in body:
                    decoded = (decoded << 1) | ((dibit >> 1) ^ (reg & 1))
                    reg = (reg >> 1) | (((reg ^ (reg >> 4)) & 1) << 8)
                require(decoded == lich['full_lich'] == 239 and lich['lich'] == 119 and lich['voice'] == 3 and lich['scch'] == 1, 'Independent LICH route disagreement')
                require((decoded & 1) == (sum((decoded >> n) & 1 for n in range(4, 8)) & 1), 'LICH parity differs')
                audio = [r for r in group if r['kind'] == 'audio_end']
                item = {'frame': fid, 'source_frontier_end': last['frontier'], 'full_lich': decoded,
                        'information': event['bits'], 'computed_crc7': event['computed'], 'received_crc7': event['received'],
                        'soft_pass': event['soft_pass'], 'fallback': event['fallback'],
                        'confirmed_before': first['confirmed'], 'confirmed_after': last['confirmed'],
                        'end_evidence': last['evidence'], 'end_proved': last['proved'], 'return_value': last['value'],
                        'audio_indices_before': first['audio_indices'], 'audio_indices_after': last['audio_indices'],
                        'audio_blocks': [{k: r[k] for k in ('float_finite', 'float_nonzero', 'float_peak', 'float_energy',
                            'short_nonzero', 'short_peak', 'short_checksum', 'audio_indices')} for r in audio]}
                result['voice_frames'].append(item)
                if wave['scenario'] in ('scch_valid', 'scch_wrong'):
                    correct = wave['scenario'] == 'scch_valid'
                    require(fid in (4, 5) and event['bits'] == '0' * 25 and event['computed'] == 17
                            and event['received'] == (17 if correct else 81), 'Independent control truth differs')
                    vector_name = wave['frames'][fid]['vector']
                    require(bytes(map(int, last['body'])) == (RUN / 'inputs/vectors' / vector_name).read_bytes()[10:], 'Control body bytes differ')
                    require(last['proved'] == int(correct) and last['value'] == (2 if correct else 1), 'Control proof/history differs')
                if wave['scenario'] == 'warm_drop20':
                    require(fid == 4 and (event['computed'], event['received']) == (1, 32)
                            and last['evidence'] == last['proved'] == 0 and last['value'] == 1, 'Drop20 observed meaning differs')
            cases.append(result)
            all_blocks = [block for frame in result['voice_frames'] for block in frame['audio_blocks']]
            result['pcm_diagnostics'] = {'blocks': len(all_blocks), 'sample_positions': 160 * len(all_blocks),
                'float_nonzero': sum(b['float_nonzero'] for b in all_blocks),
                'short_nonzero': sum(b['short_nonzero'] for b in all_blocks),
                'max_short_peak': max((b['short_peak'] for b in all_blocks), default=0),
                'max_float_peak': max((b['float_peak'] for b in all_blocks), default=0),
                'finite_float_elements': sum(b['float_finite'] for b in all_blocks)}
    for case in manifest['cases']:
        require(off_projection(rows_by_key[case['id'], 0]) == off_projection(rows_by_key[case['id'], 1]), 'Observation changed common outcomes')
    chunk_pairs = 0
    for waveform in manifest['waveforms']:
        group = {c['chunk']: c['id'] for c in manifest['cases'] if c['waveform'] == waveform}
        require(set(group) == {37, 512}, 'Missing chunk pair')
        for enabled in (0, 1):
            require(chunk_projection(rows_by_key[group[37], enabled]) == chunk_projection(rows_by_key[group[512], enabled]), 'Chunk outcome differs')
            require((RUN / 'runs' / group[37] / str(enabled) / 'pops.u32le').read_bytes()
                    == (RUN / 'runs' / group[512] / str(enabled) / 'pops.u32le').read_bytes(), 'Chunk trace differs')
            chunk_pairs += 1
    anchor_pairs = unavailable = 0
    for case in manifest['cases']:
        if not manifest['waveforms'][case['waveform']].get('anchor_waveform'): continue
        for enabled in (0, 1):
            reference = RUN / 'frozen/anchor-reference' / case['id'] / str(enabled)
            unavailable += legacy_compare(read_events(reference / 'events.jsonl'), rows_by_key[case['id'], enabled])
            require((reference / 'pops.u32le').read_bytes() == (RUN / 'runs' / case['id'] / str(enabled) / 'pops.u32le').read_bytes(), 'Anchor pop trace changed')
            anchor_pairs += 1
    zero_hash = 2166136261
    for _ in range(320): zero_hash = (zero_hash * 16777619) & 0xffffffff
    for case in cases:
        for frame in case['voice_frames']:
            for block in frame['audio_blocks']:
                if not block['short_nonzero']: require(block['short_checksum'] == zero_hash, 'Zero PCM checksum differs')
    result = {'independent_audit_pass': True, 'scope': 'Recorded observation correctness/neutrality; no valid speech, playback or recovery improvement claim',
              'harness_commit': before['commit'], 'native_runs_performed_by_auditor': 0,
              'binary_sha256': before['binary_sha256'], 'report_sha256': sha(RUN / 'report.json'),
              'independent_script_sha256': sha(__file__), 'hash_checks': hashes,
              'invocations': 36, 'observed_invocations': 18, 'on_off_pairs_equal': 18,
              'chunk_pairs_equal': chunk_pairs, 'anchor_pairs_equal': anchor_pairs,
              'legacy_eof_positions_explicitly_unavailable': unavailable,
              'totals_across_36_invocations': dict(totals), 'detailed_events_across_18_enabled': dict(detailed),
              'independently_recomputed_crcs': dict(crc_counts), 'actual_pops_across_18_enabled': enabled_pops,
              'body_call_classes_across_18_enabled': dict(partial_classes), 'enabled_cases': cases,
              'limitations': ['No full PCM arrays were recorded: nonzero/peak/energy/checksum are diagnostics.',
                  'Internal float/short samples are not normalized audio or proof of valid AMBE speech.',
                  'No MBElib acceptance/erasure return or output-device playback event was observed.',
                  'The previous failed recovery study remains failed and unchanged.']}
    OUT.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k not in ('enabled_cases', 'limitations')}, indent=2))


if __name__ == '__main__':
    main()
