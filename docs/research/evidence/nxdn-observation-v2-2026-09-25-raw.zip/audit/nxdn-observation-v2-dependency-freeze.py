import hashlib,json,os,pathlib,re,shutil
root=pathlib.Path.cwd(); b=pathlib.Path(os.environ['LOCALAPPDATA'])/'XeraXSDR-build/nxdn-observation-v2-20260925'
line=next(x for x in (b/'build.ninja').read_text().splitlines() if x.startswith('build xerax_nxdn_observation_v2.exe:'))
libs={}
for token in line.split():
    if token.endswith('.a'):
        p=pathlib.Path(token.replace('C$:', 'C:')); p=p if p.is_absolute() else b/p
        if not p.is_file(): raise ValueError(p)
        libs[str(p.resolve())]=hashlib.sha256(p.read_bytes()).hexdigest()
out=root/'build/nxdn-observation-v2-dependencies'; out.mkdir(exist_ok=False)
mb=pathlib.Path(os.environ['LOCALAPPDATA'])/'XeraXSDR-build/lab-installed/x64-mingw-static'
shutil.copytree(mb/'share/mbe-neo',out/'mbe-neo-metadata')
shutil.copy2(mb/'lib/libmbe-neo-static.a',out/'libmbe-neo-static.a')
(out/'identity.json').write_text(json.dumps({'configured_link_archive_sha256':libs,'mbe_version':'2.1.0','mbe_vcpkg_source':'be5992dab7589aec6f3a45fa1881139c0caa2a97','scope':'Archive identities at preflight; map and build records separately prove selected symbols, not every archive member.'},indent=2)+'\n')
print(json.dumps({'archives':len(libs),'mbe_static_sha256':libs[str((mb/'lib/libmbe-neo-static.a').resolve())]}))
